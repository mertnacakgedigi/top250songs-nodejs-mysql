module.exports = {
    auth : require("./auth"),
    api : require("./api")
}