

// Spotify Api
var list = [
              
               {  "added_at": "2017-04-18T02:56:20Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/1dfeR4HaWDbWqFHLkxsg1d"
                                },
                                "href": "https://api.spotify.com/v1/artists/1dfeR4HaWDbWqFHLkxsg1d",
                                "id": "1dfeR4HaWDbWqFHLkxsg1d",
                                "name": "Queen",
                                "type": "artist",
                                "uri": "spotify:artist:1dfeR4HaWDbWqFHLkxsg1d"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/1TSZDcvlPtAnekTaItI3qO"
                        },
                        "href": "https://api.spotify.com/v1/albums/1TSZDcvlPtAnekTaItI3qO",
                        "id": "1TSZDcvlPtAnekTaItI3qO",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273a461aa96bd9a8fcd0a492aee",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02a461aa96bd9a8fcd0a492aee",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851a461aa96bd9a8fcd0a492aee",
                                "width": 64
                            }
                        ],
                        "name": "A Night At The Opera (2011 Remaster)",
                        "release_date": "1975-11-21",
                        "release_date_precision": "day",
                        "total_tracks": 12,
                        "type": "album",
                        "uri": "spotify:album:1TSZDcvlPtAnekTaItI3qO"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/1dfeR4HaWDbWqFHLkxsg1d"
                            },
                            "href": "https://api.spotify.com/v1/artists/1dfeR4HaWDbWqFHLkxsg1d",
                            "id": "1dfeR4HaWDbWqFHLkxsg1d",
                            "name": "Queen",
                            "type": "artist",
                            "uri": "spotify:artist:1dfeR4HaWDbWqFHLkxsg1d"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 354320,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBUM71029604"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/1AhDOtG9vPSOmsWgNW0BEY"
                    },
                    "href": "https://api.spotify.com/v1/tracks/1AhDOtG9vPSOmsWgNW0BEY",
                    "id": "1AhDOtG9vPSOmsWgNW0BEY",
                    "is_local": false,
                    "name": "Bohemian Rhapsody - Remastered 2011",    
                    "popularity": 11,
                    "preview_url": null,
                    "track": true,
                    "track_number": 11,
                    "type": "track",
                    "uri": "spotify:track:1AhDOtG9vPSOmsWgNW0BEY"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T02:56:28Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/3qm84nBOXUEQ2vnTfUTTFC"
                                },
                                "href": "https://api.spotify.com/v1/artists/3qm84nBOXUEQ2vnTfUTTFC",
                                "id": "3qm84nBOXUEQ2vnTfUTTFC",
                                "name": "Guns N' Roses",
                                "type": "artist",
                                "uri": "spotify:artist:3qm84nBOXUEQ2vnTfUTTFC"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/3I9Z1nDCL4E0cP62flcbI5"
                        },
                        "href": "https://api.spotify.com/v1/albums/3I9Z1nDCL4E0cP62flcbI5",
                        "id": "3I9Z1nDCL4E0cP62flcbI5",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273aa07223229c3f264be0ca653",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02aa07223229c3f264be0ca653",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851aa07223229c3f264be0ca653",
                                "width": 64
                            }
                        ],
                        "name": "Appetite For Destruction",
                        "release_date": "1987-07-21",
                        "release_date_precision": "day",
                        "total_tracks": 12,
                        "type": "album",
                        "uri": "spotify:album:3I9Z1nDCL4E0cP62flcbI5"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/3qm84nBOXUEQ2vnTfUTTFC"
                            },
                            "href": "https://api.spotify.com/v1/artists/3qm84nBOXUEQ2vnTfUTTFC",
                            "id": "3qm84nBOXUEQ2vnTfUTTFC",
                            "name": "Guns N' Roses",
                            "type": "artist",
                            "uri": "spotify:artist:3qm84nBOXUEQ2vnTfUTTFC"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 354520,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USGF18714809"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/7o2CTH4ctstm8TNelqjb51"
                    },
                    "href": "https://api.spotify.com/v1/tracks/7o2CTH4ctstm8TNelqjb51",
                    "id": "7o2CTH4ctstm8TNelqjb51",
                    "is_local": false,
                    "name": "Sweet Child O' Mine",
                    "popularity": 81,
                    "preview_url": "https://p.scdn.co/mp3-preview    /08877fcd63336fdd8c184fb5d1195fd5f6cc89cf?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 9,
                    "type": "track",
                    "uri": "spotify:track:7o2CTH4ctstm8TNelqjb51"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T02:56:41Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/6olE6TJLqED3rqDCT0FyPh"
                                },
                                "href": "https://api.spotify.com/v1/artists/6olE6TJLqED3rqDCT0FyPh",
                                "id": "6olE6TJLqED3rqDCT0FyPh",
                                "name": "Nirvana",
                                "type": "artist",
                                "uri": "spotify:artist:6olE6TJLqED3rqDCT0FyPh"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BO",
                            "BR",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "EC",
                            "EE",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JP",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PT",
                            "PY",
                            "RO",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TR",
                            "TW",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/2uEf3r9i2bnxwJQsxQ0xQ7"
                        },
                        "href": "https://api.spotify.com/v1/albums/2uEf3r9i2bnxwJQsxQ0xQ7",
                        "id": "2uEf3r9i2bnxwJQsxQ0xQ7",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b27328a90d00a2819504364880e4",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e0228a90d00a2819504364880e4",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d0000485128a90d00a2819504364880e4",
                                "width": 64
                            }
                        ],
                        "name": "Nevermind (Deluxe Edition)",
                        "release_date": "1991-09-26",
                        "release_date_precision": "day",
                        "total_tracks": 40,
                        "type": "album",
                        "uri": "spotify:album:2uEf3r9i2bnxwJQsxQ0xQ7"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/6olE6TJLqED3rqDCT0FyPh"
                            },
                            "href": "https://api.spotify.com/v1/artists/6olE6TJLqED3rqDCT0FyPh",
                            "id": "6olE6TJLqED3rqDCT0FyPh",
                            "name": "Nirvana",
                            "type": "artist",
                            "uri": "spotify:artist:6olE6TJLqED3rqDCT0FyPh"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BO",
                        "BR",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "EC",
                        "EE",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JP",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PT",
                        "PY",
                        "RO",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TR",
                        "TW",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 301920,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USGF19942501"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/1f3yAtsJtY87CTmM8RLnxf"
                    },
                    "href": "https://api.spotify.com/v1/tracks/1f3yAtsJtY87CTmM8RLnxf",
                    "id": "1f3yAtsJtY87CTmM8RLnxf",
                    "is_local": false,
                    "name": "Smells Like Teen Spirit",
                    "popularity": 80,
                    "preview_url": "https://p.scdn.co/mp3-preview    /a4655f8b70ebee4a0d56afea3fec16eefaec4bd3?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:1f3yAtsJtY87CTmM8RLnxf"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T02:57:19Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/4x1nvY2FN8jxqAFA0DA02H"
                                },
                                "href": "https://api.spotify.com/v1/artists/4x1nvY2FN8jxqAFA0DA02H",
                                "id": "4x1nvY2FN8jxqAFA0DA02H",
                                "name": "John Lennon",
                                "type": "artist",
                                "uri": "spotify:artist:4x1nvY2FN8jxqAFA0DA02H"
                            },
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/5JRQN1PslNH3W77jakgryr"
                                },
                                "href": "https://api.spotify.com/v1/artists/5JRQN1PslNH3W77jakgryr",
                                "id": "5JRQN1PslNH3W77jakgryr",
                                "name": "The Flux Fiddlers",
                                "type": "artist",
                                "uri": "spotify:artist:5JRQN1PslNH3W77jakgryr"
                            },
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/4m2kfAHEnK7Z7qLGxeWtro"
                                },
                                "href": "https://api.spotify.com/v1/artists/4m2kfAHEnK7Z7qLGxeWtro",
                                "id": "4m2kfAHEnK7Z7qLGxeWtro",
                                "name": "The Plastic Ono Band",
                                "type": "artist",
                                "uri": "spotify:artist:4m2kfAHEnK7Z7qLGxeWtro"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/0xzaemKucrJpYhyl7TltAk"
                        },
                        "href": "https://api.spotify.com/v1/albums/0xzaemKucrJpYhyl7TltAk",
                        "id": "0xzaemKucrJpYhyl7TltAk",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b27399581550ef9746ca582bb3cc",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e0299581550ef9746ca582bb3cc",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d0000485199581550ef9746ca582bb3cc",
                                "width": 64
                            }
                        ],
                        "name": "Imagine",
                        "release_date": "1971-09-09",
                        "release_date_precision": "day",
                        "total_tracks": 10,
                        "type": "album",
                        "uri": "spotify:album:0xzaemKucrJpYhyl7TltAk"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/4x1nvY2FN8jxqAFA0DA02H"
                            },
                            "href": "https://api.spotify.com/v1/artists/4x1nvY2FN8jxqAFA0DA02H",
                            "id": "4x1nvY2FN8jxqAFA0DA02H",
                            "name": "John Lennon",
                            "type": "artist",
                            "uri": "spotify:artist:4x1nvY2FN8jxqAFA0DA02H"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 187866,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBAYE1000769"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/7pKfPomDEeI4TPT6EOYjn9"
                    },
                    "href": "https://api.spotify.com/v1/tracks/7pKfPomDEeI4TPT6EOYjn9",
                    "id": "7pKfPomDEeI4TPT6EOYjn9",
                    "is_local": false,
                    "name": "Imagine - 2010 Mix",
                    "popularity": 77,
                    "preview_url": "https://p.scdn.co/mp3-preview    /8995c11b9e4a866f37eced30cdc2038667f50cb7?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:7pKfPomDEeI4TPT6EOYjn9"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T02:57:31Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "compilation",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/1QxaPWG1POM8Ul6WwsHq4y"
                                },
                                "href": "https://api.spotify.com/v1/artists/1QxaPWG1POM8Ul6WwsHq4y",
                                "id": "1QxaPWG1POM8Ul6WwsHq4y",
                                "name": "John Farnham",
                                "type": "artist",
                                "uri": "spotify:artist:1QxaPWG1POM8Ul6WwsHq4y"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/2kzUFnhuzdPxp33ncA1ovM"
                        },
                        "href": "https://api.spotify.com/v1/albums/2kzUFnhuzdPxp33ncA1ovM",
                        "id": "2kzUFnhuzdPxp33ncA1ovM",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273739e255fc355179f520d5f4e",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02739e255fc355179f520d5f4e",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851739e255fc355179f520d5f4e",
                                "width": 64
                            }
                        ],
                        "name": "Collections",
                        "release_date": "2008-09-19",
                        "release_date_precision": "day",
                        "total_tracks": 10,
                        "type": "album",
                        "uri": "spotify:album:2kzUFnhuzdPxp33ncA1ovM"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/1QxaPWG1POM8Ul6WwsHq4y"
                            },
                            "href": "https://api.spotify.com/v1/artists/1QxaPWG1POM8Ul6WwsHq4y",
                            "id": "1QxaPWG1POM8Ul6WwsHq4y",
                            "name": "John Farnham",
                            "type": "artist",
                            "uri": "spotify:artist:1QxaPWG1POM8Ul6WwsHq4y"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 302106,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "AUBM08641001"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/5NwkWwfRJaT55hEPtCmJHx"
                    },
                    "href": "https://api.spotify.com/v1/tracks/5NwkWwfRJaT55hEPtCmJHx",
                    "id": "5NwkWwfRJaT55hEPtCmJHx",
                    "is_local": false,
                    "name": "You're the Voice",
                    "popularity": 66,
                    "preview_url": "https://p.scdn.co/mp3-preview    /6a9248562a557046996c2c3e7e5ba9c052683b99?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:5NwkWwfRJaT55hEPtCmJHx"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T02:57:40Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/36QJpDe2go2KgaRleHCDTp"
                                },
                                "href": "https://api.spotify.com/v1/artists/36QJpDe2go2KgaRleHCDTp",
                                "id": "36QJpDe2go2KgaRleHCDTp",
                                "name": "Led Zeppelin",
                                "type": "artist",
                                "uri": "spotify:artist:36QJpDe2go2KgaRleHCDTp"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/44Ig8dzqOkvkGDzaUof9lK"
                        },
                        "href": "https://api.spotify.com/v1/albums/44Ig8dzqOkvkGDzaUof9lK",
                        "id": "44Ig8dzqOkvkGDzaUof9lK",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273c8a11e48c91a982d086afc69",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02c8a11e48c91a982d086afc69",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851c8a11e48c91a982d086afc69",
                                "width": 64
                            }
                        ],
                        "name": "Led Zeppelin IV (Deluxe Edition; Remaster)",
                        "release_date": "1971-11-08",
                        "release_date_precision": "day",
                        "total_tracks": 16,
                        "type": "album",
                        "uri": "spotify:album:44Ig8dzqOkvkGDzaUof9lK"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/36QJpDe2go2KgaRleHCDTp"
                            },
                            "href": "https://api.spotify.com/v1/artists/36QJpDe2go2KgaRleHCDTp",
                            "id": "36QJpDe2go2KgaRleHCDTp",
                            "name": "Led Zeppelin",
                            "type": "artist",
                            "uri": "spotify:artist:36QJpDe2go2KgaRleHCDTp"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 482830,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USAT21300959"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/5CQ30WqJwcep0pYcV4AMNc"
                    },
                    "href": "https://api.spotify.com/v1/tracks/5CQ30WqJwcep0pYcV4AMNc",
                    "id": "5CQ30WqJwcep0pYcV4AMNc",
                    "is_local": false,
                    "name": "Stairway to Heaven - 2012 Remaster",
                    "popularity": 78,
                    "preview_url": "https://p.scdn.co/mp3-preview    /8226164717312bc411f8635580562d67e191a754?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 4,
                    "type": "track",
                    "uri": "spotify:track:5CQ30WqJwcep0pYcV4AMNc"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T02:57:48Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/5a2EaR3hamoenG9rDuVn8j"
                                },
                                "href": "https://api.spotify.com/v1/artists/5a2EaR3hamoenG9rDuVn8j",
                                "id": "5a2EaR3hamoenG9rDuVn8j",
                                "name": "Prince",
                                "type": "artist",
                                "uri": "spotify:artist:5a2EaR3hamoenG9rDuVn8j"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/7nXJ5k4XgRj5OLg9m8V3zc"
                        },
                        "href": "https://api.spotify.com/v1/albums/7nXJ5k4XgRj5OLg9m8V3zc",
                        "id": "7nXJ5k4XgRj5OLg9m8V3zc",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273d52bfb90ee8dfeda8378b99b",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02d52bfb90ee8dfeda8378b99b",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851d52bfb90ee8dfeda8378b99b",
                                "width": 64
                            }
                        ],
                        "name": "Purple Rain",
                        "release_date": "1984-06-25",
                        "release_date_precision": "day",
                        "total_tracks": 9,
                        "type": "album",
                        "uri": "spotify:album:7nXJ5k4XgRj5OLg9m8V3zc"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/5a2EaR3hamoenG9rDuVn8j"
                            },
                            "href": "https://api.spotify.com/v1/artists/5a2EaR3hamoenG9rDuVn8j",
                            "id": "5a2EaR3hamoenG9rDuVn8j",
                            "name": "Prince",
                            "type": "artist",
                            "uri": "spotify:artist:5a2EaR3hamoenG9rDuVn8j"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 520786,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USWB10001880"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/54X78diSLoUDI3joC2bjMz"
                    },
                    "href": "https://api.spotify.com/v1/tracks/54X78diSLoUDI3joC2bjMz",
                    "id": "54X78diSLoUDI3joC2bjMz",
                    "is_local": false,
                    "name": "Purple Rain",
                    "popularity": 75,
                    "preview_url": "https://p.scdn.co/mp3-preview    /2fe008411edea4f21355301daa8993663eaf46f8?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 9,
                    "type": "track",
                    "uri": "spotify:track:54X78diSLoUDI3joC2bjMz"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T02:58:00Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/711MCceyCBcFnzjGY4Q7Un"
                                },
                                "href": "https://api.spotify.com/v1/artists/711MCceyCBcFnzjGY4Q7Un",
                                "id": "711MCceyCBcFnzjGY4Q7Un",
                                "name": "AC/DC",
                                "type": "artist",
                                "uri": "spotify:artist:711MCceyCBcFnzjGY4Q7Un"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/19AUoKWRAaQYrggVvdQnqq"
                        },
                        "href": "https://api.spotify.com/v1/albums/19AUoKWRAaQYrggVvdQnqq",
                        "id": "19AUoKWRAaQYrggVvdQnqq",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273fe88ce4e76995d0fdd92688a",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02fe88ce4e76995d0fdd92688a",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851fe88ce4e76995d0fdd92688a",
                                "width": 64
                            }
                        ],
                        "name": "High Voltage",
                        "release_date": "1976-05-14",
                        "release_date_precision": "day",
                        "total_tracks": 9,
                        "type": "album",
                        "uri": "spotify:album:19AUoKWRAaQYrggVvdQnqq"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/711MCceyCBcFnzjGY4Q7Un"
                            },
                            "href": "https://api.spotify.com/v1/artists/711MCceyCBcFnzjGY4Q7Un",
                            "id": "711MCceyCBcFnzjGY4Q7Un",
                            "name": "AC/DC",
                            "type": "artist",
                            "uri": "spotify:artist:711MCceyCBcFnzjGY4Q7Un"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 301226,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USEW17500002"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/7nemcVsXVFZF01iqpIIo2Y"
                    },
                    "href": "https://api.spotify.com/v1/tracks/7nemcVsXVFZF01iqpIIo2Y",
                    "id": "7nemcVsXVFZF01iqpIIo2Y",
                    "is_local": false,
                    "name": "It's a Long Way to the Top (If You Wanna Rock 'N' Roll)",
                    "popularity": 70,
                    "preview_url": "https://p.scdn.co/mp3-preview    /3ef81b4c80a7992678c52998078a46e5724b3669?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:7nemcVsXVFZF01iqpIIo2Y"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T02:58:14Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "compilation",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/3fMbdgg4jU18AjLCKBhRSm"
                                },
                                "href": "https://api.spotify.com/v1/artists/3fMbdgg4jU18AjLCKBhRSm",
                                "id": "3fMbdgg4jU18AjLCKBhRSm",
                                "name": "Michael Jackson",
                                "type": "artist",
                                "uri": "spotify:artist:3fMbdgg4jU18AjLCKBhRSm"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/77dNyQA0z8dV33M4so4eRY"
                        },
                        "href": "https://api.spotify.com/v1/albums/77dNyQA0z8dV33M4so4eRY",
                        "id": "77dNyQA0z8dV33M4so4eRY",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273ed1c305cd1e673fe925407ce",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02ed1c305cd1e673fe925407ce",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851ed1c305cd1e673fe925407ce",
                                "width": 64
                            }
                        ],
                        "name": "The Essential Michael Jackson",
                        "release_date": "2005-07-19",
                        "release_date_precision": "day",
                        "total_tracks": 38,
                        "type": "album",
                        "uri": "spotify:album:77dNyQA0z8dV33M4so4eRY"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/3fMbdgg4jU18AjLCKBhRSm"
                            },
                            "href": "https://api.spotify.com/v1/artists/3fMbdgg4jU18AjLCKBhRSm",
                            "id": "3fMbdgg4jU18AjLCKBhRSm",
                            "name": "Michael Jackson",
                            "type": "artist",
                            "uri": "spotify:artist:3fMbdgg4jU18AjLCKBhRSm"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 312413,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USSM10501511"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/20efeySIfZoiSaISGLBbNs"
                    },
                    "href": "https://api.spotify.com/v1/tracks/20efeySIfZoiSaISGLBbNs",
                    "id": "20efeySIfZoiSaISGLBbNs",
                    "is_local": false,
                    "name": "Thriller - Single Version",
                    "popularity": 54,
                    "preview_url": "https://p.scdn.co/mp3-preview/    41d3639dcb9fa25f07fb849730718a62538c6237?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 21,
                    "type": "track",
                    "uri": "spotify:track:20efeySIfZoiSaISGLBbNs"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T02:58:29Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/22bE4uQ6baNwSHPVcDxLCe"
                                },
                                "href": "https://api.spotify.com/v1/artists/22bE4uQ6baNwSHPVcDxLCe",
                                "id": "22bE4uQ6baNwSHPVcDxLCe",
                                "name": "The Rolling Stones",
                                "type": "artist",
                                "uri": "spotify:artist:22bE4uQ6baNwSHPVcDxLCe"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/24V2ghp7XhGZzWKjthHq4v"
                        },
                        "href": "https://api.spotify.com/v1/albums/24V2ghp7XhGZzWKjthHq4v",
                        "id": "24V2ghp7XhGZzWKjthHq4v",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273d1ba3816b76a35c8de273f00",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02d1ba3816b76a35c8de273f00",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851d1ba3816b76a35c8de273f00",
                                "width": 64
                            }
                        ],
                        "name": "Out Of Our Heads (Remastered)",
                        "release_date": "1965-07-30",
                        "release_date_precision": "day",
                        "total_tracks": 12,
                        "type": "album",
                        "uri": "spotify:album:24V2ghp7XhGZzWKjthHq4v"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/22bE4uQ6baNwSHPVcDxLCe"
                            },
                            "href": "https://api.spotify.com/v1/artists/22bE4uQ6baNwSHPVcDxLCe",
                            "id": "22bE4uQ6baNwSHPVcDxLCe",
                            "name": "The Rolling Stones",
                            "type": "artist",
                            "uri": "spotify:artist:22bE4uQ6baNwSHPVcDxLCe"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 222813,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USA176510160"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/7fSGbZLhWlAiCC3HDPAULu"
                    },
                    "href": "https://api.spotify.com/v1/tracks/7fSGbZLhWlAiCC3HDPAULu",
                    "id": "7fSGbZLhWlAiCC3HDPAULu",
                    "is_local": false,
                    "name": "(I Can't Get No) Satisfaction - Mono Version / Remastered 2002    ",
                    "popularity": 5,
                    "preview_url": null,
                    "track": true,
                    "track_number": 7,
                    "type": "track",
                    "uri": "spotify:track:7fSGbZLhWlAiCC3HDPAULu"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T02:58:41Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/0LcJLqbBmaGUft1e9Mm8HV"
                                },
                                "href": "https://api.spotify.com/v1/artists/0LcJLqbBmaGUft1e9Mm8HV",
                                "id": "0LcJLqbBmaGUft1e9Mm8HV",
                                "name": "ABBA",
                                "type": "artist",
                                "uri": "spotify:artist:0LcJLqbBmaGUft1e9Mm8HV"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/79ZX48114T8NH36MnOTtl7"
                        },
                        "href": "https://api.spotify.com/v1/albums/79ZX48114T8NH36MnOTtl7",
                        "id": "79ZX48114T8NH36MnOTtl7",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2739aa209383c254c9e23e7f909",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e029aa209383c254c9e23e7f909",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048519aa209383c254c9e23e7f909",
                                "width": 64
                            }
                        ],
                        "name": "Arrival",
                        "release_date": "1976",
                        "release_date_precision": "year",
                        "total_tracks": 12,
                        "type": "album",
                        "uri": "spotify:album:79ZX48114T8NH36MnOTtl7"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/0LcJLqbBmaGUft1e9Mm8HV"
                            },
                            "href": "https://api.spotify.com/v1/artists/0LcJLqbBmaGUft1e9Mm8HV",
                            "id": "0LcJLqbBmaGUft1e9Mm8HV",
                            "name": "ABBA",
                            "type": "artist",
                            "uri": "spotify:artist:0LcJLqbBmaGUft1e9Mm8HV"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 230400,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "SEAYD7601020"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/01iyCAUm8EvOFqVWYJ3dVX"
                    },
                    "href": "https://api.spotify.com/v1/tracks/01iyCAUm8EvOFqVWYJ3dVX",
                    "id": "01iyCAUm8EvOFqVWYJ3dVX",
                    "is_local": false,
                    "name": "Dancing Queen    ",
                    "popularity": 7,
                    "preview_url": null,
                    "track": true,
                    "track_number": 2,
                    "type": "track",
                    "uri": "spotify:track:01iyCAUm8EvOFqVWYJ3dVX"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T02:58:50Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/58lV9VcRSjABbAbfWS6skp"
                                },
                                "href": "https://api.spotify.com/v1/artists/58lV9VcRSjABbAbfWS6skp",
                                "id": "58lV9VcRSjABbAbfWS6skp",
                                "name": "Bon Jovi",
                                "type": "artist",
                                "uri": "spotify:artist:58lV9VcRSjABbAbfWS6skp"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/3gORsZp3xSbkN1ymRNonp1"
                        },
                        "href": "https://api.spotify.com/v1/albums/3gORsZp3xSbkN1ymRNonp1",
                        "id": "3gORsZp3xSbkN1ymRNonp1",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273a82359c9fefa599be35017b1",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02a82359c9fefa599be35017b1",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851a82359c9fefa599be35017b1",
                                "width": 64
                            }
                        ],
                        "name": "Slippery When Wet",
                        "release_date": "1986-01-01",
                        "release_date_precision": "day",
                        "total_tracks": 10,
                        "type": "album",
                        "uri": "spotify:album:3gORsZp3xSbkN1ymRNonp1"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/58lV9VcRSjABbAbfWS6skp"
                            },
                            "href": "https://api.spotify.com/v1/artists/58lV9VcRSjABbAbfWS6skp",
                            "id": "58lV9VcRSjABbAbfWS6skp",
                            "name": "Bon Jovi",
                            "type": "artist",
                            "uri": "spotify:artist:58lV9VcRSjABbAbfWS6skp"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 250306,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USPR38619998"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/2tyW1uBUnYMKAFEfKDKi9B"
                    },
                    "href": "https://api.spotify.com/v1/tracks/2tyW1uBUnYMKAFEfKDKi9B",
                    "id": "2tyW1uBUnYMKAFEfKDKi9B",
                    "is_local": false,
                    "name": "Livin' On A Prayer    ",
                    "popularity": 3,
                    "preview_url": null,
                    "track": true,
                    "track_number": 3,
                    "type": "track",
                    "uri": "spotify:track:2tyW1uBUnYMKAFEfKDKi9B"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T02:58:59Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/1pJEZXU2hJApJW3rM7LmMu"
                                },
                                "href": "https://api.spotify.com/v1/artists/1pJEZXU2hJApJW3rM7LmMu",
                                "id": "1pJEZXU2hJApJW3rM7LmMu",
                                "name": "The Easybeats",
                                "type": "artist",
                                "uri": "spotify:artist:1pJEZXU2hJApJW3rM7LmMu"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/3SyxsGqgDR1LZFWU3Z48jE"
                        },
                        "href": "https://api.spotify.com/v1/albums/3SyxsGqgDR1LZFWU3Z48jE",
                        "id": "3SyxsGqgDR1LZFWU3Z48jE",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273a90ebf74836caf37e5c25844",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02a90ebf74836caf37e5c25844",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851a90ebf74836caf37e5c25844",
                                "width": 64
                            }
                        ],
                        "name": "Friday On My Mind",
                        "release_date": "1965",
                        "release_date_precision": "year",
                        "total_tracks": 18,
                        "type": "album",
                        "uri": "spotify:album:3SyxsGqgDR1LZFWU3Z48jE"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/1pJEZXU2hJApJW3rM7LmMu"
                            },
                            "href": "https://api.spotify.com/v1/artists/1pJEZXU2hJApJW3rM7LmMu",
                            "id": "1pJEZXU2hJApJW3rM7LmMu",
                            "name": "The Easybeats",
                            "type": "artist",
                            "uri": "spotify:artist:1pJEZXU2hJApJW3rM7LmMu"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 162106,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "AUAP06600062"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/2rKjTiwhbkdM2focSdHc7p"
                    },
                    "href": "https://api.spotify.com/v1/tracks/2rKjTiwhbkdM2focSdHc7p",
                    "id": "2rKjTiwhbkdM2focSdHc7p",
                    "is_local": false,
                    "name": "Friday on My Mind    ",
                    "popularity": 0,
                    "preview_url": null,
                    "track": true,
                    "track_number": 6,
                    "type": "track",
                    "uri": "spotify:track:2rKjTiwhbkdM2focSdHc7p"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T02:59:08Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/6tbjWDEIzxoDsBA1FuhfPW"
                                },
                                "href": "https://api.spotify.com/v1/artists/6tbjWDEIzxoDsBA1FuhfPW",
                                "id": "6tbjWDEIzxoDsBA1FuhfPW",
                                "name": "Madonna",
                                "type": "artist",
                                "uri": "spotify:artist:6tbjWDEIzxoDsBA1FuhfPW"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/2IU9ftOgyRL2caQGWK1jjX"
                        },
                        "href": "https://api.spotify.com/v1/albums/2IU9ftOgyRL2caQGWK1jjX",
                        "id": "2IU9ftOgyRL2caQGWK1jjX",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273e09cc42d97962159cd0ab1e6",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02e09cc42d97962159cd0ab1e6",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851e09cc42d97962159cd0ab1e6",
                                "width": 64
                            }
                        ],
                        "name": "Like a Virgin (Reissue)",
                        "release_date": "1984-11-12",
                        "release_date_precision": "day",
                        "total_tracks": 11,
                        "type": "album",
                        "uri": "spotify:album:2IU9ftOgyRL2caQGWK1jjX"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/6tbjWDEIzxoDsBA1FuhfPW"
                            },
                            "href": "https://api.spotify.com/v1/artists/6tbjWDEIzxoDsBA1FuhfPW",
                            "id": "6tbjWDEIzxoDsBA1FuhfPW",
                            "name": "Madonna",
                            "type": "artist",
                            "uri": "spotify:artist:6tbjWDEIzxoDsBA1FuhfPW"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 218626,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USWB10002748"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/1ZPlNanZsJSPK5h9YZZFbZ"
                    },
                    "href": "https://api.spotify.com/v1/tracks/1ZPlNanZsJSPK5h9YZZFbZ",
                    "id": "1ZPlNanZsJSPK5h9YZZFbZ",
                    "is_local": false,
                    "name": "Like a Virgin",
                    "popularity": 70,
                    "preview_url": "https://p.scdn.co/mp3-preview    /693e9d74bf04462da738351385fdc225cc465edc?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 3,
                    "type": "track",
                    "uri": "spotify:track:1ZPlNanZsJSPK5h9YZZFbZ"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T02:59:18Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/3oDbviiivRWhXwIE8hxkVV"
                                },
                                "href": "https://api.spotify.com/v1/artists/3oDbviiivRWhXwIE8hxkVV",
                                "id": "3oDbviiivRWhXwIE8hxkVV",
                                "name": "The Beach Boys",
                                "type": "artist",
                                "uri": "spotify:artist:3oDbviiivRWhXwIE8hxkVV"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/37rNuexqEXWeSIOiJtn3A9"
                        },
                        "href": "https://api.spotify.com/v1/albums/37rNuexqEXWeSIOiJtn3A9",
                        "id": "37rNuexqEXWeSIOiJtn3A9",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273fb9dac3244b8486758058a81",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02fb9dac3244b8486758058a81",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851fb9dac3244b8486758058a81",
                                "width": 64
                            }
                        ],
                        "name": "Smiley Smile (Remastered)",
                        "release_date": "1967-09-18",
                        "release_date_precision": "day",
                        "total_tracks": 11,
                        "type": "album",
                        "uri": "spotify:album:37rNuexqEXWeSIOiJtn3A9"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/3oDbviiivRWhXwIE8hxkVV"
                            },
                            "href": "https://api.spotify.com/v1/artists/3oDbviiivRWhXwIE8hxkVV",
                            "id": "3oDbviiivRWhXwIE8hxkVV",
                            "name": "The Beach Boys",
                            "type": "artist",
                            "uri": "spotify:artist:3oDbviiivRWhXwIE8hxkVV"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 219026,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USCA20100360"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/5t9KYe0Fhd5cW6UYT4qP8f"
                    },
                    "href": "https://api.spotify.com/v1/tracks/5t9KYe0Fhd5cW6UYT4qP8f",
                    "id": "5t9KYe0Fhd5cW6UYT4qP8f",
                    "is_local": false,
                    "name": "Good Vibrations - Remastered",
                    "popularity": 72,
                    "preview_url": "https://p.scdn.co/mp3-preview    /ba9868a557bdee4ef0c5f90e8bd75bb2affa9532?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 6,
                    "type": "track",
                    "uri": "spotify:track:5t9KYe0Fhd5cW6UYT4qP8f"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T02:59:27Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/74ASZWbe4lXaubB36ztrGX"
                                },
                                "href": "https://api.spotify.com/v1/artists/74ASZWbe4lXaubB36ztrGX",
                                "id": "74ASZWbe4lXaubB36ztrGX",
                                "name": "Bob Dylan",
                                "type": "artist",
                                "uri": "spotify:artist:74ASZWbe4lXaubB36ztrGX"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/2Pj2kZM5XpyIeyFBTAVulL"
                        },
                        "href": "https://api.spotify.com/v1/albums/2Pj2kZM5XpyIeyFBTAVulL",
                        "id": "2Pj2kZM5XpyIeyFBTAVulL",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2736c86683d20c72e3874c11c6d",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e026c86683d20c72e3874c11c6d",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048516c86683d20c72e3874c11c6d",
                                "width": 64
                            }
                        ],
                        "name": "Pat Garrett & Billy The Kid [Soundtrack From The Motion Picture) (Remastered]",
                        "release_date": "1973-07-13",
                        "release_date_precision": "day",
                        "total_tracks": 10,
                        "type": "album",
                        "uri": "spotify:album:2Pj2kZM5XpyIeyFBTAVulL"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/74ASZWbe4lXaubB36ztrGX"
                            },
                            "href": "https://api.spotify.com/v1/artists/74ASZWbe4lXaubB36ztrGX",
                            "id": "74ASZWbe4lXaubB36ztrGX",
                            "name": "Bob Dylan",
                            "type": "artist",
                            "uri": "spotify:artist:74ASZWbe4lXaubB36ztrGX"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 149880,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USSM11304547"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/6HSXNV0b4M4cLJ7ljgVVeh"
                    },
                    "href": "https://api.spotify.com/v1/tracks/6HSXNV0b4M4cLJ7ljgVVeh",
                    "id": "6HSXNV0b4M4cLJ7ljgVVeh",
                    "is_local": false,
                    "name": "Knockin' On Heaven's Door",
                    "popularity": 74,
                    "preview_url": "https://p.scdn.co/mp3-preview    /5d590e2139ce4eb119238968a8b398e8510a6251?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 7,
                    "type": "track",
                    "uri": "spotify:track:6HSXNV0b4M4cLJ7ljgVVeh"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:03:20Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/0ECwFtbIWEVNwjlrfc6xoL"
                                },
                                "href": "https://api.spotify.com/v1/artists/0ECwFtbIWEVNwjlrfc6xoL",
                                "id": "0ECwFtbIWEVNwjlrfc6xoL",
                                "name": "Eagles",
                                "type": "artist",
                                "uri": "spotify:artist:0ECwFtbIWEVNwjlrfc6xoL"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/2widuo17g5CEC66IbzveRu"
                        },
                        "href": "https://api.spotify.com/v1/albums/2widuo17g5CEC66IbzveRu",
                        "id": "2widuo17g5CEC66IbzveRu",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2734637341b9f507521afa9a778",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e024637341b9f507521afa9a778",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048514637341b9f507521afa9a778",
                                "width": 64
                            }
                        ],
                        "name": "Hotel California (2013 Remaster)",
                        "release_date": "1976-12-08",
                        "release_date_precision": "day",
                        "total_tracks": 9,
                        "type": "album",
                        "uri": "spotify:album:2widuo17g5CEC66IbzveRu"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/0ECwFtbIWEVNwjlrfc6xoL"
                            },
                            "href": "https://api.spotify.com/v1/artists/0ECwFtbIWEVNwjlrfc6xoL",
                            "id": "0ECwFtbIWEVNwjlrfc6xoL",
                            "name": "Eagles",
                            "type": "artist",
                            "uri": "spotify:artist:0ECwFtbIWEVNwjlrfc6xoL"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 391376,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USEE11300353"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/40riOy7x9W7GXjyGp4pjAv"
                    },
                    "href": "https://api.spotify.com/v1/tracks/40riOy7x9W7GXjyGp4pjAv",
                    "id": "40riOy7x9W7GXjyGp4pjAv",
                    "is_local": false,
                    "name": "Hotel California - 2013 Remaster",
                    "popularity": 82,
                    "preview_url": "https://p.scdn.co/mp3-preview    /50e82c99c20ffa4223e82250605bbd8500cb3928?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:40riOy7x9W7GXjyGp4pjAv"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:03:30Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "compilation",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/5lpH0xAS4fVfLkACg9DAuM"
                                },
                                "href": "https://api.spotify.com/v1/artists/5lpH0xAS4fVfLkACg9DAuM",
                                "id": "5lpH0xAS4fVfLkACg9DAuM",
                                "name": "Wham!",
                                "type": "artist",
                                "uri": "spotify:artist:5lpH0xAS4fVfLkACg9DAuM"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/6ZJD7uT643TvniNyAk90bd"
                        },
                        "href": "https://api.spotify.com/v1/albums/6ZJD7uT643TvniNyAk90bd",
                        "id": "6ZJD7uT643TvniNyAk90bd",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273ee44e3a23aaaa941f7adb48d",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02ee44e3a23aaaa941f7adb48d",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851ee44e3a23aaaa941f7adb48d",
                                "width": 64
                            }
                        ],
                        "name": "The Final",
                        "release_date": "1986-11-25",
                        "release_date_precision": "day",
                        "total_tracks": 14,
                        "type": "album",
                        "uri": "spotify:album:6ZJD7uT643TvniNyAk90bd"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/19ra5tSw0tWufvUp8GotLo"
                            },
                            "href": "https://api.spotify.com/v1/artists/19ra5tSw0tWufvUp8GotLo",
                            "id": "19ra5tSw0tWufvUp8GotLo",
                            "name": "George Michael",
                            "type": "artist",
                            "uri": "spotify:artist:19ra5tSw0tWufvUp8GotLo"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 302600,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBBBM8400003"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/2R7858bg0GHuBBxjTyOL7N"
                    },
                    "href": "https://api.spotify.com/v1/tracks/2R7858bg0GHuBBxjTyOL7N",
                    "id": "2R7858bg0GHuBBxjTyOL7N",
                    "is_local": false,
                    "name": "Careless Whisper",
                    "popularity": 60,
                    "preview_url": "https://p.scdn.co/mp3-preview    /ab98c6031a85f245e278159490ccb22dc3440ad7?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 6,
                    "type": "track",
                    "uri": "spotify:track:2R7858bg0GHuBBxjTyOL7N"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:03:48Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/51Blml2LZPmy7TTiAg47vQ"
                                },
                                "href": "https://api.spotify.com/v1/artists/51Blml2LZPmy7TTiAg47vQ",
                                "id": "51Blml2LZPmy7TTiAg47vQ",
                                "name": "U2",
                                "type": "artist",
                                "uri": "spotify:artist:51Blml2LZPmy7TTiAg47vQ"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/2qKmY7yt0kXdzSQxYAu9eZ"
                        },
                        "href": "https://api.spotify.com/v1/albums/2qKmY7yt0kXdzSQxYAu9eZ",
                        "id": "2qKmY7yt0kXdzSQxYAu9eZ",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2732e5cea3a0e09cccb3d1568e8",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e022e5cea3a0e09cccb3d1568e8",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048512e5cea3a0e09cccb3d1568e8",
                                "width": 64
                            }
                        ],
                        "name": "The Joshua Tree (Deluxe Edition Remastered)",
                        "release_date": "1987-03-10",
                        "release_date_precision": "day",
                        "total_tracks": 25,
                        "type": "album",
                        "uri": "spotify:album:2qKmY7yt0kXdzSQxYAu9eZ"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/51Blml2LZPmy7TTiAg47vQ"
                            },
                            "href": "https://api.spotify.com/v1/artists/51Blml2LZPmy7TTiAg47vQ",
                            "id": "51Blml2LZPmy7TTiAg47vQ",
                            "name": "U2",
                            "type": "artist",
                            "uri": "spotify:artist:51Blml2LZPmy7TTiAg47vQ"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 277480,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBUM70709783"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/7gozgbG5EBTukCFWToTRA5"
                    },
                    "href": "https://api.spotify.com/v1/tracks/7gozgbG5EBTukCFWToTRA5",
                    "id": "7gozgbG5EBTukCFWToTRA5",
                    "is_local": false,
                    "name": "I Still Haven't Found What I'm Looking For - Remastered 2007    ",
                    "popularity": 9,
                    "preview_url": null,
                    "track": true,
                    "track_number": 2,
                    "type": "track",
                    "uri": "spotify:track:7gozgbG5EBTukCFWToTRA5"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:03:55Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/7nwUJBm0HE4ZxD3f5cy5ok"
                                },
                                "href": "https://api.spotify.com/v1/artists/7nwUJBm0HE4ZxD3f5cy5ok",
                                "id": "7nwUJBm0HE4ZxD3f5cy5ok",
                                "name": "Aretha Franklin",
                                "type": "artist",
                                "uri": "spotify:artist:7nwUJBm0HE4ZxD3f5cy5ok"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/5WndWfzGwCkHzAbQXVkg2V"
                        },
                        "href": "https://api.spotify.com/v1/albums/5WndWfzGwCkHzAbQXVkg2V",
                        "id": "5WndWfzGwCkHzAbQXVkg2V",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2736aa9314b7ddfbd8f036ba3ac",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e026aa9314b7ddfbd8f036ba3ac",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048516aa9314b7ddfbd8f036ba3ac",
                                "width": 64
                            }
                        ],
                        "name": "I Never Loved a Man the Way I Love You",
                        "release_date": "1967-03-10",
                        "release_date_precision": "day",
                        "total_tracks": 14,
                        "type": "album",
                        "uri": "spotify:album:5WndWfzGwCkHzAbQXVkg2V"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/7nwUJBm0HE4ZxD3f5cy5ok"
                            },
                            "href": "https://api.spotify.com/v1/artists/7nwUJBm0HE4ZxD3f5cy5ok",
                            "id": "7nwUJBm0HE4ZxD3f5cy5ok",
                            "name": "Aretha Franklin",
                            "type": "artist",
                            "uri": "spotify:artist:7nwUJBm0HE4ZxD3f5cy5ok"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 147600,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USAT20801240"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/7s25THrKz86DM225dOYwnr"
                    },
                    "href": "https://api.spotify.com/v1/tracks/7s25THrKz86DM225dOYwnr",
                    "id": "7s25THrKz86DM225dOYwnr",
                    "is_local": false,
                    "name": "Respect",
                    "popularity": 72,
                    "preview_url": "https://p.scdn.co/mp3-preview    /b0d0b4ec8963779239654542a0b33d25caf38156?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:7s25THrKz86DM225dOYwnr"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:04:12Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/6XpaIBNiVzIetEPCWDvAFP"
                                },
                                "href": "https://api.spotify.com/v1/artists/6XpaIBNiVzIetEPCWDvAFP",
                                "id": "6XpaIBNiVzIetEPCWDvAFP",
                                "name": "Whitney Houston",
                                "type": "artist",
                                "uri": "spotify:artist:6XpaIBNiVzIetEPCWDvAFP"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/7JVJlkNNobS0GSoy4tCS96"
                        },
                        "href": "https://api.spotify.com/v1/albums/7JVJlkNNobS0GSoy4tCS96",
                        "id": "7JVJlkNNobS0GSoy4tCS96",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273456c0b5d0316a80dc600802e",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02456c0b5d0316a80dc600802e",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851456c0b5d0316a80dc600802e",
                                "width": 64
                            }
                        ],
                        "name": "The Bodyguard - Original Soundtrack Album",
                        "release_date": "1992-11-17",
                        "release_date_precision": "day",
                        "total_tracks": 12,
                        "type": "album",
                        "uri": "spotify:album:7JVJlkNNobS0GSoy4tCS96"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/6XpaIBNiVzIetEPCWDvAFP"
                            },
                            "href": "https://api.spotify.com/v1/artists/6XpaIBNiVzIetEPCWDvAFP",
                            "id": "6XpaIBNiVzIetEPCWDvAFP",
                            "name": "Whitney Houston",
                            "type": "artist",
                            "uri": "spotify:artist:6XpaIBNiVzIetEPCWDvAFP"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 271093,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USAR19200110"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/4eHbdreAnSOrDDsFfc4Fpm"
                    },
                    "href": "https://api.spotify.com/v1/tracks/4eHbdreAnSOrDDsFfc4Fpm",
                    "id": "4eHbdreAnSOrDDsFfc4Fpm",
                    "is_local": false,
                    "name": "I Will Always Love You",
                    "popularity": 76,
                    "preview_url": "https://p.scdn.co/mp3-preview    /91e6d3e0b48cda2f3a1b2391a1c1384fbf73b8a8?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:4eHbdreAnSOrDDsFfc4Fpm"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:04:24Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/2AsusXITU8P25dlRNhcAbG"
                                },
                                "href": "https://api.spotify.com/v1/artists/2AsusXITU8P25dlRNhcAbG",
                                "id": "2AsusXITU8P25dlRNhcAbG",
                                "name": "Gotye",
                                "type": "artist",
                                "uri": "spotify:artist:2AsusXITU8P25dlRNhcAbG"
                            }
                        ],
                        "available_markets": [
                            "AU",
                            "NZ"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/6EMxWaM803hd4sPsJ6PkcA"
                        },
                        "href": "https://api.spotify.com/v1/albums/6EMxWaM803hd4sPsJ6PkcA",
                        "id": "6EMxWaM803hd4sPsJ6PkcA",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2731ba0ff466c68a0977a0039bc",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e021ba0ff466c68a0977a0039bc",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048511ba0ff466c68a0977a0039bc",
                                "width": 64
                            }
                        ],
                        "name": "Making Mirrors",
                        "release_date": "2011-01-01",
                        "release_date_precision": "day",
                        "total_tracks": 12,
                        "type": "album",
                        "uri": "spotify:album:6EMxWaM803hd4sPsJ6PkcA"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/2AsusXITU8P25dlRNhcAbG"
                            },
                            "href": "https://api.spotify.com/v1/artists/2AsusXITU8P25dlRNhcAbG",
                            "id": "2AsusXITU8P25dlRNhcAbG",
                            "name": "Gotye",
                            "type": "artist",
                            "uri": "spotify:artist:2AsusXITU8P25dlRNhcAbG"
                        },
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/6hk7Yq1DU9QcCCrz9uc0Ti"
                            },
                            "href": "https://api.spotify.com/v1/artists/6hk7Yq1DU9QcCCrz9uc0Ti",
                            "id": "6hk7Yq1DU9QcCCrz9uc0Ti",
                            "name": "Kimbra",
                            "type": "artist",
                            "uri": "spotify:artist:6hk7Yq1DU9QcCCrz9uc0Ti"
                        }
                    ],
                    "available_markets": [
                        "AU",
                        "NZ"
                    ],
                    "disc_number": 1,
                    "duration_ms": 244893,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "AUZS21100040"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/1qk9ujVgudgU8CyhKOx8ji"
                    },
                    "href": "https://api.spotify.com/v1/tracks/1qk9ujVgudgU8CyhKOx8ji",
                    "id": "1qk9ujVgudgU8CyhKOx8ji",
                    "is_local": false,
                    "name": "Somebody That I Used To Know",
                    "popularity": 63,
                    "preview_url": "https://p.scdn.co/mp3-preview    /34cc24aa7a9b042f909346a27d1ac423d5452462?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 3,
                    "type": "track",
                    "uri": "spotify:track:1qk9ujVgudgU8CyhKOx8ji"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:04:33Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/568ZhdwyaiCyOGJRtNYhWf"
                                },
                                "href": "https://api.spotify.com/v1/artists/568ZhdwyaiCyOGJRtNYhWf",
                                "id": "568ZhdwyaiCyOGJRtNYhWf",
                                "name": "Deep Purple",
                                "type": "artist",
                                "uri": "spotify:artist:568ZhdwyaiCyOGJRtNYhWf"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/32NQ56VZDTXSH3SMv4XSGN"
                        },
                        "href": "https://api.spotify.com/v1/albums/32NQ56VZDTXSH3SMv4XSGN",
                        "id": "32NQ56VZDTXSH3SMv4XSGN",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273a729c9c3dec04b99d889c66f",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02a729c9c3dec04b99d889c66f",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851a729c9c3dec04b99d889c66f",
                                "width": 64
                            }
                        ],
                        "name": "Machine Head (Remastered)",
                        "release_date": "1972-03-25",
                        "release_date_precision": "day",
                        "total_tracks": 8,
                        "type": "album",
                        "uri": "spotify:album:32NQ56VZDTXSH3SMv4XSGN"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/568ZhdwyaiCyOGJRtNYhWf"
                            },
                            "href": "https://api.spotify.com/v1/artists/568ZhdwyaiCyOGJRtNYhWf",
                            "id": "568ZhdwyaiCyOGJRtNYhWf",
                            "name": "Deep Purple",
                            "type": "artist",
                            "uri": "spotify:artist:568ZhdwyaiCyOGJRtNYhWf"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 340742,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBDXG1200006"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/5MMnwYs0hIxkENRsbkWJ2G"
                    },
                    "href": "https://api.spotify.com/v1/tracks/5MMnwYs0hIxkENRsbkWJ2G",
                    "id": "5MMnwYs0hIxkENRsbkWJ2G",
                    "is_local": false,
                    "name": "Smoke On The Water - Remastered 2012",
                    "popularity": 75,
                    "preview_url": "https://p.scdn.co/mp3-preview    /94ac3266d30211c5ca9d8067edca1b8b1da87ad3?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 5,
                    "type": "track",
                    "uri": "spotify:track:5MMnwYs0hIxkENRsbkWJ2G"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:04:44Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "compilation",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/7ohlPA8dRBtCf92zaZCaaB"
                                },
                                "href": "https://api.spotify.com/v1/artists/7ohlPA8dRBtCf92zaZCaaB",
                                "id": "7ohlPA8dRBtCf92zaZCaaB",
                                "name": "Crowded House",
                                "type": "artist",
                                "uri": "spotify:artist:7ohlPA8dRBtCf92zaZCaaB"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/1a89uP7otjpXF9UvMKy02M"
                        },
                        "href": "https://api.spotify.com/v1/albums/1a89uP7otjpXF9UvMKy02M",
                        "id": "1a89uP7otjpXF9UvMKy02M",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273ed0c9d87136532ab57be5324",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02ed0c9d87136532ab57be5324",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851ed0c9d87136532ab57be5324",
                                "width": 64
                            }
                        ],
                        "name": "The Very Very Best Of Crowded House",
                        "release_date": "2010-01-01",
                        "release_date_precision": "day",
                        "total_tracks": 19,
                        "type": "album",
                        "uri": "spotify:album:1a89uP7otjpXF9UvMKy02M"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/7ohlPA8dRBtCf92zaZCaaB"
                            },
                            "href": "https://api.spotify.com/v1/artists/7ohlPA8dRBtCf92zaZCaaB",
                            "id": "7ohlPA8dRBtCf92zaZCaaB",
                            "name": "Crowded House",
                            "type": "artist",
                            "uri": "spotify:artist:7ohlPA8dRBtCf92zaZCaaB"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 188049,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USCA28800035"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/4zVyMSnXjxM734u4SQTqVx"
                    },
                    "href": "https://api.spotify.com/v1/tracks/4zVyMSnXjxM734u4SQTqVx",
                    "id": "4zVyMSnXjxM734u4SQTqVx",
                    "is_local": false,
                    "name": "Better Be Home Soon",
                    "popularity": 47,
                    "preview_url": "https://p.scdn.co/mp3-preview    /f60463a71116a05979dec0aad6e5868cc21fa90a?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 7,
                    "type": "track",
                    "uri": "spotify:track:4zVyMSnXjxM734u4SQTqVx"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:05:05Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/22WZ7M8sxp5THdruNY3gXt"
                                },
                                "href": "https://api.spotify.com/v1/artists/22WZ7M8sxp5THdruNY3gXt",
                                "id": "22WZ7M8sxp5THdruNY3gXt",
                                "name": "The Doors",
                                "type": "artist",
                                "uri": "spotify:artist:22WZ7M8sxp5THdruNY3gXt"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/3zVyMAtWiXugudXuCRiUjL"
                        },
                        "href": "https://api.spotify.com/v1/albums/3zVyMAtWiXugudXuCRiUjL",
                        "id": "3zVyMAtWiXugudXuCRiUjL",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273d94d0fb4a7579c8e570bc7f8",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02d94d0fb4a7579c8e570bc7f8",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851d94d0fb4a7579c8e570bc7f8",
                                "width": 64
                            }
                        ],
                        "name": "The Doors (50th Anniversary Deluxe Edition)",
                        "release_date": "2017-03-31",
                        "release_date_precision": "day",
                        "total_tracks": 30,
                        "type": "album",
                        "uri": "spotify:album:3zVyMAtWiXugudXuCRiUjL"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/22WZ7M8sxp5THdruNY3gXt"
                            },
                            "href": "https://api.spotify.com/v1/artists/22WZ7M8sxp5THdruNY3gXt",
                            "id": "22WZ7M8sxp5THdruNY3gXt",
                            "name": "The Doors",
                            "type": "artist",
                            "uri": "spotify:artist:22WZ7M8sxp5THdruNY3gXt"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 430453,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USRH11605641"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/6l8BhUGXyQWFGWJY5tohDC"
                    },
                    "href": "https://api.spotify.com/v1/tracks/6l8BhUGXyQWFGWJY5tohDC",
                    "id": "6l8BhUGXyQWFGWJY5tohDC",
                    "is_local": false,
                    "name": "Light My Fire - 2017 Remaster",
                    "popularity": 40,
                    "preview_url": "https://p.scdn.co/mp3-preview    /97324f000558877e6dac70b453cefb7ae2da6323?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 6,
                    "type": "track",
                    "uri": "spotify:track:6l8BhUGXyQWFGWJY5tohDC"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:05:12Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "compilation",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/0f3EsoviYnRKTkmayI3cux"
                                },
                                "href": "https://api.spotify.com/v1/artists/0f3EsoviYnRKTkmayI3cux",
                                "id": "0f3EsoviYnRKTkmayI3cux",
                                "name": "Men At Work",
                                "type": "artist",
                                "uri": "spotify:artist:0f3EsoviYnRKTkmayI3cux"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/6GYIy1SuhPDrugCZ5yNeQy"
                        },
                        "href": "https://api.spotify.com/v1/albums/6GYIy1SuhPDrugCZ5yNeQy",
                        "id": "6GYIy1SuhPDrugCZ5yNeQy",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273d6a1f7a12629154fa274631f",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02d6a1f7a12629154fa274631f",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851d6a1f7a12629154fa274631f",
                                "width": 64
                            }
                        ],
                        "name": "The Best Of Men At Work: Contraband",
                        "release_date": "1996-02-01",
                        "release_date_precision": "day",
                        "total_tracks": 16,
                        "type": "album",
                        "uri": "spotify:album:6GYIy1SuhPDrugCZ5yNeQy"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/0f3EsoviYnRKTkmayI3cux"
                            },
                            "href": "https://api.spotify.com/v1/artists/0f3EsoviYnRKTkmayI3cux",
                            "id": "0f3EsoviYnRKTkmayI3cux",
                            "name": "Men At Work",
                            "type": "artist",
                            "uri": "spotify:artist:0f3EsoviYnRKTkmayI3cux"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 220866,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USSM18100058"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/46RVKt5Edm1zl0rXhPJZxz"
                    },
                    "href": "https://api.spotify.com/v1/tracks/46RVKt5Edm1zl0rXhPJZxz",
                    "id": "46RVKt5Edm1zl0rXhPJZxz",
                    "is_local": false,
                    "name": "Down Under",
                    "popularity": 73,
                    "preview_url": "https://p.scdn.co/mp3-preview    /e2a0e908126b04c92cf0f80c29242d46f2b45396?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 2,
                    "type": "track",
                    "uri": "spotify:track:46RVKt5Edm1zl0rXhPJZxz"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:05:21Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/2DaxqgrOhkeH0fpeiQq2f4"
                                },
                                "href": "https://api.spotify.com/v1/artists/2DaxqgrOhkeH0fpeiQq2f4",
                                "id": "2DaxqgrOhkeH0fpeiQq2f4",
                                "name": "Oasis",
                                "type": "artist",
                                "uri": "spotify:artist:2DaxqgrOhkeH0fpeiQq2f4"
                            }
                        ],
                        "available_markets": [
                            "AE",
                            "AR",
                            "AU",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DO",
                            "EC",
                            "EG",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IL",
                            "IN",
                            "IT",
                            "JO",
                            "KW",
                            "LB",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TR",
                            "TW",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/1VW1MFNstaJuygaoTPkdCk"
                        },
                        "href": "https://api.spotify.com/v1/albums/1VW1MFNstaJuygaoTPkdCk",
                        "id": "1VW1MFNstaJuygaoTPkdCk",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b27385e5dcc05cc216a10f141480",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e0285e5dcc05cc216a10f141480",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d0000485185e5dcc05cc216a10f141480",
                                "width": 64
                            }
                        ],
                        "name": "(What's The Story) Morning Glory? [Remastered]",
                        "release_date": "1995-10-02",
                        "release_date_precision": "day",
                        "total_tracks": 40,
                        "type": "album",
                        "uri": "spotify:album:1VW1MFNstaJuygaoTPkdCk"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/2DaxqgrOhkeH0fpeiQq2f4"
                            },
                            "href": "https://api.spotify.com/v1/artists/2DaxqgrOhkeH0fpeiQq2f4",
                            "id": "2DaxqgrOhkeH0fpeiQq2f4",
                            "name": "Oasis",
                            "type": "artist",
                            "uri": "spotify:artist:2DaxqgrOhkeH0fpeiQq2f4"
                        }
                    ],
                    "available_markets": [
                        "AE",
                        "AR",
                        "AU",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DO",
                        "EC",
                        "EG",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IL",
                        "IN",
                        "IT",
                        "JO",
                        "KW",
                        "LB",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TR",
                        "TW",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 258773,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBQCP1400109"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/5qqabIl2vWzo9ApSC317sa"
                    },
                    "href": "https://api.spotify.com/v1/tracks/5qqabIl2vWzo9ApSC317sa",
                    "id": "5qqabIl2vWzo9ApSC317sa",
                    "is_local": false,
                    "name": "Wonderwall - Remastered",
                    "popularity": 77,
                    "preview_url": "https://p.scdn.co/mp3-preview    /d012e536916c927bd6c8ced0dae75ee3b7715983?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 3,
                    "type": "track",
                    "uri": "spotify:track:5qqabIl2vWzo9ApSC317sa"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:05:31Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/3koiLjNrgRTNbOwViDipeA"
                                },
                                "href": "https://api.spotify.com/v1/artists/3koiLjNrgRTNbOwViDipeA",
                                "id": "3koiLjNrgRTNbOwViDipeA",
                                "name": "Marvin Gaye",
                                "type": "artist",
                                "uri": "spotify:artist:3koiLjNrgRTNbOwViDipeA"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/4gp6F03qAJCvKYoAGSrHVk"
                        },
                        "href": "https://api.spotify.com/v1/albums/4gp6F03qAJCvKYoAGSrHVk",
                        "id": "4gp6F03qAJCvKYoAGSrHVk",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2733d208b72327472664a0480e6",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e023d208b72327472664a0480e6",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048513d208b72327472664a0480e6",
                                "width": 64
                            }
                        ],
                        "name": "What's Going On - 40th Anniversary (Super Deluxe)",
                        "release_date": "1971-05-21",
                        "release_date_precision": "day",
                        "total_tracks": 46,
                        "type": "album",
                        "uri": "spotify:album:4gp6F03qAJCvKYoAGSrHVk"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/3koiLjNrgRTNbOwViDipeA"
                            },
                            "href": "https://api.spotify.com/v1/artists/3koiLjNrgRTNbOwViDipeA",
                            "id": "3koiLjNrgRTNbOwViDipeA",
                            "name": "Marvin Gaye",
                            "type": "artist",
                            "uri": "spotify:artist:3koiLjNrgRTNbOwViDipeA"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 232600,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USMO17100041"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/7av4raprzW2bWdjyAaH3hz"
                    },
                    "href": "https://api.spotify.com/v1/tracks/7av4raprzW2bWdjyAaH3hz",
                    "id": "7av4raprzW2bWdjyAaH3hz",
                    "is_local": false,
                    "name": "What's Going On    ",
                    "popularity": 3,
                    "preview_url": null,
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:7av4raprzW2bWdjyAaH3hz"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:05:39Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "compilation",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/1VcbchGlIfo3Gylxc3F076"
                                },
                                "href": "https://api.spotify.com/v1/artists/1VcbchGlIfo3Gylxc3F076",
                                "id": "1VcbchGlIfo3Gylxc3F076",
                                "name": "Cold Chisel",
                                "type": "artist",
                                "uri": "spotify:artist:1VcbchGlIfo3Gylxc3F076"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/1Htwv3I81HU6YUWWs0ommZ"
                        },
                        "href": "https://api.spotify.com/v1/albums/1Htwv3I81HU6YUWWs0ommZ",
                        "id": "1Htwv3I81HU6YUWWs0ommZ",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b27306dc40069e45da5e5d9f90e6",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e0206dc40069e45da5e5d9f90e6",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d0000485106dc40069e45da5e5d9f90e6",
                                "width": 64
                            }
                        ],
                        "name": "The Best of Cold Chisel - All for You",
                        "release_date": "2011-10-31",
                        "release_date_precision": "day",
                        "total_tracks": 20,
                        "type": "album",
                        "uri": "spotify:album:1Htwv3I81HU6YUWWs0ommZ"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/1VcbchGlIfo3Gylxc3F076"
                            },
                            "href": "https://api.spotify.com/v1/artists/1VcbchGlIfo3Gylxc3F076",
                            "id": "1VcbchGlIfo3Gylxc3F076",
                            "name": "Cold Chisel",
                            "type": "artist",
                            "uri": "spotify:artist:1VcbchGlIfo3Gylxc3F076"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 250669,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "TCABB1158215"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/04MGO8KdFKUcqQY3qVX0U4"
                    },
                    "href": "https://api.spotify.com/v1/tracks/04MGO8KdFKUcqQY3qVX0U4",
                    "id": "04MGO8KdFKUcqQY3qVX0U4",
                    "is_local": false,
                    "name": "Khe Sanh    ",
                    "popularity": 1,
                    "preview_url": null,
                    "track": true,
                    "track_number": 3,
                    "type": "track",
                    "uri": "spotify:track:04MGO8KdFKUcqQY3qVX0U4"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:05:59Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "compilation",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/1LZEQNv7sE11VDY3SdxQeN"
                                },
                                "href": "https://api.spotify.com/v1/artists/1LZEQNv7sE11VDY3SdxQeN",
                                "id": "1LZEQNv7sE11VDY3SdxQeN",
                                "name": "Bee Gees",
                                "type": "artist",
                                "uri": "spotify:artist:1LZEQNv7sE11VDY3SdxQeN"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/0rGrmrf9XKC54uU8VR5D2s"
                        },
                        "href": "https://api.spotify.com/v1/albums/0rGrmrf9XKC54uU8VR5D2s",
                        "id": "0rGrmrf9XKC54uU8VR5D2s",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2731d88e47464bbcec20fb92726",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e021d88e47464bbcec20fb92726",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048511d88e47464bbcec20fb92726",
                                "width": 64
                            }
                        ],
                        "name": "Tales From The Brothers Gibb",
                        "release_date": "1990-01-01",
                        "release_date_precision": "day",
                        "total_tracks": 74,
                        "type": "album",
                        "uri": "spotify:album:0rGrmrf9XKC54uU8VR5D2s"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/1LZEQNv7sE11VDY3SdxQeN"
                            },
                            "href": "https://api.spotify.com/v1/artists/1LZEQNv7sE11VDY3SdxQeN",
                            "id": "1LZEQNv7sE11VDY3SdxQeN",
                            "name": "Bee Gees",
                            "type": "artist",
                            "uri": "spotify:artist:1LZEQNv7sE11VDY3SdxQeN"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 3,
                    "duration_ms": 281666,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "NLF057790034"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/32NqW4lERGa0uTQLXeXh65"
                    },
                    "href": "https://api.spotify.com/v1/tracks/32NqW4lERGa0uTQLXeXh65",
                    "id": "32NqW4lERGa0uTQLXeXh65",
                    "is_local": false,
                    "name": "Stayin' Alive - From \"Saturday Night Fever\" Soundtrack    ",
                    "popularity": 1,
                    "preview_url": null,
                    "track": true,
                    "track_number": 9,
                    "type": "track",
                    "uri": "spotify:track:32NqW4lERGa0uTQLXeXh65"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:06:10Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/6vWDO969PvNqNYHIOW5v0m"
                                },
                                "href": "https://api.spotify.com/v1/artists/6vWDO969PvNqNYHIOW5v0m",
                                "id": "6vWDO969PvNqNYHIOW5v0m",
                                "name": "Beyoncé",
                                "type": "artist",
                                "uri": "spotify:artist:6vWDO969PvNqNYHIOW5v0m"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AR",
                            "AU",
                            "BG",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "ES",
                            "FI",
                            "FR",
                            "GR",
                            "GT",
                            "HN",
                            "HU",
                            "IE",
                            "IL",
                            "IS",
                            "IT",
                            "JP",
                            "LI",
                            "LT",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "NI",
                            "NO",
                            "NZ",
                            "PA",
                            "PE",
                            "PL",
                            "PT",
                            "PY",
                            "RO",
                            "SE",
                            "SK",
                            "SV",
                            "TN",
                            "TR",
                            "US",
                            "UY",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/39P7VD7qlg3Z0ltq60eHp7"
                        },
                        "href": "https://api.spotify.com/v1/albums/39P7VD7qlg3Z0ltq60eHp7",
                        "id": "39P7VD7qlg3Z0ltq60eHp7",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273801c4d205accdba0a468a10b",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02801c4d205accdba0a468a10b",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851801c4d205accdba0a468a10b",
                                "width": 64
                            }
                        ],
                        "name": "I AM...SASHA FIERCE",
                        "release_date": "2008-11-17",
                        "release_date_precision": "day",
                        "total_tracks": 11,
                        "type": "album",
                        "uri": "spotify:album:39P7VD7qlg3Z0ltq60eHp7"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/6vWDO969PvNqNYHIOW5v0m"
                            },
                            "href": "https://api.spotify.com/v1/artists/6vWDO969PvNqNYHIOW5v0m",
                            "id": "6vWDO969PvNqNYHIOW5v0m",
                            "name": "Beyoncé",
                            "type": "artist",
                            "uri": "spotify:artist:6vWDO969PvNqNYHIOW5v0m"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AR",
                        "AU",
                        "BG",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "ES",
                        "FI",
                        "FR",
                        "GR",
                        "GT",
                        "HN",
                        "HU",
                        "IE",
                        "IL",
                        "IS",
                        "IT",
                        "JP",
                        "LI",
                        "LT",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "NI",
                        "NO",
                        "NZ",
                        "PA",
                        "PE",
                        "PL",
                        "PT",
                        "PY",
                        "RO",
                        "SE",
                        "SK",
                        "SV",
                        "TN",
                        "TR",
                        "US",
                        "UY",
                        "ZA"
                    ],
                    "disc_number": 2,
                    "duration_ms": 193213,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USSM10803760"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/5R9a4t5t5O0IsznsrKPVro"
                    },
                    "href": "https://api.spotify.com/v1/tracks/5R9a4t5t5O0IsznsrKPVro",
                    "id": "5R9a4t5t5O0IsznsrKPVro",
                    "is_local": false,
                    "name": "Single Ladies (Put a Ring on It)",
                    "popularity": 69,
                    "preview_url": "https://p.scdn.co/mp3-preview    /69c8bae97df9121ee440b23053fe20f64c204408?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:5R9a4t5t5O0IsznsrKPVro"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:06:19Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "compilation",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/0LyfQWJT6nXafLPZqxe9Of"
                                },
                                "href": "https://api.spotify.com/v1/artists/0LyfQWJT6nXafLPZqxe9Of",
                                "id": "0LyfQWJT6nXafLPZqxe9Of",
                                "name": "Various Artists",
                                "type": "artist",
                                "uri": "spotify:artist:0LyfQWJT6nXafLPZqxe9Of"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BO",
                            "BR",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "ES",
                            "FI",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JP",
                            "KW",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MC",
                            "MT",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "RO",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TR",
                            "TW",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/1PDvi5uU71NCpZ7TPdcl6B"
                        },
                        "href": "https://api.spotify.com/v1/albums/1PDvi5uU71NCpZ7TPdcl6B",
                        "id": "1PDvi5uU71NCpZ7TPdcl6B",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273e36423c91e3c6f248a03aee4",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02e36423c91e3c6f248a03aee4",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851e36423c91e3c6f248a03aee4",
                                "width": 64
                            }
                        ],
                        "name": "Virgin Records: 40 Years Of Disruptions",
                        "release_date": "2013-01-01",
                        "release_date_precision": "day",
                        "total_tracks": 46,
                        "type": "album",
                        "uri": "spotify:album:1PDvi5uU71NCpZ7TPdcl6B"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/0uq5PttqEjj3IH1bzwcrXF"
                            },
                            "href": "https://api.spotify.com/v1/artists/0uq5PttqEjj3IH1bzwcrXF",
                            "id": "0uq5PttqEjj3IH1bzwcrXF",
                            "name": "Spice Girls",
                            "type": "artist",
                            "uri": "spotify:artist:0uq5PttqEjj3IH1bzwcrXF"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BO",
                        "BR",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "ES",
                        "FI",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JP",
                        "KW",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MC",
                        "MT",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "RO",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TR",
                        "TW",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 2,
                    "duration_ms": 172720,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBAAA9600008"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/0n6FMFq5bE22tNTmd6L9U4"
                    },
                    "href": "https://api.spotify.com/v1/tracks/0n6FMFq5bE22tNTmd6L9U4",
                    "id": "0n6FMFq5bE22tNTmd6L9U4",
                    "is_local": false,
                    "name": "Wannabe",
                    "popularity": 48,
                    "preview_url": "https://p.scdn.co/mp3-preview    /bfc927e3387d3e8f8e8f9120b9e78a314582e208?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 5,
                    "type": "track",
                    "uri": "spotify:track:0n6FMFq5bE22tNTmd6L9U4"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:06:30Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/7guDJrEfX3qb6FEbdPA5qi"
                                },
                                "href": "https://api.spotify.com/v1/artists/7guDJrEfX3qb6FEbdPA5qi",
                                "id": "7guDJrEfX3qb6FEbdPA5qi",
                                "name": "Stevie Wonder",
                                "type": "artist",
                                "uri": "spotify:artist:7guDJrEfX3qb6FEbdPA5qi"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/7vgpBNK5xPmS3Mu2Hl9O0D"
                        },
                        "href": "https://api.spotify.com/v1/albums/7vgpBNK5xPmS3Mu2Hl9O0D",
                        "id": "7vgpBNK5xPmS3Mu2Hl9O0D",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2738d800b13a88d5502dd022775",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e028d800b13a88d5502dd022775",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048518d800b13a88d5502dd022775",
                                "width": 64
                            }
                        ],
                        "name": "Talking Book (Reissue)",
                        "release_date": "1972-10-28",
                        "release_date_precision": "day",
                        "total_tracks": 10,
                        "type": "album",
                        "uri": "spotify:album:7vgpBNK5xPmS3Mu2Hl9O0D"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/7guDJrEfX3qb6FEbdPA5qi"
                            },
                            "href": "https://api.spotify.com/v1/artists/7guDJrEfX3qb6FEbdPA5qi",
                            "id": "7guDJrEfX3qb6FEbdPA5qi",
                            "name": "Stevie Wonder",
                            "type": "artist",
                            "uri": "spotify:artist:7guDJrEfX3qb6FEbdPA5qi"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 266160,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USMO17200984"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/1kryOQS9FQDsbYY4db5zS5"
                    },
                    "href": "https://api.spotify.com/v1/tracks/1kryOQS9FQDsbYY4db5zS5",
                    "id": "1kryOQS9FQDsbYY4db5zS5",
                    "is_local": false,
                    "name": "Superstition    ",
                    "popularity": 0,
                    "preview_url": null,
                    "track": true,
                    "track_number": 6,
                    "type": "track",
                    "uri": "spotify:track:1kryOQS9FQDsbYY4db5zS5"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:06:44Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/4RVnAU35WRWra6OZ3CbbMA"
                                },
                                "href": "https://api.spotify.com/v1/artists/4RVnAU35WRWra6OZ3CbbMA",
                                "id": "4RVnAU35WRWra6OZ3CbbMA",
                                "name": "Kylie Minogue",
                                "type": "artist",
                                "uri": "spotify:artist:4RVnAU35WRWra6OZ3CbbMA"
                            }
                        ],
                        "available_markets": [
                            "AU",
                            "NZ"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/6FTq1YhYJLetfJQrq02gdv"
                        },
                        "href": "https://api.spotify.com/v1/albums/6FTq1YhYJLetfJQrq02gdv",
                        "id": "6FTq1YhYJLetfJQrq02gdv",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273c2f18ddba993ab67b989bcb8",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02c2f18ddba993ab67b989bcb8",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851c2f18ddba993ab67b989bcb8",
                                "width": 64
                            }
                        ],
                        "name": "Fever",
                        "release_date": "2001",
                        "release_date_precision": "year",
                        "total_tracks": 13,
                        "type": "album",
                        "uri": "spotify:album:6FTq1YhYJLetfJQrq02gdv"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/4RVnAU35WRWra6OZ3CbbMA"
                            },
                            "href": "https://api.spotify.com/v1/artists/4RVnAU35WRWra6OZ3CbbMA",
                            "id": "4RVnAU35WRWra6OZ3CbbMA",
                            "name": "Kylie Minogue",
                            "type": "artist",
                            "uri": "spotify:artist:4RVnAU35WRWra6OZ3CbbMA"
                        }
                    ],
                    "available_markets": [
                        "AU",
                        "NZ"
                    ],
                    "disc_number": 1,
                    "duration_ms": 230640,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBAYE0100913"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/7m2g1kKuF7Tre2PzjK3Lnh"
                    },
                    "href": "https://api.spotify.com/v1/tracks/7m2g1kKuF7Tre2PzjK3Lnh",
                    "id": "7m2g1kKuF7Tre2PzjK3Lnh",
                    "is_local": false,
                    "name": "Can't Get You out of My Head",
                    "popularity": 55,
                    "preview_url": "https://p.scdn.co/mp3-preview    /8698fb43a16503ad290e738649a19d1663b9cbc6?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 3,
                    "type": "track",
                    "uri": "spotify:track:7m2g1kKuF7Tre2PzjK3Lnh"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:06:52Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/0L8ExT028jH3ddEcZwqJJ5"
                                },
                                "href": "https://api.spotify.com/v1/artists/0L8ExT028jH3ddEcZwqJJ5",
                                "id": "0L8ExT028jH3ddEcZwqJJ5",
                                "name": "Red Hot Chili Peppers",
                                "type": "artist",
                                "uri": "spotify:artist:0L8ExT028jH3ddEcZwqJJ5"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/30Perjew8HyGkdSmqguYyg"
                        },
                        "href": "https://api.spotify.com/v1/albums/30Perjew8HyGkdSmqguYyg",
                        "id": "30Perjew8HyGkdSmqguYyg",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273153d79816d853f2694b2cc70",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02153d79816d853f2694b2cc70",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851153d79816d853f2694b2cc70",
                                "width": 64
                            }
                        ],
                        "name": "Blood Sugar Sex Magik (Deluxe Edition)",
                        "release_date": "1991-09-24",
                        "release_date_precision": "day",
                        "total_tracks": 19,
                        "type": "album",
                        "uri": "spotify:album:30Perjew8HyGkdSmqguYyg"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/0L8ExT028jH3ddEcZwqJJ5"
                            },
                            "href": "https://api.spotify.com/v1/artists/0L8ExT028jH3ddEcZwqJJ5",
                            "id": "0L8ExT028jH3ddEcZwqJJ5",
                            "name": "Red Hot Chili Peppers",
                            "type": "artist",
                            "uri": "spotify:artist:0L8ExT028jH3ddEcZwqJJ5"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 264306,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USWB19901576"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/3d9DChrdc6BOeFsbrZ3Is0"
                    },
                    "href": "https://api.spotify.com/v1/tracks/3d9DChrdc6BOeFsbrZ3Is0",
                    "id": "3d9DChrdc6BOeFsbrZ3Is0",
                    "is_local": false,
                    "name": "Under the Bridge",
                    "popularity": 81,
                    "preview_url": "https://p.scdn.co/mp3-preview/    90e41778392f27b6f7dd82db4c90916b3727aa6a?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 11,
                    "type": "track",
                    "uri": "spotify:track:3d9DChrdc6BOeFsbrZ3Is0"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:07:00Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/7dnB1wSxbYa8CejeVg98hz"
                                },
                                "href": "https://api.spotify.com/v1/artists/7dnB1wSxbYa8CejeVg98hz",
                                "id": "7dnB1wSxbYa8CejeVg98hz",
                                "name": "Meat Loaf",
                                "type": "artist",
                                "uri": "spotify:artist:7dnB1wSxbYa8CejeVg98hz"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/6mvI80w5r78niBmwtu7RF9"
                        },
                        "href": "https://api.spotify.com/v1/albums/6mvI80w5r78niBmwtu7RF9",
                        "id": "6mvI80w5r78niBmwtu7RF9",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2734111af27787499f6d8752e9f",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e024111af27787499f6d8752e9f",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048514111af27787499f6d8752e9f",
                                "width": 64
                            }
                        ],
                        "name": "Bat Out Of Hell",
                        "release_date": "1977-10-21",
                        "release_date_precision": "day",
                        "total_tracks": 7,
                        "type": "album",
                        "uri": "spotify:album:6mvI80w5r78niBmwtu7RF9"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/7dnB1wSxbYa8CejeVg98hz"
                            },
                            "href": "https://api.spotify.com/v1/artists/7dnB1wSxbYa8CejeVg98hz",
                            "id": "7dnB1wSxbYa8CejeVg98hz",
                            "name": "Meat Loaf",
                            "type": "artist",
                            "uri": "spotify:artist:7dnB1wSxbYa8CejeVg98hz"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 304440,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USSM11206825"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/7wawEkN4nhPqSBWleGvdxa"
                    },
                    "href": "https://api.spotify.com/v1/tracks/7wawEkN4nhPqSBWleGvdxa",
                    "id": "7wawEkN4nhPqSBWleGvdxa",
                    "is_local": false,
                    "name": "You Took The Words Right Out of My Mouth (Hot Summer Night)",
                    "popularity": 58,
                    "preview_url": "https://p.scdn.co/mp3-preview    /6e60bded7b4a19105038da5d53e9cf995b0277dd?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 2,
                    "type": "track",
                    "uri": "spotify:track:7wawEkN4nhPqSBWleGvdxa"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:07:08Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/6kz53iCdBSqhQCZ21CoLcc"
                                },
                                "href": "https://api.spotify.com/v1/artists/6kz53iCdBSqhQCZ21CoLcc",
                                "id": "6kz53iCdBSqhQCZ21CoLcc",
                                "name": "Culture Club",
                                "type": "artist",
                                "uri": "spotify:artist:6kz53iCdBSqhQCZ21CoLcc"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/0VgBqlPrvUQsOqSwzA0fET"
                        },
                        "href": "https://api.spotify.com/v1/albums/0VgBqlPrvUQsOqSwzA0fET",
                        "id": "0VgBqlPrvUQsOqSwzA0fET",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273784f3d22b1b28313311acd2a",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02784f3d22b1b28313311acd2a",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851784f3d22b1b28313311acd2a",
                                "width": 64
                            }
                        ],
                        "name": "Colour By Numbers",
                        "release_date": "1983-10-01",
                        "release_date_precision": "day",
                        "total_tracks": 10,
                        "type": "album",
                        "uri": "spotify:album:0VgBqlPrvUQsOqSwzA0fET"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/6kz53iCdBSqhQCZ21CoLcc"
                            },
                            "href": "https://api.spotify.com/v1/artists/6kz53iCdBSqhQCZ21CoLcc",
                            "id": "6kz53iCdBSqhQCZ21CoLcc",
                            "name": "Culture Club",
                            "type": "artist",
                            "uri": "spotify:artist:6kz53iCdBSqhQCZ21CoLcc"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 252760,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBAAA8300010"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/3XDeeP9wBZzGhIPZmLfEEx"
                    },
                    "href": "https://api.spotify.com/v1/tracks/3XDeeP9wBZzGhIPZmLfEEx",
                    "id": "3XDeeP9wBZzGhIPZmLfEEx",
                    "is_local": false,
                    "name": "Karma Chameleon",
                    "popularity": 61,
                    "preview_url": "https://p.scdn.co/mp3-preview    /f3736b3acecd13a8b343e844e56ea03f26e3710f?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:3XDeeP9wBZzGhIPZmLfEEx"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:07:20Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "single",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/2HcwFjNelS49kFbfvMxQYw"
                                },
                                "href": "https://api.spotify.com/v1/artists/2HcwFjNelS49kFbfvMxQYw",
                                "id": "2HcwFjNelS49kFbfvMxQYw",
                                "name": "Robbie Williams",
                                "type": "artist",
                                "uri": "spotify:artist:2HcwFjNelS49kFbfvMxQYw"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/15lwLTwByJddohg3GvxICy"
                        },
                        "href": "https://api.spotify.com/v1/albums/15lwLTwByJddohg3GvxICy",
                        "id": "15lwLTwByJddohg3GvxICy",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2734ac63692f6efafa9d8e4e4e8",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e024ac63692f6efafa9d8e4e4e8",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048514ac63692f6efafa9d8e4e4e8",
                                "width": 64
                            }
                        ],
                        "name": "Angels",
                        "release_date": "1997-01-01",
                        "release_date_precision": "day",
                        "total_tracks": 4,
                        "type": "album",
                        "uri": "spotify:album:15lwLTwByJddohg3GvxICy"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/2HcwFjNelS49kFbfvMxQYw"
                            },
                            "href": "https://api.spotify.com/v1/artists/2HcwFjNelS49kFbfvMxQYw",
                            "id": "2HcwFjNelS49kFbfvMxQYw",
                            "name": "Robbie Williams",
                            "type": "artist",
                            "uri": "spotify:artist:2HcwFjNelS49kFbfvMxQYw"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 265333,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBAYE9700233"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/7CKbqqrs0AS1si1ZgaQdcj"
                    },
                    "href": "https://api.spotify.com/v1/tracks/7CKbqqrs0AS1si1ZgaQdcj",
                    "id": "7CKbqqrs0AS1si1ZgaQdcj",
                    "is_local": false,
                    "name": "Angels",
                    "popularity": 63,
                    "preview_url": "https://p.scdn.co/mp3-preview    /7d28db54db7f02b654dfc415efb5f1d51c3f8b5a?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:7CKbqqrs0AS1si1ZgaQdcj"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:07:29Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/08GQAI4eElDnROBrJRGE0X"
                                },
                                "href": "https://api.spotify.com/v1/artists/08GQAI4eElDnROBrJRGE0X",
                                "id": "08GQAI4eElDnROBrJRGE0X",
                                "name": "Fleetwood Mac",
                                "type": "artist",
                                "uri": "spotify:artist:08GQAI4eElDnROBrJRGE0X"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/5VIQ3VaAoRKOEpJ0fewdvo"
                        },
                        "href": "https://api.spotify.com/v1/albums/5VIQ3VaAoRKOEpJ0fewdvo",
                        "id": "5VIQ3VaAoRKOEpJ0fewdvo",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2734fb043195e8d07e72edc7226",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e024fb043195e8d07e72edc7226",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048514fb043195e8d07e72edc7226",
                                "width": 64
                            }
                        ],
                        "name": "Fleetwood Mac",
                        "release_date": "1975-07-11",
                        "release_date_precision": "day",
                        "total_tracks": 11,
                        "type": "album",
                        "uri": "spotify:album:5VIQ3VaAoRKOEpJ0fewdvo"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/08GQAI4eElDnROBrJRGE0X"
                            },
                            "href": "https://api.spotify.com/v1/artists/08GQAI4eElDnROBrJRGE0X",
                            "id": "08GQAI4eElDnROBrJRGE0X",
                            "name": "Fleetwood Mac",
                            "type": "artist",
                            "uri": "spotify:artist:08GQAI4eElDnROBrJRGE0X"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 252773,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USWB19900188"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/05oETzWbd4SI33qK2gbJfR"
                    },
                    "href": "https://api.spotify.com/v1/tracks/05oETzWbd4SI33qK2gbJfR",
                    "id": "05oETzWbd4SI33qK2gbJfR",
                    "is_local": false,
                    "name": "Rhiannon",
                    "popularity": 69,
                    "preview_url": "https://p.scdn.co/mp3-preview    /bbe6f2993487401609cb53dcfcd74ac2b17a472d?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 4,
                    "type": "track",
                    "uri": "spotify:track:05oETzWbd4SI33qK2gbJfR"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:07:41Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/2ye2Wgw4gimLv2eAKyk1NB"
                                },
                                "href": "https://api.spotify.com/v1/artists/2ye2Wgw4gimLv2eAKyk1NB",
                                "id": "2ye2Wgw4gimLv2eAKyk1NB",
                                "name": "Metallica",
                                "type": "artist",
                                "uri": "spotify:artist:2ye2Wgw4gimLv2eAKyk1NB"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/3A4zAmE5c4dUAAqEJz6hCH"
                        },
                        "href": "https://api.spotify.com/v1/albums/3A4zAmE5c4dUAAqEJz6hCH",
                        "id": "3A4zAmE5c4dUAAqEJz6hCH",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273aeef6d1f525548aabcea0f6e",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02aeef6d1f525548aabcea0f6e",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851aeef6d1f525548aabcea0f6e",
                                "width": 64
                            }
                        ],
                        "name": "Metallica",
                        "release_date": "1991-01-01",
                        "release_date_precision": "day",
                        "total_tracks": 12,
                        "type": "album",
                        "uri": "spotify:album:3A4zAmE5c4dUAAqEJz6hCH"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/2ye2Wgw4gimLv2eAKyk1NB"
                            },
                            "href": "https://api.spotify.com/v1/artists/2ye2Wgw4gimLv2eAKyk1NB",
                            "id": "2ye2Wgw4gimLv2eAKyk1NB",
                            "name": "Metallica",
                            "type": "artist",
                            "uri": "spotify:artist:2ye2Wgw4gimLv2eAKyk1NB"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 331266,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBF089190013"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/1bdXMstfxFWYSkEFTnJMoN"
                    },
                    "href": "https://api.spotify.com/v1/tracks/1bdXMstfxFWYSkEFTnJMoN",
                    "id": "1bdXMstfxFWYSkEFTnJMoN",
                    "is_local": false,
                    "name": "Enter Sandman    ",
                    "popularity": 3,
                    "preview_url": null,
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:1bdXMstfxFWYSkEFTnJMoN"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:07:53Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/43ZHCT0cAZBISjO8DG9PnE"
                                },
                                "href": "https://api.spotify.com/v1/artists/43ZHCT0cAZBISjO8DG9PnE",
                                "id": "43ZHCT0cAZBISjO8DG9PnE",
                                "name": "Elvis Presley",
                                "type": "artist",
                                "uri": "spotify:artist:43ZHCT0cAZBISjO8DG9PnE"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/0C3t1htEDTFKcg7F2rNbek"
                        },
                        "href": "https://api.spotify.com/v1/albums/0C3t1htEDTFKcg7F2rNbek",
                        "id": "0C3t1htEDTFKcg7F2rNbek",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b27320ee3e86e17f17239bef1f76",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e0220ee3e86e17f17239bef1f76",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d0000485120ee3e86e17f17239bef1f76",
                                "width": 64
                            }
                        ],
                        "name": "Elvis' Golden Records",
                        "release_date": "1958-03-21",
                        "release_date_precision": "day",
                        "total_tracks": 14,
                        "type": "album",
                        "uri": "spotify:album:0C3t1htEDTFKcg7F2rNbek"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/43ZHCT0cAZBISjO8DG9PnE"
                            },
                            "href": "https://api.spotify.com/v1/artists/43ZHCT0cAZBISjO8DG9PnE",
                            "id": "43ZHCT0cAZBISjO8DG9PnE",
                            "name": "Elvis Presley",
                            "type": "artist",
                            "uri": "spotify:artist:43ZHCT0cAZBISjO8DG9PnE"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 122893,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USRC15602859"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/01u6AEzGbGbQyYVdxajxqk"
                    },
                    "href": "https://api.spotify.com/v1/tracks/01u6AEzGbGbQyYVdxajxqk",
                    "id": "01u6AEzGbGbQyYVdxajxqk",
                    "is_local": false,
                    "name": "Don't Be Cruel",
                    "popularity": 61,
                    "preview_url": "https://p.scdn.co/mp3-preview    /55f71e5caaccf649dd8c1ab9742cd0c09e1e65e7?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 8,
                    "type": "track",
                    "uri": "spotify:track:01u6AEzGbGbQyYVdxajxqk"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:08:02Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/1eClJfHLoDI4rZe5HxzBFv"
                                },
                                "href": "https://api.spotify.com/v1/artists/1eClJfHLoDI4rZe5HxzBFv",
                                "id": "1eClJfHLoDI4rZe5HxzBFv",
                                "name": "INXS",
                                "type": "artist",
                                "uri": "spotify:artist:1eClJfHLoDI4rZe5HxzBFv"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/7CJvhqb2PJq5fBcY6eKqjl"
                        },
                        "href": "https://api.spotify.com/v1/albums/7CJvhqb2PJq5fBcY6eKqjl",
                        "id": "7CJvhqb2PJq5fBcY6eKqjl",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273114b2baa75317b81a8c9c7ca",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02114b2baa75317b81a8c9c7ca",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851114b2baa75317b81a8c9c7ca",
                                "width": 64
                            }
                        ],
                        "name": "INXS Remastered",
                        "release_date": "2011-01-01",
                        "release_date_precision": "day",
                        "total_tracks": 110,
                        "type": "album",
                        "uri": "spotify:album:7CJvhqb2PJq5fBcY6eKqjl"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/1eClJfHLoDI4rZe5HxzBFv"
                            },
                            "href": "https://api.spotify.com/v1/artists/1eClJfHLoDI4rZe5HxzBFv",
                            "id": "1eClJfHLoDI4rZe5HxzBFv",
                            "name": "INXS",
                            "type": "artist",
                            "uri": "spotify:artist:1eClJfHLoDI4rZe5HxzBFv"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 6,
                    "duration_ms": 181106,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBAMX8700008"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/1sR4aKaHpLrc9u7g4ii90U"
                    },
                    "href": "https://api.spotify.com/v1/tracks/1sR4aKaHpLrc9u7g4ii90U",
                    "id": "1sR4aKaHpLrc9u7g4ii90U",
                    "is_local": false,
                    "name": "Need You Tonight",
                    "popularity": 60,
                    "preview_url": "https://p.scdn.co/mp3-preview    /61b17a335d5afc1c4086b1b08e2400f0da147977?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 4,
                    "type": "track",
                    "uri": "spotify:track:1sR4aKaHpLrc9u7g4ii90U"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:08:14Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/0oSGxfWSnnOXhD2fKuz2Gy"
                                },
                                "href": "https://api.spotify.com/v1/artists/0oSGxfWSnnOXhD2fKuz2Gy",
                                "id": "0oSGxfWSnnOXhD2fKuz2Gy",
                                "name": "David Bowie",
                                "type": "artist",
                                "uri": "spotify:artist:0oSGxfWSnnOXhD2fKuz2Gy"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/1ay9Z4R5ZYI2TY7WiDhNYQ"
                        },
                        "href": "https://api.spotify.com/v1/albums/1ay9Z4R5ZYI2TY7WiDhNYQ",
                        "id": "1ay9Z4R5ZYI2TY7WiDhNYQ",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273614c5f63afef27e4dfa9f596",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02614c5f63afef27e4dfa9f596",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851614c5f63afef27e4dfa9f596",
                                "width": 64
                            }
                        ],
                        "name": "David Bowie (aka Space Oddity) [2015 Remaster]",
                        "release_date": "1969-11-04",
                        "release_date_precision": "day",
                        "total_tracks": 9,
                        "type": "album",
                        "uri": "spotify:album:1ay9Z4R5ZYI2TY7WiDhNYQ"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/0oSGxfWSnnOXhD2fKuz2Gy"
                            },
                            "href": "https://api.spotify.com/v1/artists/0oSGxfWSnnOXhD2fKuz2Gy",
                            "id": "0oSGxfWSnnOXhD2fKuz2Gy",
                            "name": "David Bowie",
                            "type": "artist",
                            "uri": "spotify:artist:0oSGxfWSnnOXhD2fKuz2Gy"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 318813,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USJT11500173"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/72Z17vmmeQKAg8bptWvpVG"
                    },
                    "href": "https://api.spotify.com/v1/tracks/72Z17vmmeQKAg8bptWvpVG",
                    "id": "72Z17vmmeQKAg8bptWvpVG",
                    "is_local": false,
                    "name": "Space Oddity - 2015 Remaster",
                    "popularity": 73,
                    "preview_url": "https://p.scdn.co/mp3-preview    /b39f0ae16451e7aca47dec309ea7d55aad607b8e?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:72Z17vmmeQKAg8bptWvpVG"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:08:23Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/3nnQpaTvKb5jCQabZefACI"
                                },
                                "href": "https://api.spotify.com/v1/artists/3nnQpaTvKb5jCQabZefACI",
                                "id": "3nnQpaTvKb5jCQabZefACI",
                                "name": "Jeff Buckley",
                                "type": "artist",
                                "uri": "spotify:artist:3nnQpaTvKb5jCQabZefACI"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/07Fr36M0hRPJrSJMFWGnvD"
                        },
                        "href": "https://api.spotify.com/v1/albums/07Fr36M0hRPJrSJMFWGnvD",
                        "id": "07Fr36M0hRPJrSJMFWGnvD",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273c9e961be2679c41930a370cd",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02c9e961be2679c41930a370cd",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851c9e961be2679c41930a370cd",
                                "width": 64
                            }
                        ],
                        "name": "Grace (Legacy Edition)",
                        "release_date": "1994",
                        "release_date_precision": "year",
                        "total_tracks": 22,
                        "type": "album",
                        "uri": "spotify:album:07Fr36M0hRPJrSJMFWGnvD"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/3nnQpaTvKb5jCQabZefACI"
                            },
                            "href": "https://api.spotify.com/v1/artists/3nnQpaTvKb5jCQabZefACI",
                            "id": "3nnQpaTvKb5jCQabZefACI",
                            "name": "Jeff Buckley",
                            "type": "artist",
                            "uri": "spotify:artist:3nnQpaTvKb5jCQabZefACI"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 275493,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USSM19400913"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/4xqw8JSmfNdHLCuT23pHiv"
                    },
                    "href": "https://api.spotify.com/v1/tracks/4xqw8JSmfNdHLCuT23pHiv",
                    "id": "4xqw8JSmfNdHLCuT23pHiv",
                    "is_local": false,
                    "name": "Last Goodbye    ",
                    "popularity": 2,
                    "preview_url": null,
                    "track": true,
                    "track_number": 3,
                    "type": "track",
                    "uri": "spotify:track:4xqw8JSmfNdHLCuT23pHiv"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:08:36Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/2BTZIqw0ntH9MvilQ3ewNY"
                                },
                                "href": "https://api.spotify.com/v1/artists/2BTZIqw0ntH9MvilQ3ewNY",
                                "id": "2BTZIqw0ntH9MvilQ3ewNY",
                                "name": "Cyndi Lauper",
                                "type": "artist",
                                "uri": "spotify:artist:2BTZIqw0ntH9MvilQ3ewNY"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/4pox3k0CGuwwAknR9GtcoX"
                        },
                        "href": "https://api.spotify.com/v1/albums/4pox3k0CGuwwAknR9GtcoX",
                        "id": "4pox3k0CGuwwAknR9GtcoX",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273681265e351fc75e60d0fa50b",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02681265e351fc75e60d0fa50b",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851681265e351fc75e60d0fa50b",
                                "width": 64
                            }
                        ],
                        "name": "She's So Unusual: A 30th Anniversary Celebration (Deluxe Edition)",
                        "release_date": "2014-03-28",
                        "release_date_precision": "day",
                        "total_tracks": 22,
                        "type": "album",
                        "uri": "spotify:album:4pox3k0CGuwwAknR9GtcoX"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/2BTZIqw0ntH9MvilQ3ewNY"
                            },
                            "href": "https://api.spotify.com/v1/artists/2BTZIqw0ntH9MvilQ3ewNY",
                            "id": "2BTZIqw0ntH9MvilQ3ewNY",
                            "name": "Cyndi Lauper",
                            "type": "artist",
                            "uri": "spotify:artist:2BTZIqw0ntH9MvilQ3ewNY"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 238120,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USSM18300548"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/2zjt2hHBbiv5SuxYg8Z7eP"
                    },
                    "href": "https://api.spotify.com/v1/tracks/2zjt2hHBbiv5SuxYg8Z7eP",
                    "id": "2zjt2hHBbiv5SuxYg8Z7eP",
                    "is_local": false,
                    "name": "Girls Just Want to Have Fun",
                    "popularity": 67,
                    "preview_url": "https://p.scdn.co/mp3-preview    /6bee4180ef21c7badcfae3293ce3427c2e2dfa37?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 2,
                    "type": "track",
                    "uri": "spotify:track:2zjt2hHBbiv5SuxYg8Z7eP"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:08:49Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/0k17h0D3J5VfsdmQ1iZtE9"
                                },
                                "href": "https://api.spotify.com/v1/artists/0k17h0D3J5VfsdmQ1iZtE9",
                                "id": "0k17h0D3J5VfsdmQ1iZtE9",
                                "name": "Pink Floyd",
                                "type": "artist",
                                "uri": "spotify:artist:0k17h0D3J5VfsdmQ1iZtE9"
                            }
                        ],
                        "available_markets": [
                            "AE",
                            "AR",
                            "AU",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CL",
                            "CO",
                            "CR",
                            "DO",
                            "EC",
                            "EG",
                            "GT",
                            "HK",
                            "HN",
                            "ID",
                            "IL",
                            "IN",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "MX",
                            "MY",
                            "NI",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PS",
                            "PY",
                            "QA",
                            "SA",
                            "SG",
                            "SV",
                            "TH",
                            "TN",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/5Dbax7G8SWrP9xyzkOvy2F"
                        },
                        "href": "https://api.spotify.com/v1/albums/5Dbax7G8SWrP9xyzkOvy2F",
                        "id": "5Dbax7G8SWrP9xyzkOvy2F",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273288d32d88a616b9a278ddc07",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02288d32d88a616b9a278ddc07",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851288d32d88a616b9a278ddc07",
                                "width": 64
                            }
                        ],
                        "name": "The Wall",
                        "release_date": "1979-11-30",
                        "release_date_precision": "day",
                        "total_tracks": 26,
                        "type": "album",
                        "uri": "spotify:album:5Dbax7G8SWrP9xyzkOvy2F"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/0k17h0D3J5VfsdmQ1iZtE9"
                            },
                            "href": "https://api.spotify.com/v1/artists/0k17h0D3J5VfsdmQ1iZtE9",
                            "id": "0k17h0D3J5VfsdmQ1iZtE9",
                            "name": "Pink Floyd",
                            "type": "artist",
                            "uri": "spotify:artist:0k17h0D3J5VfsdmQ1iZtE9"
                        }
                    ],
                    "available_markets": [
                        "AE",
                        "AR",
                        "AU",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CL",
                        "CO",
                        "CR",
                        "DO",
                        "EC",
                        "EG",
                        "GT",
                        "HK",
                        "HN",
                        "ID",
                        "IL",
                        "IN",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "MX",
                        "MY",
                        "NI",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PS",
                        "PY",
                        "QA",
                        "SA",
                        "SG",
                        "SV",
                        "TH",
                        "TN",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 238746,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBN9Y1100099"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/4gMgiXfqyzZLMhsksGmbQV"
                    },
                    "href": "https://api.spotify.com/v1/tracks/4gMgiXfqyzZLMhsksGmbQV",
                    "id": "4gMgiXfqyzZLMhsksGmbQV",
                    "is_local": false,
                    "name": "Another Brick in the Wall, Pt. 2",
                    "popularity": 76,
                    "preview_url": "https://p.scdn.co/mp3-preview    /92210b01fcc6efa80008663c158baf79cf0d7b5f?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 5,
                    "type": "track",
                    "uri": "spotify:track:4gMgiXfqyzZLMhsksGmbQV"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:09:01Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "compilation",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/5sHPYevv4ykaH79HIHqBDP"
                                },
                                "href": "https://api.spotify.com/v1/artists/5sHPYevv4ykaH79HIHqBDP",
                                "id": "5sHPYevv4ykaH79HIHqBDP",
                                "name": "Yothu Yindi",
                                "type": "artist",
                                "uri": "spotify:artist:5sHPYevv4ykaH79HIHqBDP"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/4KqHJrKDQGRgXSXWajwJVI"
                        },
                        "href": "https://api.spotify.com/v1/albums/4KqHJrKDQGRgXSXWajwJVI",
                        "id": "4KqHJrKDQGRgXSXWajwJVI",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b27314e3b5478737117a5e2fee2b",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e0214e3b5478737117a5e2fee2b",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d0000485114e3b5478737117a5e2fee2b",
                                "width": 64
                            }
                        ],
                        "name": "Healing Stone - The Best of Yothu Yindi",
                        "release_date": "2012-11-30",
                        "release_date_precision": "day",
                        "total_tracks": 17,
                        "type": "album",
                        "uri": "spotify:album:4KqHJrKDQGRgXSXWajwJVI"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/5sHPYevv4ykaH79HIHqBDP"
                            },
                            "href": "https://api.spotify.com/v1/artists/5sHPYevv4ykaH79HIHqBDP",
                            "id": "5sHPYevv4ykaH79HIHqBDP",
                            "name": "Yothu Yindi",
                            "type": "artist",
                            "uri": "spotify:artist:5sHPYevv4ykaH79HIHqBDP"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 243080,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "AUYT20700030"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/1WvO9c6UokTaCFLk76f07H"
                    },
                    "href": "https://api.spotify.com/v1/tracks/1WvO9c6UokTaCFLk76f07H",
                    "id": "1WvO9c6UokTaCFLk76f07H",
                    "is_local": false,
                    "name": "Treaty (Radio Mix)    ",
                    "popularity": 0,
                    "preview_url": null,
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:1WvO9c6UokTaCFLk76f07H"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:09:11Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "compilation",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/1gRNBaI4yn6wCCTvRhGWh8"
                                },
                                "href": "https://api.spotify.com/v1/artists/1gRNBaI4yn6wCCTvRhGWh8",
                                "id": "1gRNBaI4yn6wCCTvRhGWh8",
                                "name": "Don McLean",
                                "type": "artist",
                                "uri": "spotify:artist:1gRNBaI4yn6wCCTvRhGWh8"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/20Y9wHWIxNFvqplgHmqmUl"
                        },
                        "href": "https://api.spotify.com/v1/albums/20Y9wHWIxNFvqplgHmqmUl",
                        "id": "20Y9wHWIxNFvqplgHmqmUl",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273b387752e21389aa53753329e",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02b387752e21389aa53753329e",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851b387752e21389aa53753329e",
                                "width": 64
                            }
                        ],
                        "name": "The Best Of Don McLean",
                        "release_date": "1988-01-01",
                        "release_date_precision": "day",
                        "total_tracks": 10,
                        "type": "album",
                        "uri": "spotify:album:20Y9wHWIxNFvqplgHmqmUl"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/1gRNBaI4yn6wCCTvRhGWh8"
                            },
                            "href": "https://api.spotify.com/v1/artists/1gRNBaI4yn6wCCTvRhGWh8",
                            "id": "1gRNBaI4yn6wCCTvRhGWh8",
                            "name": "Don McLean",
                            "type": "artist",
                            "uri": "spotify:artist:1gRNBaI4yn6wCCTvRhGWh8"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 515866,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USEM38600088"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/2QgWuCtBpNIpl5trmKCxRf"
                    },
                    "href": "https://api.spotify.com/v1/tracks/2QgWuCtBpNIpl5trmKCxRf",
                    "id": "2QgWuCtBpNIpl5trmKCxRf",
                    "is_local": false,
                    "name": "American Pie",
                    "popularity": 71,
                    "preview_url": "https://p.scdn.co/mp3-preview    /09dcb64638386cd6eb5223ec5fcd5303ba046bd6?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:2QgWuCtBpNIpl5trmKCxRf"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:09:24Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/4sD9znwiVFx9cgRPZ42aQ1"
                                },
                                "href": "https://api.spotify.com/v1/artists/4sD9znwiVFx9cgRPZ42aQ1",
                                "id": "4sD9znwiVFx9cgRPZ42aQ1",
                                "name": "Sinéad O'Connor",
                                "type": "artist",
                                "uri": "spotify:artist:4sD9znwiVFx9cgRPZ42aQ1"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/34hQFIwGTLf03BZQmGL0iy"
                        },
                        "href": "https://api.spotify.com/v1/albums/34hQFIwGTLf03BZQmGL0iy",
                        "id": "34hQFIwGTLf03BZQmGL0iy",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2736f6536c2e326fb2b42db90f8",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e026f6536c2e326fb2b42db90f8",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048516f6536c2e326fb2b42db90f8",
                                "width": 64
                            }
                        ],
                        "name": "I Do Not Want What I Haven't Got",
                        "release_date": "1990-07-01",
                        "release_date_precision": "day",
                        "total_tracks": 10,
                        "type": "album",
                        "uri": "spotify:album:34hQFIwGTLf03BZQmGL0iy"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/4sD9znwiVFx9cgRPZ42aQ1"
                            },
                            "href": "https://api.spotify.com/v1/artists/4sD9znwiVFx9cgRPZ42aQ1",
                            "id": "4sD9znwiVFx9cgRPZ42aQ1",
                            "name": "Sinéad O'Connor",
                            "type": "artist",
                            "uri": "spotify:artist:4sD9znwiVFx9cgRPZ42aQ1"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 280040,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBAYK9000017"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/3nvuPQTw2zuFAVuLsC9IYQ"
                    },
                    "href": "https://api.spotify.com/v1/tracks/3nvuPQTw2zuFAVuLsC9IYQ",
                    "id": "3nvuPQTw2zuFAVuLsC9IYQ",
                    "is_local": false,
                    "name": "Nothing Compares 2 U",
                    "popularity": 72,
                    "preview_url": "https://p.scdn.co/mp3-preview    /d50d7c8ec55e72b1fef322107cc76ac5ade9c1b6?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 6,
                    "type": "track",
                    "uri": "spotify:track:3nvuPQTw2zuFAVuLsC9IYQ"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:09:38Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/4FtSnMlCVxCswABUmdhwpm"
                                },
                                "href": "https://api.spotify.com/v1/artists/4FtSnMlCVxCswABUmdhwpm",
                                "id": "4FtSnMlCVxCswABUmdhwpm",
                                "name": "Carly Simon",
                                "type": "artist",
                                "uri": "spotify:artist:4FtSnMlCVxCswABUmdhwpm"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/79x0PRGIZv33znrCkPkCZ5"
                        },
                        "href": "https://api.spotify.com/v1/albums/79x0PRGIZv33znrCkPkCZ5",
                        "id": "79x0PRGIZv33znrCkPkCZ5",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273143aaf19ecc28c7b41d42d9d",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02143aaf19ecc28c7b41d42d9d",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851143aaf19ecc28c7b41d42d9d",
                                "width": 64
                            }
                        ],
                        "name": "No Secrets",
                        "release_date": "1972",
                        "release_date_precision": "year",
                        "total_tracks": 10,
                        "type": "album",
                        "uri": "spotify:album:79x0PRGIZv33znrCkPkCZ5"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/4FtSnMlCVxCswABUmdhwpm"
                            },
                            "href": "https://api.spotify.com/v1/artists/4FtSnMlCVxCswABUmdhwpm",
                            "id": "4FtSnMlCVxCswABUmdhwpm",
                            "name": "Carly Simon",
                            "type": "artist",
                            "uri": "spotify:artist:4FtSnMlCVxCswABUmdhwpm"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 258411,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USEE19900883"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/2DnJjbjNTV9Nd5NOa1KGba"
                    },
                    "href": "https://api.spotify.com/v1/tracks/2DnJjbjNTV9Nd5NOa1KGba",
                    "id": "2DnJjbjNTV9Nd5NOa1KGba",
                    "is_local": false,
                    "name": "You're so Vain",
                    "popularity": 75,
                    "preview_url": "https://p.scdn.co/mp3-preview    /0cd60ee4a92a3af5f87eae5485ff622daed4135f?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 3,
                    "type": "track",
                    "uri": "spotify:track:2DnJjbjNTV9Nd5NOa1KGba"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:10:03Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/776Uo845nYHJpNaStv1Ds4"
                                },
                                "href": "https://api.spotify.com/v1/artists/776Uo845nYHJpNaStv1Ds4",
                                "id": "776Uo845nYHJpNaStv1Ds4",
                                "name": "Jimi Hendrix",
                                "type": "artist",
                                "uri": "spotify:artist:776Uo845nYHJpNaStv1Ds4"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/5z090LQztiqh13wYspQvKQ"
                        },
                        "href": "https://api.spotify.com/v1/albums/5z090LQztiqh13wYspQvKQ",
                        "id": "5z090LQztiqh13wYspQvKQ",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273522088789d49e216d9818292",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02522088789d49e216d9818292",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851522088789d49e216d9818292",
                                "width": 64
                            }
                        ],
                        "name": "Electric Ladyland",
                        "release_date": "1968-10-25",
                        "release_date_precision": "day",
                        "total_tracks": 16,
                        "type": "album",
                        "uri": "spotify:album:5z090LQztiqh13wYspQvKQ"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/776Uo845nYHJpNaStv1Ds4"
                            },
                            "href": "https://api.spotify.com/v1/artists/776Uo845nYHJpNaStv1Ds4",
                            "id": "776Uo845nYHJpNaStv1Ds4",
                            "name": "Jimi Hendrix",
                            "type": "artist",
                            "uri": "spotify:artist:776Uo845nYHJpNaStv1Ds4"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 240800,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USQX90900749"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/2aoo2jlRnM3A0NyLQqMN2f"
                    },
                    "href": "https://api.spotify.com/v1/tracks/2aoo2jlRnM3A0NyLQqMN2f",
                    "id": "2aoo2jlRnM3A0NyLQqMN2f",
                    "is_local": false,
                    "name": "All Along the Watchtower",
                    "popularity": 77,
                    "preview_url": "https://p.scdn.co/mp3-preview/    5eec2933740ab3984340d5f004813f8275e1bb97?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 15,
                    "type": "track",
                    "uri": "spotify:track:2aoo2jlRnM3A0NyLQqMN2f"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:10:11Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/7oPftvlwr6VrsViSDV7fJY"
                                },
                                "href": "https://api.spotify.com/v1/artists/7oPftvlwr6VrsViSDV7fJY",
                                "id": "7oPftvlwr6VrsViSDV7fJY",
                                "name": "Green Day",
                                "type": "artist",
                                "uri": "spotify:artist:7oPftvlwr6VrsViSDV7fJY"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/3x2uer6Xh0d5rF8toWpRDA"
                        },
                        "href": "https://api.spotify.com/v1/albums/3x2uer6Xh0d5rF8toWpRDA",
                        "id": "3x2uer6Xh0d5rF8toWpRDA",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273da4f6706ae0f2501c61ce776",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02da4f6706ae0f2501c61ce776",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851da4f6706ae0f2501c61ce776",
                                "width": 64
                            }
                        ],
                        "name": "Nimrod",
                        "release_date": "1997-10-14",
                        "release_date_precision": "day",
                        "total_tracks": 18,
                        "type": "album",
                        "uri": "spotify:album:3x2uer6Xh0d5rF8toWpRDA"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/7oPftvlwr6VrsViSDV7fJY"
                            },
                            "href": "https://api.spotify.com/v1/artists/7oPftvlwr6VrsViSDV7fJY",
                            "id": "7oPftvlwr6VrsViSDV7fJY",
                            "name": "Green Day",
                            "type": "artist",
                            "uri": "spotify:artist:7oPftvlwr6VrsViSDV7fJY"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 153466,
                    "episode": false,
                    "explicit": true,
                    "external_ids": {
                        "isrc": "USRE19700545"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/6ORqU0bHbVCRjXm9AjyHyZ"
                    },
                    "href": "https://api.spotify.com/v1/tracks/6ORqU0bHbVCRjXm9AjyHyZ",
                    "id": "6ORqU0bHbVCRjXm9AjyHyZ",
                    "is_local": false,
                    "name": "Good Riddance (Time of Your Life)",
                    "popularity": 75,
                    "preview_url": "https://p.scdn.co/mp3-preview/    e12bf548d4633c9877b3772493bf9a980511b926?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 17,
                    "type": "track",
                    "uri": "spotify:track:6ORqU0bHbVCRjXm9AjyHyZ"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:10:27Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "compilation",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/4tpUmLEVLCGFr93o8hFFIB"
                                },
                                "href": "https://api.spotify.com/v1/artists/4tpUmLEVLCGFr93o8hFFIB",
                                "id": "4tpUmLEVLCGFr93o8hFFIB",
                                "name": "Blondie",
                                "type": "artist",
                                "uri": "spotify:artist:4tpUmLEVLCGFr93o8hFFIB"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/7mEjsBlRmfP63cH1gdPT6A"
                        },
                        "href": "https://api.spotify.com/v1/albums/7mEjsBlRmfP63cH1gdPT6A",
                        "id": "7mEjsBlRmfP63cH1gdPT6A",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2738cf86a9be38868f1d73cdb58",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e028cf86a9be38868f1d73cdb58",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048518cf86a9be38868f1d73cdb58",
                                "width": 64
                            }
                        ],
                        "name": "Best Of Blondie",
                        "release_date": "1981-10-31",
                        "release_date_precision": "day",
                        "total_tracks": 12,
                        "type": "album",
                        "uri": "spotify:album:7mEjsBlRmfP63cH1gdPT6A"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/4tpUmLEVLCGFr93o8hFFIB"
                            },
                            "href": "https://api.spotify.com/v1/artists/4tpUmLEVLCGFr93o8hFFIB",
                            "id": "4tpUmLEVLCGFr93o8hFFIB",
                            "name": "Blondie",
                            "type": "artist",
                            "uri": "spotify:artist:4tpUmLEVLCGFr93o8hFFIB"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 212893,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USCH38900008"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/0vLwL4xuJ3s7SeaCdvMqkY"
                    },
                    "href": "https://api.spotify.com/v1/tracks/0vLwL4xuJ3s7SeaCdvMqkY",
                    "id": "0vLwL4xuJ3s7SeaCdvMqkY",
                    "is_local": false,
                    "name": "Call Me",
                    "popularity": 61,
                    "preview_url": "https://p.scdn.co/mp3-preview/    ed5a443bc86176135ebca8a114f66f4d814d4c90?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 10,
                    "type": "track",
                    "uri": "spotify:track:0vLwL4xuJ3s7SeaCdvMqkY"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:10:38Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/3hv9jJF3adDNsBSIQDqcjp"
                                },
                                "href": "https://api.spotify.com/v1/artists/3hv9jJF3adDNsBSIQDqcjp",
                                "id": "3hv9jJF3adDNsBSIQDqcjp",
                                "name": "Mark Ronson",
                                "type": "artist",
                                "uri": "spotify:artist:3hv9jJF3adDNsBSIQDqcjp"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/3vLaOYCNCzngDf8QdBg2V1"
                        },
                        "href": "https://api.spotify.com/v1/albums/3vLaOYCNCzngDf8QdBg2V1",
                        "id": "3vLaOYCNCzngDf8QdBg2V1",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b27375a609817a8b9a5d1ea6911d",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e0275a609817a8b9a5d1ea6911d",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d0000485175a609817a8b9a5d1ea6911d",
                                "width": 64
                            }
                        ],
                        "name": "Uptown Special",
                        "release_date": "2015-01-12",
                        "release_date_precision": "day",
                        "total_tracks": 11,
                        "type": "album",
                        "uri": "spotify:album:3vLaOYCNCzngDf8QdBg2V1"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/3hv9jJF3adDNsBSIQDqcjp"
                            },
                            "href": "https://api.spotify.com/v1/artists/3hv9jJF3adDNsBSIQDqcjp",
                            "id": "3hv9jJF3adDNsBSIQDqcjp",
                            "name": "Mark Ronson",
                            "type": "artist",
                            "uri": "spotify:artist:3hv9jJF3adDNsBSIQDqcjp"
                        },
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/0du5cEVh5yTK9QJze8zA0C"
                            },
                            "href": "https://api.spotify.com/v1/artists/0du5cEVh5yTK9QJze8zA0C",
                            "id": "0du5cEVh5yTK9QJze8zA0C",
                            "name": "Bruno Mars",
                            "type": "artist",
                            "uri": "spotify:artist:0du5cEVh5yTK9QJze8zA0C"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 269666,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBARL1401524"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/32OlwWuMpZ6b0aN2RZOeMS"
                    },
                    "href": "https://api.spotify.com/v1/tracks/32OlwWuMpZ6b0aN2RZOeMS",
                    "id": "32OlwWuMpZ6b0aN2RZOeMS",
                    "is_local": false,
                    "name": "Uptown Funk (feat. Bruno Mars)",
                    "popularity": 81,
                    "preview_url": "https://p.scdn.co/mp3-preview    /88a794d97fcb4475f72a27be7baf71b94d5a9dda?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 4,
                    "type": "track",
                    "uri": "spotify:track:32OlwWuMpZ6b0aN2RZOeMS"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:10:51Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "compilation",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/2yrbLiuBmc9j81lTX3XUuI"
                                },
                                "href": "https://api.spotify.com/v1/artists/2yrbLiuBmc9j81lTX3XUuI",
                                "id": "2yrbLiuBmc9j81lTX3XUuI",
                                "name": "The Jacksons",
                                "type": "artist",
                                "uri": "spotify:artist:2yrbLiuBmc9j81lTX3XUuI"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/6qZW5Wm8k45fyhA1GFKh5y"
                        },
                        "href": "https://api.spotify.com/v1/albums/6qZW5Wm8k45fyhA1GFKh5y",
                        "id": "6qZW5Wm8k45fyhA1GFKh5y",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273093b7db5e748d7f9d7c336bc",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02093b7db5e748d7f9d7c336bc",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851093b7db5e748d7f9d7c336bc",
                                "width": 64
                            }
                        ],
                        "name": "The Very Best Of The Jacksons and Jackson 5",
                        "release_date": "2004-06-28",
                        "release_date_precision": "day",
                        "total_tracks": 32,
                        "type": "album",
                        "uri": "spotify:album:6qZW5Wm8k45fyhA1GFKh5y"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/2yrbLiuBmc9j81lTX3XUuI"
                            },
                            "href": "https://api.spotify.com/v1/artists/2yrbLiuBmc9j81lTX3XUuI",
                            "id": "2yrbLiuBmc9j81lTX3XUuI",
                            "name": "The Jacksons",
                            "type": "artist",
                            "uri": "spotify:artist:2yrbLiuBmc9j81lTX3XUuI"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 2,
                    "duration_ms": 210373,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USSM17801024"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/2Cm7WEVdiXiWSjfEBHFtRu"
                    },
                    "href": "https://api.spotify.com/v1/tracks/2Cm7WEVdiXiWSjfEBHFtRu",
                    "id": "2Cm7WEVdiXiWSjfEBHFtRu",
                    "is_local": false,
                    "name": "Blame It on the Boogie",
                    "popularity": 52,
                    "preview_url": "https://p.scdn.co/mp3-preview    /e3f6a1f962bf21731f49dc8ffb4560043ad688ec?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 2,
                    "type": "track",
                    "uri": "spotify:track:2Cm7WEVdiXiWSjfEBHFtRu"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:11:06Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/2CvCyf1gEVhI0mX6aFXmVI"
                                },
                                "href": "https://api.spotify.com/v1/artists/2CvCyf1gEVhI0mX6aFXmVI",
                                "id": "2CvCyf1gEVhI0mX6aFXmVI",
                                "name": "Paul Simon",
                                "type": "artist",
                                "uri": "spotify:artist:2CvCyf1gEVhI0mX6aFXmVI"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/6WgGWYw6XXQyLTsWt7tXky"
                        },
                        "href": "https://api.spotify.com/v1/albums/6WgGWYw6XXQyLTsWt7tXky",
                        "id": "6WgGWYw6XXQyLTsWt7tXky",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b27309880a7b8636c5a0615dc0c8",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e0209880a7b8636c5a0615dc0c8",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d0000485109880a7b8636c5a0615dc0c8",
                                "width": 64
                            }
                        ],
                        "name": "Graceland (25th Anniversary Deluxe Edition)",
                        "release_date": "1986-08-12",
                        "release_date_precision": "day",
                        "total_tracks": 17,
                        "type": "album",
                        "uri": "spotify:album:6WgGWYw6XXQyLTsWt7tXky"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/2CvCyf1gEVhI0mX6aFXmVI"
                            },
                            "href": "https://api.spotify.com/v1/artists/2CvCyf1gEVhI0mX6aFXmVI",
                            "id": "2CvCyf1gEVhI0mX6aFXmVI",
                            "name": "Paul Simon",
                            "type": "artist",
                            "uri": "spotify:artist:2CvCyf1gEVhI0mX6aFXmVI"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 280000,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USSM11002274"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/0qxYx4F3vm1AOnfux6dDxP"
                    },
                    "href": "https://api.spotify.com/v1/tracks/0qxYx4F3vm1AOnfux6dDxP",
                    "id": "0qxYx4F3vm1AOnfux6dDxP",
                    "is_local": false,
                    "name": "You Can Call Me Al",
                    "popularity": 76,
                    "preview_url": "https://p.scdn.co/mp3-preview    /ff8c2381dbea9e5c5da615f6321d42c603175761?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 6,
                    "type": "track",
                    "uri": "spotify:track:0qxYx4F3vm1AOnfux6dDxP"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:11:19Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/7udwYystFcvYziV36ZIwuh"
                                },
                                "href": "https://api.spotify.com/v1/artists/7udwYystFcvYziV36ZIwuh",
                                "id": "7udwYystFcvYziV36ZIwuh",
                                "name": "Hunters & Collectors",
                                "type": "artist",
                                "uri": "spotify:artist:7udwYystFcvYziV36ZIwuh"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/39EJWDJI8959h6aMZkZ5pS"
                        },
                        "href": "https://api.spotify.com/v1/albums/39EJWDJI8959h6aMZkZ5pS",
                        "id": "39EJWDJI8959h6aMZkZ5pS",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2733ea43efe89294092e5d5fbd3",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e023ea43efe89294092e5d5fbd3",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048513ea43efe89294092e5d5fbd3",
                                "width": 64
                            }
                        ],
                        "name": "Human Frailty",
                        "release_date": "1986",
                        "release_date_precision": "year",
                        "total_tracks": 13,
                        "type": "album",
                        "uri": "spotify:album:39EJWDJI8959h6aMZkZ5pS"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/7udwYystFcvYziV36ZIwuh"
                            },
                            "href": "https://api.spotify.com/v1/artists/7udwYystFcvYziV36ZIwuh",
                            "id": "7udwYystFcvYziV36ZIwuh",
                            "name": "Hunters & Collectors",
                            "type": "artist",
                            "uri": "spotify:artist:7udwYystFcvYziV36ZIwuh"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 233493,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "AULI00508340"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/3T0ggmh35mdaTCXT2c0wkb"
                    },
                    "href": "https://api.spotify.com/v1/tracks/3T0ggmh35mdaTCXT2c0wkb",
                    "id": "3T0ggmh35mdaTCXT2c0wkb",
                    "is_local": false,
                    "name": "Throw Your Arms Around Me    ",
                    "popularity": 3,
                    "preview_url": null,
                    "track": true,
                    "track_number": 2,
                    "type": "track",
                    "uri": "spotify:track:3T0ggmh35mdaTCXT2c0wkb"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:11:25Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "compilation",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/6zFYqv1mOsgBRQbae3JJ9e"
                                },
                                "href": "https://api.spotify.com/v1/artists/6zFYqv1mOsgBRQbae3JJ9e",
                                "id": "6zFYqv1mOsgBRQbae3JJ9e",
                                "name": "Billy Joel",
                                "type": "artist",
                                "uri": "spotify:artist:6zFYqv1mOsgBRQbae3JJ9e"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/7r36rel1M4gyBavfcJP6Yz"
                        },
                        "href": "https://api.spotify.com/v1/albums/7r36rel1M4gyBavfcJP6Yz",
                        "id": "7r36rel1M4gyBavfcJP6Yz",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273649d4f282653ab8be56f447e",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02649d4f282653ab8be56f447e",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851649d4f282653ab8be56f447e",
                                "width": 64
                            }
                        ],
                        "name": "The Essential Billy Joel",
                        "release_date": "2001-10-02",
                        "release_date_precision": "day",
                        "total_tracks": 36,
                        "type": "album",
                        "uri": "spotify:album:7r36rel1M4gyBavfcJP6Yz"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/6zFYqv1mOsgBRQbae3JJ9e"
                            },
                            "href": "https://api.spotify.com/v1/artists/6zFYqv1mOsgBRQbae3JJ9e",
                            "id": "6zFYqv1mOsgBRQbae3JJ9e",
                            "name": "Billy Joel",
                            "type": "artist",
                            "uri": "spotify:artist:6zFYqv1mOsgBRQbae3JJ9e"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 336093,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USSM17300504"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/3FCto7hnn1shUyZL42YgfO"
                    },
                    "href": "https://api.spotify.com/v1/tracks/3FCto7hnn1shUyZL42YgfO",
                    "id": "3FCto7hnn1shUyZL42YgfO",
                    "is_local": false,
                    "name": "Piano Man",
                    "popularity": 69,
                    "preview_url": "https://p.scdn.co/mp3-preview    /54682172a43fb85c11b29f807f9ced0dcd3b9dc0?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:3FCto7hnn1shUyZL42YgfO"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:11:34Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/1k5aZWIOUbUfKcnMxtEivJ"
                                },
                                "href": "https://api.spotify.com/v1/artists/1k5aZWIOUbUfKcnMxtEivJ",
                                "id": "1k5aZWIOUbUfKcnMxtEivJ",
                                "name": "Jimmy Barnes",
                                "type": "artist",
                                "uri": "spotify:artist:1k5aZWIOUbUfKcnMxtEivJ"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/2iv4jmYWY966XXNbi26G2c"
                        },
                        "href": "https://api.spotify.com/v1/albums/2iv4jmYWY966XXNbi26G2c",
                        "id": "2iv4jmYWY966XXNbi26G2c",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2730936919a9ce7985b93a8cf6c",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e020936919a9ce7985b93a8cf6c",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048510936919a9ce7985b93a8cf6c",
                                "width": 64
                            }
                        ],
                        "name": "For The Working Class Man 25",
                        "release_date": "1985",
                        "release_date_precision": "year",
                        "total_tracks": 12,
                        "type": "album",
                        "uri": "spotify:album:2iv4jmYWY966XXNbi26G2c"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/1k5aZWIOUbUfKcnMxtEivJ"
                            },
                            "href": "https://api.spotify.com/v1/artists/1k5aZWIOUbUfKcnMxtEivJ",
                            "id": "1k5aZWIOUbUfKcnMxtEivJ",
                            "name": "Jimmy Barnes",
                            "type": "artist",
                            "uri": "spotify:artist:1k5aZWIOUbUfKcnMxtEivJ"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 250146,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "AUL100623960"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/6FQ5fUnSBAg5bujBlT62CL"
                    },
                    "href": "https://api.spotify.com/v1/tracks/6FQ5fUnSBAg5bujBlT62CL",
                    "id": "6FQ5fUnSBAg5bujBlT62CL",
                    "is_local": false,
                    "name": "Working Class Man    ",
                    "popularity": 0,
                    "preview_url": null,
                    "track": true,
                    "track_number": 4,
                    "type": "track",
                    "uri": "spotify:track:6FQ5fUnSBAg5bujBlT62CL"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:11:55Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/7dGJo4pcD2V6oG8kP0tJRR"
                                },
                                "href": "https://api.spotify.com/v1/artists/7dGJo4pcD2V6oG8kP0tJRR",
                                "id": "7dGJo4pcD2V6oG8kP0tJRR",
                                "name": "Eminem",
                                "type": "artist",
                                "uri": "spotify:artist:7dGJo4pcD2V6oG8kP0tJRR"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/71xFWYFtiHC8eP99QB30AA"
                        },
                        "href": "https://api.spotify.com/v1/albums/71xFWYFtiHC8eP99QB30AA",
                        "id": "71xFWYFtiHC8eP99QB30AA",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273a8a32ae2a279b9bf03445738",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02a8a32ae2a279b9bf03445738",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851a8a32ae2a279b9bf03445738",
                                "width": 64
                            }
                        ],
                        "name": "Curtain Call (Deluxe)",
                        "release_date": "2005-12-06",
                        "release_date_precision": "day",
                        "total_tracks": 24,
                        "type": "album",
                        "uri": "spotify:album:71xFWYFtiHC8eP99QB30AA"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/7dGJo4pcD2V6oG8kP0tJRR"
                            },
                            "href": "https://api.spotify.com/v1/artists/7dGJo4pcD2V6oG8kP0tJRR",
                            "id": "7dGJo4pcD2V6oG8kP0tJRR",
                            "name": "Eminem",
                            "type": "artist",
                            "uri": "spotify:artist:7dGJo4pcD2V6oG8kP0tJRR"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 284800,
                    "episode": false,
                    "explicit": true,
                    "external_ids": {
                        "isrc": "USIR10000448"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/1MYlx4dBtiyjn7K8YSyfzT"
                    },
                    "href": "https://api.spotify.com/v1/tracks/1MYlx4dBtiyjn7K8YSyfzT",
                    "id": "1MYlx4dBtiyjn7K8YSyfzT",
                    "is_local": false,
                    "name": "The Real Slim Shady"    ,
                    "popularity": 1,
                    "preview_url": null,
                    "track": true,
                    "track_number": 11,
                    "type": "track",
                    "uri": "spotify:track:1MYlx4dBtiyjn7K8YSyfzT"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:12:05Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "compilation",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/432R46LaYsJZV2Gmc4jUV5"
                                },
                                "href": "https://api.spotify.com/v1/artists/432R46LaYsJZV2Gmc4jUV5",
                                "id": "432R46LaYsJZV2Gmc4jUV5",
                                "name": "Joy Division",
                                "type": "artist",
                                "uri": "spotify:artist:432R46LaYsJZV2Gmc4jUV5"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/0p8Zy0wEzDYiFDcSt07UHe"
                        },
                        "href": "https://api.spotify.com/v1/albums/0p8Zy0wEzDYiFDcSt07UHe",
                        "id": "0p8Zy0wEzDYiFDcSt07UHe",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b27365792edb445d4a107dbe97fd",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e0265792edb445d4a107dbe97fd",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d0000485165792edb445d4a107dbe97fd",
                                "width": 64
                            }
                        ],
                        "name": "The Best Of",
                        "release_date": "2008-03-20",
                        "release_date_precision": "day",
                        "total_tracks": 14,
                        "type": "album",
                        "uri": "spotify:album:0p8Zy0wEzDYiFDcSt07UHe"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/432R46LaYsJZV2Gmc4jUV5"
                            },
                            "href": "https://api.spotify.com/v1/artists/432R46LaYsJZV2Gmc4jUV5",
                            "id": "432R46LaYsJZV2Gmc4jUV5",
                            "name": "Joy Division",
                            "type": "artist",
                            "uri": "spotify:artist:432R46LaYsJZV2Gmc4jUV5"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 206866,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBAAP9700227"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/2JO3HwMRPeya8bXbtbyPcf"
                    },
                    "href": "https://api.spotify.com/v1/tracks/2JO3HwMRPeya8bXbtbyPcf",
                    "id": "2JO3HwMRPeya8bXbtbyPcf",
                    "is_local": false,
                    "name": "Love Will Tear Us Apart",
                    "popularity": 72,
                    "preview_url": "https://p.scdn.co/mp3-preview    /18a4b498250ed137d44823f2d49170be32336433?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 9,
                    "type": "track",
                    "uri": "spotify:track:2JO3HwMRPeya8bXbtbyPcf"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:12:17Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/3NRFinRTEqUCfaTTZmk8ek"
                                },
                                "href": "https://api.spotify.com/v1/artists/3NRFinRTEqUCfaTTZmk8ek",
                                "id": "3NRFinRTEqUCfaTTZmk8ek",
                                "name": "Savage Garden",
                                "type": "artist",
                                "uri": "spotify:artist:3NRFinRTEqUCfaTTZmk8ek"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/2FSVwM8ysmI2tXIPpBJbfs"
                        },
                        "href": "https://api.spotify.com/v1/albums/2FSVwM8ysmI2tXIPpBJbfs",
                        "id": "2FSVwM8ysmI2tXIPpBJbfs",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2736829cf8da7c5706fc42a3852",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e026829cf8da7c5706fc42a3852",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048516829cf8da7c5706fc42a3852",
                                "width": 64
                            }
                        ],
                        "name": "Savage Garden",
                        "release_date": "1997-03-04",
                        "release_date_precision": "day",
                        "total_tracks": 21,
                        "type": "album",
                        "uri": "spotify:album:2FSVwM8ysmI2tXIPpBJbfs"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/3NRFinRTEqUCfaTTZmk8ek"
                            },
                            "href": "https://api.spotify.com/v1/artists/3NRFinRTEqUCfaTTZmk8ek",
                            "id": "3NRFinRTEqUCfaTTZmk8ek",
                            "name": "Savage Garden",
                            "type": "artist",
                            "uri": "spotify:artist:3NRFinRTEqUCfaTTZmk8ek"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 277600,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "AURQ09700005"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/41Za52zU5QKSgVg0CxWO68"
                    },
                    "href": "https://api.spotify.com/v1/tracks/41Za52zU5QKSgVg0CxWO68",
                    "id": "41Za52zU5QKSgVg0CxWO68",
                    "is_local": false,
                    "name": "Truly Madly Deeply    ",
                    "popularity": 1,
                    "preview_url": null,
                    "track": true,
                    "track_number": 5,
                    "type": "track",
                    "uri": "spotify:track:41Za52zU5QKSgVg0CxWO68"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:12:24Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/4lxfqrEsLX6N1N4OCSkILp"
                                },
                                "href": "https://api.spotify.com/v1/artists/4lxfqrEsLX6N1N4OCSkILp",
                                "id": "4lxfqrEsLX6N1N4OCSkILp",
                                "name": "Phil Collins",
                                "type": "artist",
                                "uri": "spotify:artist:4lxfqrEsLX6N1N4OCSkILp"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/1cM3r0WQZWNkCpEbmFjLln"
                        },
                        "href": "https://api.spotify.com/v1/albums/1cM3r0WQZWNkCpEbmFjLln",
                        "id": "1cM3r0WQZWNkCpEbmFjLln",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273f6954c1f074f66907a8c5483",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02f6954c1f074f66907a8c5483",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851f6954c1f074f66907a8c5483",
                                "width": 64
                            }
                        ],
                        "name": "Face Value (Deluxe Editon)",
                        "release_date": "1981-01-01",
                        "release_date_precision": "day",
                        "total_tracks": 24,
                        "type": "album",
                        "uri": "spotify:album:1cM3r0WQZWNkCpEbmFjLln"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/4lxfqrEsLX6N1N4OCSkILp"
                            },
                            "href": "https://api.spotify.com/v1/artists/4lxfqrEsLX6N1N4OCSkILp",
                            "id": "4lxfqrEsLX6N1N4OCSkILp",
                            "name": "Phil Collins",
                            "type": "artist",
                            "uri": "spotify:artist:4lxfqrEsLX6N1N4OCSkILp"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 336453,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USAT21502120"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/18AXbzPzBS8Y3AkgSxzJPb"
                    },
                    "href": "https://api.spotify.com/v1/tracks/18AXbzPzBS8Y3AkgSxzJPb",
                    "id": "18AXbzPzBS8Y3AkgSxzJPb",
                    "is_local": false,
                    "name": "In The Air Tonight - 2015 Remastered",
                    "popularity": 77,
                    "preview_url": "https://p.scdn.co/mp3-preview    /36ca54a4ddb42fac1cecd19684c351f160ed55fa?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:18AXbzPzBS8Y3AkgSxzJPb"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:12:32Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/26dSoYclwsYLMAKD3tpOr4"
                                },
                                "href": "https://api.spotify.com/v1/artists/26dSoYclwsYLMAKD3tpOr4",
                                "id": "26dSoYclwsYLMAKD3tpOr4",
                                "name": "Britney Spears",
                                "type": "artist",
                                "uri": "spotify:artist:26dSoYclwsYLMAKD3tpOr4"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/5PmgtkodFl2Om3hMXONDll"
                        },
                        "href": "https://api.spotify.com/v1/albums/5PmgtkodFl2Om3hMXONDll",
                        "id": "5PmgtkodFl2Om3hMXONDll",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2732aa20611c7fb964a74ab01a6",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e022aa20611c7fb964a74ab01a6",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048512aa20611c7fb964a74ab01a6",
                                "width": 64
                            }
                        ],
                        "name": "Oops!... I Did It Again",
                        "release_date": "2000-05-16",
                        "release_date_precision": "day",
                        "total_tracks": 12,
                        "type": "album",
                        "uri": "spotify:album:5PmgtkodFl2Om3hMXONDll"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/26dSoYclwsYLMAKD3tpOr4"
                            },
                            "href": "https://api.spotify.com/v1/artists/26dSoYclwsYLMAKD3tpOr4",
                            "id": "26dSoYclwsYLMAKD3tpOr4",
                            "name": "Britney Spears",
                            "type": "artist",
                            "uri": "spotify:artist:26dSoYclwsYLMAKD3tpOr4"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 211160,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USJI10000100"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/6naxalmIoLFWR0siv8dnQQ"
                    },
                    "href": "https://api.spotify.com/v1/tracks/6naxalmIoLFWR0siv8dnQQ",
                    "id": "6naxalmIoLFWR0siv8dnQQ",
                    "is_local": false,
                    "name": "Oops!...I Did It Again",
                    "popularity": 78,
                    "preview_url": "https://p.scdn.co/mp3-preview    /7fb86827422540ad01f65870375fef055412f034?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:6naxalmIoLFWR0siv8dnQQ"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:17:59Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/0Nn9YwJzcaeuU1jJL06e3r"
                                },
                                "href": "https://api.spotify.com/v1/artists/0Nn9YwJzcaeuU1jJL06e3r",
                                "id": "0Nn9YwJzcaeuU1jJL06e3r",
                                "name": "The Knack",
                                "type": "artist",
                                "uri": "spotify:artist:0Nn9YwJzcaeuU1jJL06e3r"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/6H0wsYDvFlATzXHn0IqVpi"
                        },
                        "href": "https://api.spotify.com/v1/albums/6H0wsYDvFlATzXHn0IqVpi",
                        "id": "6H0wsYDvFlATzXHn0IqVpi",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273af6b486fa0a2959f79c8acd8",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02af6b486fa0a2959f79c8acd8",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851af6b486fa0a2959f79c8acd8",
                                "width": 64
                            }
                        ],
                        "name": "Get The Knack",
                        "release_date": "1979-01-01",
                        "release_date_precision": "day",
                        "total_tracks": 12,
                        "type": "album",
                        "uri": "spotify:album:6H0wsYDvFlATzXHn0IqVpi"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/0Nn9YwJzcaeuU1jJL06e3r"
                            },
                            "href": "https://api.spotify.com/v1/artists/0Nn9YwJzcaeuU1jJL06e3r",
                            "id": "0Nn9YwJzcaeuU1jJL06e3r",
                            "name": "The Knack",
                            "type": "artist",
                            "uri": "spotify:artist:0Nn9YwJzcaeuU1jJL06e3r"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 295400,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USCA28900153"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/1HOMkjp0nHMaTnfAkslCQj"
                    },
                    "href": "https://api.spotify.com/v1/tracks/1HOMkjp0nHMaTnfAkslCQj",
                    "id": "1HOMkjp0nHMaTnfAkslCQj",
                    "is_local": false,
                    "name": "My Sharona",
                    "popularity": 73,
                    "preview_url": "https://p.scdn.co/mp3-preview    /4af53791e6095ca0a3c406f1d21c444ed3d7a781?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 7,
                    "type": "track",
                    "uri": "spotify:track:1HOMkjp0nHMaTnfAkslCQj"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:12:49Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "compilation",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/4KWTAlx2RvbpseOGMEmROg"
                                },
                                "href": "https://api.spotify.com/v1/artists/4KWTAlx2RvbpseOGMEmROg",
                                "id": "4KWTAlx2RvbpseOGMEmROg",
                                "name": "R.E.M.",
                                "type": "artist",
                                "uri": "spotify:artist:4KWTAlx2RvbpseOGMEmROg"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/5PHng5BLIYSwmFfrihOeOi"
                        },
                        "href": "https://api.spotify.com/v1/albums/5PHng5BLIYSwmFfrihOeOi",
                        "id": "5PHng5BLIYSwmFfrihOeOi",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2734cef297681ea8e64a1fe4dc6",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e024cef297681ea8e64a1fe4dc6",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048514cef297681ea8e64a1fe4dc6",
                                "width": 64
                            }
                        ],
                        "name": "In Time: The Best Of R.E.M. 1988-2003",
                        "release_date": "2003-10-27",
                        "release_date_precision": "day",
                        "total_tracks": 18,
                        "type": "album",
                        "uri": "spotify:album:5PHng5BLIYSwmFfrihOeOi"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/4KWTAlx2RvbpseOGMEmROg"
                            },
                            "href": "https://api.spotify.com/v1/artists/4KWTAlx2RvbpseOGMEmROg",
                            "id": "4KWTAlx2RvbpseOGMEmROg",
                            "name": "R.E.M.",
                            "type": "artist",
                            "uri": "spotify:artist:4KWTAlx2RvbpseOGMEmROg"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 269000,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USWB19901521"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/12axV6NUqaYH3yFUWwArzr"
                    },
                    "href": "https://api.spotify.com/v1/tracks/12axV6NUqaYH3yFUWwArzr",
                    "id": "12axV6NUqaYH3yFUWwArzr",
                    "is_local": false,
                    "name": "Losing My Religion    ",
                    "popularity": 1,
                    "preview_url": null,
                    "track": true,
                    "track_number": 6,
                    "type": "track",
                    "uri": "spotify:track:12axV6NUqaYH3yFUWwArzr"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:12:56Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/3PhoLpVuITZKcymswpck5b"
                                },
                                "href": "https://api.spotify.com/v1/artists/3PhoLpVuITZKcymswpck5b",
                                "id": "3PhoLpVuITZKcymswpck5b",
                                "name": "Elton John",
                                "type": "artist",
                                "uri": "spotify:artist:3PhoLpVuITZKcymswpck5b"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/6eXE4xeu9GHSa8zTEVtFep"
                        },
                        "href": "https://api.spotify.com/v1/albums/6eXE4xeu9GHSa8zTEVtFep",
                        "id": "6eXE4xeu9GHSa8zTEVtFep",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b27339a2bb3c9e467e527407a6a5",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e0239a2bb3c9e467e527407a6a5",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d0000485139a2bb3c9e467e527407a6a5",
                                "width": 64
                            }
                        ],
                        "name": "Madman Across The Water",
                        "release_date": "1971-11-05",
                        "release_date_precision": "day",
                        "total_tracks": 9,
                        "type": "album",
                        "uri": "spotify:album:6eXE4xeu9GHSa8zTEVtFep"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/3PhoLpVuITZKcymswpck5b"
                            },
                            "href": "https://api.spotify.com/v1/artists/3PhoLpVuITZKcymswpck5b",
                            "id": "3PhoLpVuITZKcymswpck5b",
                            "name": "Elton John",
                            "type": "artist",
                            "uri": "spotify:artist:3PhoLpVuITZKcymswpck5b"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 377093,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBAMB7100001"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/4BGJSbB5rAcg4pNzD4gfxU"
                    },
                    "href": "https://api.spotify.com/v1/tracks/4BGJSbB5rAcg4pNzD4gfxU",
                    "id": "4BGJSbB5rAcg4pNzD4gfxU",
                    "is_local": false,
                    "name": "Tiny Dancer    ",
                    "popularity": 5,
                    "preview_url": null,
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:4BGJSbB5rAcg4pNzD4gfxU"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:13:14Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/3eqjTLE0HfPfh78zjh6TqT"
                                },
                                "href": "https://api.spotify.com/v1/artists/3eqjTLE0HfPfh78zjh6TqT",
                                "id": "3eqjTLE0HfPfh78zjh6TqT",
                                "name": "Bruce Springsteen",
                                "type": "artist",
                                "uri": "spotify:artist:3eqjTLE0HfPfh78zjh6TqT"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/0PMasrHdpaoIRuHuhHp72O"
                        },
                        "href": "https://api.spotify.com/v1/albums/0PMasrHdpaoIRuHuhHp72O",
                        "id": "0PMasrHdpaoIRuHuhHp72O",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273a7865e686c36a4adda6c9978",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02a7865e686c36a4adda6c9978",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851a7865e686c36a4adda6c9978",
                                "width": 64
                            }
                        ],
                        "name": "Born In The U.S.A.",
                        "release_date": "1984-06-04",
                        "release_date_precision": "day",
                        "total_tracks": 12,
                        "type": "album",
                        "uri": "spotify:album:0PMasrHdpaoIRuHuhHp72O"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/3eqjTLE0HfPfh78zjh6TqT"
                            },
                            "href": "https://api.spotify.com/v1/artists/3eqjTLE0HfPfh78zjh6TqT",
                            "id": "3eqjTLE0HfPfh78zjh6TqT",
                            "name": "Bruce Springsteen",
                            "type": "artist",
                            "uri": "spotify:artist:3eqjTLE0HfPfh78zjh6TqT"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 278680,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USSM18400406"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/0dOg1ySSI7NkpAe89Zo0b9"
                    },
                    "href": "https://api.spotify.com/v1/tracks/0dOg1ySSI7NkpAe89Zo0b9",
                    "id": "0dOg1ySSI7NkpAe89Zo0b9",
                    "is_local": false,
                    "name": "Born in the U.S.A.",
                    "popularity": 76,
                    "preview_url": "https://p.scdn.co/mp3-preview    /3b6a5b917056de1d50b31687f48098b264c0f12b?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:0dOg1ySSI7NkpAe89Zo0b9"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:18:24Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "compilation",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/0LyfQWJT6nXafLPZqxe9Of"
                                },
                                "href": "https://api.spotify.com/v1/artists/0LyfQWJT6nXafLPZqxe9Of",
                                "id": "0LyfQWJT6nXafLPZqxe9Of",
                                "name": "Various Artists",
                                "type": "artist",
                                "uri": "spotify:artist:0LyfQWJT6nXafLPZqxe9Of"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/4eKi4PJuybybkSbE6nNQnD"
                        },
                        "href": "https://api.spotify.com/v1/albums/4eKi4PJuybybkSbE6nNQnD",
                        "id": "4eKi4PJuybybkSbE6nNQnD",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273d029ad5d1a40fabfae0ac7f3",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02d029ad5d1a40fabfae0ac7f3",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851d029ad5d1a40fabfae0ac7f3",
                                "width": 64
                            }
                        ],
                        "name": "RnB Fridays",
                        "release_date": "2015-10-30",
                        "release_date_precision": "day",
                        "total_tracks": 38,
                        "type": "album",
                        "uri": "spotify:album:4eKi4PJuybybkSbE6nNQnD"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/7wqtxqI3eo7Gn1P7SpP6cQ"
                            },
                            "href": "https://api.spotify.com/v1/artists/7wqtxqI3eo7Gn1P7SpP6cQ",
                            "id": "7wqtxqI3eo7Gn1P7SpP6cQ",
                            "name": "Salt-N-Pepa",
                            "type": "artist",
                            "uri": "spotify:artist:7wqtxqI3eo7Gn1P7SpP6cQ"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 212746,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USIR20180412"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/32PCjJw8mk1FrJT2FcqRtT"
                    },
                    "href": "https://api.spotify.com/v1/tracks/32PCjJw8mk1FrJT2FcqRtT",
                    "id": "32PCjJw8mk1FrJT2FcqRtT",
                    "is_local": false,
                    "name": "Let's Talk About Sex"    ,
                    "popularity": 0,
                    "preview_url": null,
                    "track": true,
                    "track_number": 15,
                    "type": "track",
                    "uri": "spotify:track:32PCjJw8mk1FrJT2FcqRtT"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:18:37Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/5ht2HGrvbN9eDWJarHsou6"
                                },
                                "href": "https://api.spotify.com/v1/artists/5ht2HGrvbN9eDWJarHsou6",
                                "id": "5ht2HGrvbN9eDWJarHsou6",
                                "name": "Daddy Cool",
                                "type": "artist",
                                "uri": "spotify:artist:5ht2HGrvbN9eDWJarHsou6"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/4ZejRTERcKwWr0bc8CslGV"
                        },
                        "href": "https://api.spotify.com/v1/albums/4ZejRTERcKwWr0bc8CslGV",
                        "id": "4ZejRTERcKwWr0bc8CslGV",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2738a62b3ddb1b4eaa7739cc770",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e028a62b3ddb1b4eaa7739cc770",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048518a62b3ddb1b4eaa7739cc770",
                                "width": 64
                            }
                        ],
                        "name": "Daddy Who? Daddy Cool (40th Anniversary Edition)",
                        "release_date": "1971-07-01",
                        "release_date_precision": "day",
                        "total_tracks": 15,
                        "type": "album",
                        "uri": "spotify:album:4ZejRTERcKwWr0bc8CslGV"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/5ht2HGrvbN9eDWJarHsou6"
                            },
                            "href": "https://api.spotify.com/v1/artists/5ht2HGrvbN9eDWJarHsou6",
                            "id": "5ht2HGrvbN9eDWJarHsou6",
                            "name": "Daddy Cool",
                            "type": "artist",
                            "uri": "spotify:artist:5ht2HGrvbN9eDWJarHsou6"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 250066,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "AUBM01100328"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/2nCXuFS4Dt4BpHkxA9rhPL"
                    },
                    "href": "https://api.spotify.com/v1/tracks/2nCXuFS4Dt4BpHkxA9rhPL",
                    "id": "2nCXuFS4Dt4BpHkxA9rhPL",
                    "is_local": false,
                    "name": "Eagle Rock - 2011 Remaster",
                    "popularity": 60,
                    "preview_url": "https://p.scdn.co/mp3-preview    /d2c8c7672227054901c898a841c127605a84cfcc?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 7,
                    "type": "track",
                    "uri": "spotify:track:2nCXuFS4Dt4BpHkxA9rhPL"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:18:44Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/6LBCQo20ri3tsvbsWWLmr6"
                                },
                                "href": "https://api.spotify.com/v1/artists/6LBCQo20ri3tsvbsWWLmr6",
                                "id": "6LBCQo20ri3tsvbsWWLmr6",
                                "name": "Powderfinger",
                                "type": "artist",
                                "uri": "spotify:artist:6LBCQo20ri3tsvbsWWLmr6"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/5EmYAq4NagWeuaaEvzOmac"
                        },
                        "href": "https://api.spotify.com/v1/albums/5EmYAq4NagWeuaaEvzOmac",
                        "id": "5EmYAq4NagWeuaaEvzOmac",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273c2c400c36db8870048859fe1",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02c2c400c36db8870048859fe1",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851c2c400c36db8870048859fe1",
                                "width": 64
                            }
                        ],
                        "name": "Odyssey Number Five",
                        "release_date": "2000-01-01",
                        "release_date_precision": "day",
                        "total_tracks": 11,
                        "type": "album",
                        "uri": "spotify:album:5EmYAq4NagWeuaaEvzOmac"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/6LBCQo20ri3tsvbsWWLmr6"
                            },
                            "href": "https://api.spotify.com/v1/artists/6LBCQo20ri3tsvbsWWLmr6",
                            "id": "6LBCQo20ri3tsvbsWWLmr6",
                            "name": "Powderfinger",
                            "type": "artist",
                            "uri": "spotify:artist:6LBCQo20ri3tsvbsWWLmr6"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 276706,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "AUUM00010045"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/251PhjPNakilcDWfUXCo2Y"
                    },
                    "href": "https://api.spotify.com/v1/tracks/251PhjPNakilcDWfUXCo2Y",
                    "id": "251PhjPNakilcDWfUXCo2Y",
                    "is_local": false,
                    "name": "My Happiness    ",
                    "popularity": 1,
                    "preview_url": null,
                    "track": true,
                    "track_number": 2,
                    "type": "track",
                    "uri": "spotify:track:251PhjPNakilcDWfUXCo2Y"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:19:36Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/4STHEaNw4mPZ2tzheohgXB"
                                },
                                "href": "https://api.spotify.com/v1/artists/4STHEaNw4mPZ2tzheohgXB",
                                "id": "4STHEaNw4mPZ2tzheohgXB",
                                "name": "Paul McCartney",
                                "type": "artist",
                                "uri": "spotify:artist:4STHEaNw4mPZ2tzheohgXB"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/2rrxATdBTvNt2i9lJo68qU"
                        },
                        "href": "https://api.spotify.com/v1/albums/2rrxATdBTvNt2i9lJo68qU",
                        "id": "2rrxATdBTvNt2i9lJo68qU",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2732e759b212add227cba797c92",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e022e759b212add227cba797c92",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048512e759b212add227cba797c92",
                                "width": 64
                            }
                        ],
                        "name": "Back In The World",
                        "release_date": "2003-05-17",
                        "release_date_precision": "day",
                        "total_tracks": 36,
                        "type": "album",
                        "uri": "spotify:album:2rrxATdBTvNt2i9lJo68qU"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/4STHEaNw4mPZ2tzheohgXB"
                            },
                            "href": "https://api.spotify.com/v1/artists/4STHEaNw4mPZ2tzheohgXB",
                            "id": "4STHEaNw4mPZ2tzheohgXB",
                            "name": "Paul McCartney",
                            "type": "artist",
                            "uri": "spotify:artist:4STHEaNw4mPZ2tzheohgXB"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 2,
                    "duration_ms": 455560,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBCCS0201312"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/6JNLbLXIhXAhuUvEZsSyeY"
                    },
                    "href": "https://api.spotify.com/v1/tracks/6JNLbLXIhXAhuUvEZsSyeY",
                    "id": "6JNLbLXIhXAhuUvEZsSyeY",
                    "is_local": false,
                    "name": "Hey Jude"    ,
                    "popularity": 0,
                    "preview_url": null,
                    "track": true,
                    "track_number": 14,
                    "type": "track",
                    "uri": "spotify:track:6JNLbLXIhXAhuUvEZsSyeY"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:19:57Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/1w5Kfo2jwwIPruYS2UWh56"
                                },
                                "href": "https://api.spotify.com/v1/artists/1w5Kfo2jwwIPruYS2UWh56",
                                "id": "1w5Kfo2jwwIPruYS2UWh56",
                                "name": "Pearl Jam",
                                "type": "artist",
                                "uri": "spotify:artist:1w5Kfo2jwwIPruYS2UWh56"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/5B4PYA7wNN4WdEXdIJu58a"
                        },
                        "href": "https://api.spotify.com/v1/albums/5B4PYA7wNN4WdEXdIJu58a",
                        "id": "5B4PYA7wNN4WdEXdIJu58a",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273d400d27cba05bb0545533864",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02d400d27cba05bb0545533864",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851d400d27cba05bb0545533864",
                                "width": 64
                            }
                        ],
                        "name": "Ten",
                        "release_date": "1991-08-27",
                        "release_date_precision": "day",
                        "total_tracks": 11,
                        "type": "album",
                        "uri": "spotify:album:5B4PYA7wNN4WdEXdIJu58a"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/1w5Kfo2jwwIPruYS2UWh56"
                            },
                            "href": "https://api.spotify.com/v1/artists/1w5Kfo2jwwIPruYS2UWh56",
                            "id": "1w5Kfo2jwwIPruYS2UWh56",
                            "name": "Pearl Jam",
                            "type": "artist",
                            "uri": "spotify:artist:1w5Kfo2jwwIPruYS2UWh56"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 340907,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USSM19100003"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/1L94M3KIu7QluZe63g64rv"
                    },
                    "href": "https://api.spotify.com/v1/tracks/1L94M3KIu7QluZe63g64rv",
                    "id": "1L94M3KIu7QluZe63g64rv",
                    "is_local": false,
                    "name": "Alive",
                    "popularity": 75,
                    "preview_url": "https://p.scdn.co/mp3-preview    /628f678adab15d9b2b8a144e4bdffd5b2c493436?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 3,
                    "type": "track",
                    "uri": "spotify:track:1L94M3KIu7QluZe63g64rv"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:20:06Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/4dpARuHxo51G3z768sgnrY"
                                },
                                "href": "https://api.spotify.com/v1/artists/4dpARuHxo51G3z768sgnrY",
                                "id": "4dpARuHxo51G3z768sgnrY",
                                "name": "Adele",
                                "type": "artist",
                                "uri": "spotify:artist:4dpARuHxo51G3z768sgnrY"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "CA",
                            "CH",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DZ",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "HK",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MY",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/7n3QJc7TBOxXtlYh4Ssll8"
                        },
                        "href": "https://api.spotify.com/v1/albums/7n3QJc7TBOxXtlYh4Ssll8",
                        "id": "7n3QJc7TBOxXtlYh4Ssll8",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273ba764098164f221484bcc309",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02ba764098164f221484bcc309",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851ba764098164f221484bcc309",
                                "width": 64
                            }
                        ],
                        "name": "21",
                        "release_date": "2011-01-19",
                        "release_date_precision": "day",
                        "total_tracks": 11,
                        "type": "album",
                        "uri": "spotify:album:7n3QJc7TBOxXtlYh4Ssll8"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/4dpARuHxo51G3z768sgnrY"
                            },
                            "href": "https://api.spotify.com/v1/artists/4dpARuHxo51G3z768sgnrY",
                            "id": "4dpARuHxo51G3z768sgnrY",
                            "name": "Adele",
                            "type": "artist",
                            "uri": "spotify:artist:4dpARuHxo51G3z768sgnrY"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "CA",
                        "CH",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DZ",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "HK",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MY",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 228093,
                    "episode": false,
                    "explicit": true,
                    "external_ids": {
                        "isrc": "GBBKS1000335"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/1eq1wUnLVLg4pdEfx9kajC"
                    },
                    "href": "https://api.spotify.com/v1/tracks/1eq1wUnLVLg4pdEfx9kajC",
                    "id": "1eq1wUnLVLg4pdEfx9kajC",
                    "is_local": false,
                    "name": "Rolling in the Deep",
                    "popularity": 76,
                    "preview_url": "https://p.scdn.co/mp3-preview    /b2ba47ab9af2b4cd08a04e45b94803bd076c209d?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:1eq1wUnLVLg4pdEfx9kajC"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:20:16Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "compilation",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/72KyoXzp0NOQij6OcmZUxk"
                                },
                                "href": "https://api.spotify.com/v1/artists/72KyoXzp0NOQij6OcmZUxk",
                                "id": "72KyoXzp0NOQij6OcmZUxk",
                                "name": "Midnight Oil",
                                "type": "artist",
                                "uri": "spotify:artist:72KyoXzp0NOQij6OcmZUxk"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/2H371tT3IIvmqji0iZCp0O"
                        },
                        "href": "https://api.spotify.com/v1/albums/2H371tT3IIvmqji0iZCp0O",
                        "id": "2H371tT3IIvmqji0iZCp0O",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b27318c8f4eca624b080ed00ba42",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e0218c8f4eca624b080ed00ba42",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d0000485118c8f4eca624b080ed00ba42",
                                "width": 64
                            }
                        ],
                        "name": "20000 Watt RSL - The Midnight Oil Collection",
                        "release_date": "1997",
                        "release_date_precision": "year",
                        "total_tracks": 18,
                        "type": "album",
                        "uri": "spotify:album:2H371tT3IIvmqji0iZCp0O"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/72KyoXzp0NOQij6OcmZUxk"
                            },
                            "href": "https://api.spotify.com/v1/artists/72KyoXzp0NOQij6OcmZUxk",
                            "id": "72KyoXzp0NOQij6OcmZUxk",
                            "name": "Midnight Oil",
                            "type": "artist",
                            "uri": "spotify:artist:72KyoXzp0NOQij6OcmZUxk"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 258173,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "AUSM09700190"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/6Nabz5Gsy80XL0MJoOmgF8"
                    },
                    "href": "https://api.spotify.com/v1/tracks/6Nabz5Gsy80XL0MJoOmgF8",
                    "id": "6Nabz5Gsy80XL0MJoOmgF8",
                    "is_local": false,
                    "name": "Beds Are Burning - Remastered",
                    "popularity": 63,
                    "preview_url": "https://p.scdn.co/mp3-preview    /c68dba22ba58c3d94eaf4de6dae5332bb23b421d?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 9,
                    "type": "track",
                    "uri": "spotify:track:6Nabz5Gsy80XL0MJoOmgF8"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:20:23Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/4Z8W4fKeB5YxbusRsdQVPb"
                                },
                                "href": "https://api.spotify.com/v1/artists/4Z8W4fKeB5YxbusRsdQVPb",
                                "id": "4Z8W4fKeB5YxbusRsdQVPb",
                                "name": "Radiohead",
                                "type": "artist",
                                "uri": "spotify:artist:4Z8W4fKeB5YxbusRsdQVPb"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/6400dnyeDyD2mIFHfkwHXN"
                        },
                        "href": "https://api.spotify.com/v1/albums/6400dnyeDyD2mIFHfkwHXN",
                        "id": "6400dnyeDyD2mIFHfkwHXN",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2732f85b65d3ac4d3d7f806ca11",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e022f85b65d3ac4d3d7f806ca11",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048512f85b65d3ac4d3d7f806ca11",
                                "width": 64
                            }
                        ],
                        "name": "Pablo Honey",
                        "release_date": "1993-02-22",
                        "release_date_precision": "day",
                        "total_tracks": 12,
                        "type": "album",
                        "uri": "spotify:album:6400dnyeDyD2mIFHfkwHXN"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/4Z8W4fKeB5YxbusRsdQVPb"
                            },
                            "href": "https://api.spotify.com/v1/artists/4Z8W4fKeB5YxbusRsdQVPb",
                            "id": "4Z8W4fKeB5YxbusRsdQVPb",
                            "name": "Radiohead",
                            "type": "artist",
                            "uri": "spotify:artist:4Z8W4fKeB5YxbusRsdQVPb"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 238640,
                    "episode": false,
                    "explicit": true,
                    "external_ids": {
                        "isrc": "GBAYE9200070"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/6b2oQwSGFkzsMtQruIWm2p"
                    },
                    "href": "https://api.spotify.com/v1/tracks/6b2oQwSGFkzsMtQruIWm2p",
                    "id": "6b2oQwSGFkzsMtQruIWm2p",
                    "is_local": false,
                    "name": "Creep",
                    "popularity": 82,
                    "preview_url": "https://p.scdn.co/mp3-preview    /e7eb60e9466bc3a27299ea8803aadf4fa9cf795c?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 2,
                    "type": "track",
                    "uri": "spotify:track:6b2oQwSGFkzsMtQruIWm2p"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:20:32Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/3RGLhK1IP9jnYFH4BRFJBS"
                                },
                                "href": "https://api.spotify.com/v1/artists/3RGLhK1IP9jnYFH4BRFJBS",
                                "id": "3RGLhK1IP9jnYFH4BRFJBS",
                                "name": "The Clash",
                                "type": "artist",
                                "uri": "spotify:artist:3RGLhK1IP9jnYFH4BRFJBS"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/6FCzvataOZh68j8OKzOt9a"
                        },
                        "href": "https://api.spotify.com/v1/albums/6FCzvataOZh68j8OKzOt9a",
                        "id": "6FCzvataOZh68j8OKzOt9a",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273cd9d8bc9ef04014b6e90e182",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02cd9d8bc9ef04014b6e90e182",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851cd9d8bc9ef04014b6e90e182",
                                "width": 64
                            }
                        ],
                        "name": "London Calling (Remastered)",
                        "release_date": "1979",
                        "release_date_precision": "year",
                        "total_tracks": 19,
                        "type": "album",
                        "uri": "spotify:album:6FCzvataOZh68j8OKzOt9a"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/3RGLhK1IP9jnYFH4BRFJBS"
                            },
                            "href": "https://api.spotify.com/v1/artists/3RGLhK1IP9jnYFH4BRFJBS",
                            "id": "3RGLhK1IP9jnYFH4BRFJBS",
                            "name": "The Clash",
                            "type": "artist",
                            "uri": "spotify:artist:3RGLhK1IP9jnYFH4BRFJBS"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 200480,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBARL1200680"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/5jzma6gCzYtKB1DbEwFZKH"
                    },
                    "href": "https://api.spotify.com/v1/tracks/5jzma6gCzYtKB1DbEwFZKH",
                    "id": "5jzma6gCzYtKB1DbEwFZKH",
                    "is_local": false,
                    "name": "London Calling - Remastered",
                    "popularity": 73,
                    "preview_url": "https://p.scdn.co/mp3-preview    /cab17680a55cff3339dec569c52b079efda6daad?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:5jzma6gCzYtKB1DbEwFZKH"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:20:47Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/1XgFuvRd7r5g0h844A5ZUQ"
                                },
                                "href": "https://api.spotify.com/v1/artists/1XgFuvRd7r5g0h844A5ZUQ",
                                "id": "1XgFuvRd7r5g0h844A5ZUQ",
                                "name": "Take That",
                                "type": "artist",
                                "uri": "spotify:artist:1XgFuvRd7r5g0h844A5ZUQ"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/5QnHvl0ne6yEhRGw3ajvFF"
                        },
                        "href": "https://api.spotify.com/v1/albums/5QnHvl0ne6yEhRGw3ajvFF",
                        "id": "5QnHvl0ne6yEhRGw3ajvFF",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2734d30d662454d239ed12fe963",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e024d30d662454d239ed12fe963",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048514d30d662454d239ed12fe963",
                                "width": 64
                            }
                        ],
                        "name": "Nobody Else (Deluxe)",
                        "release_date": "1995",
                        "release_date_precision": "year",
                        "total_tracks": 14,
                        "type": "album",
                        "uri": "spotify:album:5QnHvl0ne6yEhRGw3ajvFF"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/1XgFuvRd7r5g0h844A5ZUQ"
                            },
                            "href": "https://api.spotify.com/v1/artists/1XgFuvRd7r5g0h844A5ZUQ",
                            "id": "1XgFuvRd7r5g0h844A5ZUQ",
                            "name": "Take That",
                            "type": "artist",
                            "uri": "spotify:artist:1XgFuvRd7r5g0h844A5ZUQ"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 242266,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBARL9500020"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/24fQpRwKFkC3Fe8QtvvrNw"
                    },
                    "href": "https://api.spotify.com/v1/tracks/24fQpRwKFkC3Fe8QtvvrNw",
                    "id": "24fQpRwKFkC3Fe8QtvvrNw",
                    "is_local": false,
                    "name": "Back for Good - Radio Mix"    ,
                    "popularity": 37,
                    "preview_url": null,
                    "track": true,
                    "track_number": 2,
                    "type": "track",
                    "uri": "spotify:track:24fQpRwKFkC3Fe8QtvvrNw"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:20:58Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "compilation",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/3IUisqn0mluZR0LITs8Sqk"
                                },
                                "href": "https://api.spotify.com/v1/artists/3IUisqn0mluZR0LITs8Sqk",
                                "id": "3IUisqn0mluZR0LITs8Sqk",
                                "name": "ICEHOUSE",
                                "type": "artist",
                                "uri": "spotify:artist:3IUisqn0mluZR0LITs8Sqk"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/3UuP7QQWY6hXNiESqZei92"
                        },
                        "href": "https://api.spotify.com/v1/albums/3UuP7QQWY6hXNiESqZei92",
                        "id": "3UuP7QQWY6hXNiESqZei92",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273c1e97e3b542ffb0713d1bd8d",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02c1e97e3b542ffb0713d1bd8d",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851c1e97e3b542ffb0713d1bd8d",
                                "width": 64
                            }
                        ],
                        "name": "White Heat: 30 Hits",
                        "release_date": "2011-08-26",
                        "release_date_precision": "day",
                        "total_tracks": 30,
                        "type": "album",
                        "uri": "spotify:album:3UuP7QQWY6hXNiESqZei92"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/3IUisqn0mluZR0LITs8Sqk"
                            },
                            "href": "https://api.spotify.com/v1/artists/3IUisqn0mluZR0LITs8Sqk",
                            "id": "3IUisqn0mluZR0LITs8Sqk",
                            "name": "ICEHOUSE",
                            "type": "artist",
                            "uri": "spotify:artist:3IUisqn0mluZR0LITs8Sqk"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 317200,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "AUC441100021"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/2qUjP7g8WY3fzBCNTELwjy"
                    },
                    "href": "https://api.spotify.com/v1/tracks/2qUjP7g8WY3fzBCNTELwjy",
                    "id": "2qUjP7g8WY3fzBCNTELwjy",
                    "is_local": false,
                    "name": "Great Southern Land    ",
                    "popularity": 0,
                    "preview_url": null,
                    "track": true,
                    "track_number": 6,
                    "type": "track",
                    "uri": "spotify:track:2qUjP7g8WY3fzBCNTELwjy"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:21:04Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/4gzpq5DPGxSnKTe4SA8HAU"
                                },
                                "href": "https://api.spotify.com/v1/artists/4gzpq5DPGxSnKTe4SA8HAU",
                                "id": "4gzpq5DPGxSnKTe4SA8HAU",
                                "name": "Coldplay",
                                "type": "artist",
                                "uri": "spotify:artist:4gzpq5DPGxSnKTe4SA8HAU"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/0RHX9XECH8IVI3LNgWDpmQ"
                        },
                        "href": "https://api.spotify.com/v1/albums/0RHX9XECH8IVI3LNgWDpmQ",
                        "id": "0RHX9XECH8IVI3LNgWDpmQ",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273ad6f442ecac8735b9285a923",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02ad6f442ecac8735b9285a923",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851ad6f442ecac8735b9285a923",
                                "width": 64
                            }
                        ],
                        "name": "A Rush of Blood to the Head",
                        "release_date": "2002-08-08",
                        "release_date_precision": "day",
                        "total_tracks": 11,
                        "type": "album",
                        "uri": "spotify:album:0RHX9XECH8IVI3LNgWDpmQ"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/4gzpq5DPGxSnKTe4SA8HAU"
                            },
                            "href": "https://api.spotify.com/v1/artists/4gzpq5DPGxSnKTe4SA8HAU",
                            "id": "4gzpq5DPGxSnKTe4SA8HAU",
                            "name": "Coldplay",
                            "type": "artist",
                            "uri": "spotify:artist:4gzpq5DPGxSnKTe4SA8HAU"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 307879,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBAYE0200771"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/0BCPKOYdS2jbQ8iyB56Zns"
                    },
                    "href": "https://api.spotify.com/v1/tracks/0BCPKOYdS2jbQ8iyB56Zns",
                    "id": "0BCPKOYdS2jbQ8iyB56Zns",
                    "is_local": false,
                    "name": "Clocks",
                    "popularity": 76,
                    "preview_url": "https://p.scdn.co/mp3-preview    /24c7fe858b234e3cb21872cd03ab44b669163fbb?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 5,
                    "type": "track",
                    "uri": "spotify:track:0BCPKOYdS2jbQ8iyB56Zns"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:21:20Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/6V6WCgi7waF55bJmylC4H5"
                                },
                                "href": "https://api.spotify.com/v1/artists/6V6WCgi7waF55bJmylC4H5",
                                "id": "6V6WCgi7waF55bJmylC4H5",
                                "name": "Gloria Gaynor",
                                "type": "artist",
                                "uri": "spotify:artist:6V6WCgi7waF55bJmylC4H5"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/0EvxRMIJySiL1ges38c753"
                        },
                        "href": "https://api.spotify.com/v1/albums/0EvxRMIJySiL1ges38c753",
                        "id": "0EvxRMIJySiL1ges38c753",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273793b4236b943cd72d1577ab2",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02793b4236b943cd72d1577ab2",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851793b4236b943cd72d1577ab2",
                                "width": 64
                            }
                        ],
                        "name": "I Will Survive (Rerecorded)",
                        "release_date": "1982",
                        "release_date_precision": "year",
                        "total_tracks": 10,
                        "type": "album",
                        "uri": "spotify:album:0EvxRMIJySiL1ges38c753"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/6V6WCgi7waF55bJmylC4H5"
                            },
                            "href": "https://api.spotify.com/v1/artists/6V6WCgi7waF55bJmylC4H5",
                            "id": "6V6WCgi7waF55bJmylC4H5",
                            "name": "Gloria Gaynor",
                            "type": "artist",
                            "uri": "spotify:artist:6V6WCgi7waF55bJmylC4H5"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 265026,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "FR6V88200357"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/2a1MrtxYybqFV1Ow8VJ1dW"
                    },
                    "href": "https://api.spotify.com/v1/tracks/2a1MrtxYybqFV1Ow8VJ1dW",
                    "id": "2a1MrtxYybqFV1Ow8VJ1dW",
                    "is_local": false,
                    "name": "I Will Survive - Rerecorded",
                    "popularity": 61,
                    "preview_url": "https://p.scdn.co/mp3-preview    /0f5744013a9c7464474a7c634a7880306ad1297d?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:2a1MrtxYybqFV1Ow8VJ1dW"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:21:30Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/2WKdxPFRD7IqZvlIAvhMgY"
                                },
                                "href": "https://api.spotify.com/v1/artists/2WKdxPFRD7IqZvlIAvhMgY",
                                "id": "2WKdxPFRD7IqZvlIAvhMgY",
                                "name": "Fugees",
                                "type": "artist",
                                "uri": "spotify:artist:2WKdxPFRD7IqZvlIAvhMgY"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/7m1r9h3wfPRm3Iv8uvq9vQ"
                        },
                        "href": "https://api.spotify.com/v1/albums/7m1r9h3wfPRm3Iv8uvq9vQ",
                        "id": "7m1r9h3wfPRm3Iv8uvq9vQ",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2734b7c4561e0f5002b9f5efb7a",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e024b7c4561e0f5002b9f5efb7a",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048514b7c4561e0f5002b9f5efb7a",
                                "width": 64
                            }
                        ],
                        "name": "The Score",
                        "release_date": "1996",
                        "release_date_precision": "year",
                        "total_tracks": 17,
                        "type": "album",
                        "uri": "spotify:album:7m1r9h3wfPRm3Iv8uvq9vQ"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/2WKdxPFRD7IqZvlIAvhMgY"
                            },
                            "href": "https://api.spotify.com/v1/artists/2WKdxPFRD7IqZvlIAvhMgY",
                            "id": "2WKdxPFRD7IqZvlIAvhMgY",
                            "name": "Fugees",
                            "type": "artist",
                            "uri": "spotify:artist:2WKdxPFRD7IqZvlIAvhMgY"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 298773,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USSM19600055"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/1MAqR81Tz28IIqMJ2KUDAO"
                    },
                    "href": "https://api.spotify.com/v1/tracks/1MAqR81Tz28IIqMJ2KUDAO",
                    "id": "1MAqR81Tz28IIqMJ2KUDAO",
                    "is_local": false,
                    "name": "Killing Me Softly With His Song    ",
                    "popularity": 5,
                    "preview_url": null,
                    "track": true,
                    "track_number": 8,
                    "type": "track",
                    "uri": "spotify:track:1MAqR81Tz28IIqMJ2KUDAO"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:21:40Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/5NGO30tJxFlKixkPSgXcFE"
                                },
                                "href": "https://api.spotify.com/v1/artists/5NGO30tJxFlKixkPSgXcFE",
                                "id": "5NGO30tJxFlKixkPSgXcFE",
                                "name": "The Police",
                                "type": "artist",
                                "uri": "spotify:artist:5NGO30tJxFlKixkPSgXcFE"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/28eOriEfl7IGbQDNvWIWXK"
                        },
                        "href": "https://api.spotify.com/v1/albums/28eOriEfl7IGbQDNvWIWXK",
                        "id": "28eOriEfl7IGbQDNvWIWXK",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b27307ea1b7ac092119e1b6dd57b",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e0207ea1b7ac092119e1b6dd57b",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d0000485107ea1b7ac092119e1b6dd57b",
                                "width": 64
                            }
                        ],
                        "name": "Synchronicity (Remastered)",
                        "release_date": "1983-06-01",
                        "release_date_precision": "day",
                        "total_tracks": 11,
                        "type": "album",
                        "uri": "spotify:album:28eOriEfl7IGbQDNvWIWXK"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/5NGO30tJxFlKixkPSgXcFE"
                            },
                            "href": "https://api.spotify.com/v1/artists/5NGO30tJxFlKixkPSgXcFE",
                            "id": "5NGO30tJxFlKixkPSgXcFE",
                            "name": "The Police",
                            "type": "artist",
                            "uri": "spotify:artist:5NGO30tJxFlKixkPSgXcFE"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 253250,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBAAM0201110"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/5C0LFQARavkPpn7JgA4sLk"
                    },
                    "href": "https://api.spotify.com/v1/tracks/5C0LFQARavkPpn7JgA4sLk",
                    "id": "5C0LFQARavkPpn7JgA4sLk",
                    "is_local": false,
                    "name": "Every Breath You Take - Remastered 2003"    ,
                    "popularity": 13,
                    "preview_url": null,
                    "track": true,
                    "track_number": 7,
                    "type": "track",
                    "uri": "spotify:track:5C0LFQARavkPpn7JgA4sLk"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:23:23Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/6PAt558ZEZl0DmdXlnjMgD"
                                },
                                "href": "https://api.spotify.com/v1/artists/6PAt558ZEZl0DmdXlnjMgD",
                                "id": "6PAt558ZEZl0DmdXlnjMgD",
                                "name": "Eric Clapton",
                                "type": "artist",
                                "uri": "spotify:artist:6PAt558ZEZl0DmdXlnjMgD"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/3ebyEGol0Abc7VAxYf7vEg"
                        },
                        "href": "https://api.spotify.com/v1/albums/3ebyEGol0Abc7VAxYf7vEg",
                        "id": "3ebyEGol0Abc7VAxYf7vEg",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273d55ec7fcfacd95e73877b787",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02d55ec7fcfacd95e73877b787",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851d55ec7fcfacd95e73877b787",
                                "width": 64
                            }
                        ],
                        "name": "Unplugged (Deluxe Edition)",
                        "release_date": "1992-08-25",
                        "release_date_precision": "day",
                        "total_tracks": 20,
                        "type": "album",
                        "uri": "spotify:album:3ebyEGol0Abc7VAxYf7vEg"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/6PAt558ZEZl0DmdXlnjMgD"
                            },
                            "href": "https://api.spotify.com/v1/artists/6PAt558ZEZl0DmdXlnjMgD",
                            "id": "6PAt558ZEZl0DmdXlnjMgD",
                            "name": "Eric Clapton",
                            "type": "artist",
                            "uri": "spotify:artist:6PAt558ZEZl0DmdXlnjMgD"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 280000,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USRE11300314"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/612VcBshQcy4mpB2utGc3H"
                    },
                    "href": "https://api.spotify.com/v1/tracks/612VcBshQcy4mpB2utGc3H",
                    "id": "612VcBshQcy4mpB2utGc3H",
                    "is_local": false,
                    "name": "Tears in Heaven - Acoustic; Live at MTV Unplugged, Bray Film Studios, Windsor, England, UK, 1/16/1992; 2013 Remaster",
                    "popularity": 72,
                    "preview_url": "https://p.scdn.co/mp3-preview    /6db51a706aa23e959e1f3ee27f26848ec81ff812?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 4,
                    "type": "track",
                    "uri": "spotify:track:612VcBshQcy4mpB2utGc3H"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:23:36Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/0lZoBs4Pzo7R89JM9lxwoT"
                                },
                                "href": "https://api.spotify.com/v1/artists/0lZoBs4Pzo7R89JM9lxwoT",
                                "id": "0lZoBs4Pzo7R89JM9lxwoT",
                                "name": "Duran Duran",
                                "type": "artist",
                                "uri": "spotify:artist:0lZoBs4Pzo7R89JM9lxwoT"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/2Tc7ILGF89w1PWOhzuZlqB"
                        },
                        "href": "https://api.spotify.com/v1/albums/2Tc7ILGF89w1PWOhzuZlqB",
                        "id": "2Tc7ILGF89w1PWOhzuZlqB",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2734984aa86fe9a5f99d73b60a4",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e024984aa86fe9a5f99d73b60a4",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048514984aa86fe9a5f99d73b60a4",
                                "width": 64
                            }
                        ],
                        "name": "Duran Duran (Deluxe Edition)",
                        "release_date": "1981-06-15",
                        "release_date_precision": "day",
                        "total_tracks": 27,
                        "type": "album",
                        "uri": "spotify:album:2Tc7ILGF89w1PWOhzuZlqB"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/0lZoBs4Pzo7R89JM9lxwoT"
                            },
                            "href": "https://api.spotify.com/v1/artists/0lZoBs4Pzo7R89JM9lxwoT",
                            "id": "0lZoBs4Pzo7R89JM9lxwoT",
                            "name": "Duran Duran",
                            "type": "artist",
                            "uri": "spotify:artist:0lZoBs4Pzo7R89JM9lxwoT"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 212853,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBAYE1000023"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/4EFkvOhgAmlHEfDfvfSoh5"
                    },
                    "href": "https://api.spotify.com/v1/tracks/4EFkvOhgAmlHEfDfvfSoh5",
                    "id": "4EFkvOhgAmlHEfDfvfSoh5",
                    "is_local": false,
                    "name": "Girls on Film - 2010 Remaster",
                    "popularity": 60,
                    "preview_url": "https://p.scdn.co/mp3-preview    /eedad12c75be8a41f9f8cbf5393410d286ec676c?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:4EFkvOhgAmlHEfDfvfSoh5"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:23:51Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/7EVPblaCtZJI6QBtJnqO7e"
                                },
                                "href": "https://api.spotify.com/v1/artists/7EVPblaCtZJI6QBtJnqO7e",
                                "id": "7EVPblaCtZJI6QBtJnqO7e",
                                "name": "Russell Morris",
                                "type": "artist",
                                "uri": "spotify:artist:7EVPblaCtZJI6QBtJnqO7e"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/59g9F8snSqu7JNay78YfbH"
                        },
                        "href": "https://api.spotify.com/v1/albums/59g9F8snSqu7JNay78YfbH",
                        "id": "59g9F8snSqu7JNay78YfbH",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b27350ffa155f414d1ce9de8ac27",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e0250ffa155f414d1ce9de8ac27",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d0000485150ffa155f414d1ce9de8ac27",
                                "width": 64
                            }
                        ],
                        "name": "Fundamentalist",
                        "release_date": "2007-05-19",
                        "release_date_precision": "day",
                        "total_tracks": 15,
                        "type": "album",
                        "uri": "spotify:album:59g9F8snSqu7JNay78YfbH"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/7EVPblaCtZJI6QBtJnqO7e"
                            },
                            "href": "https://api.spotify.com/v1/artists/7EVPblaCtZJI6QBtJnqO7e",
                            "id": "7EVPblaCtZJI6QBtJnqO7e",
                            "name": "Russell Morris",
                            "type": "artist",
                            "uri": "spotify:artist:7EVPblaCtZJI6QBtJnqO7e"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 274800,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "AULI00733670"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/2PjpTvzYS4Dfm7xyqkob2m"
                    },
                    "href": "https://api.spotify.com/v1/tracks/2PjpTvzYS4Dfm7xyqkob2m",
                    "id": "2PjpTvzYS4Dfm7xyqkob2m",
                    "is_local": false,
                    "name": "The Real Thing"    ,
                    "popularity": 0,
                    "preview_url": null,
                    "track": true,
                    "track_number": 13,
                    "type": "track",
                    "uri": "spotify:track:2PjpTvzYS4Dfm7xyqkob2m"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:23:59Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/0SdiiPkr02EUdekHZJkt58"
                                },
                                "href": "https://api.spotify.com/v1/artists/0SdiiPkr02EUdekHZJkt58",
                                "id": "0SdiiPkr02EUdekHZJkt58",
                                "name": "Hanson",
                                "type": "artist",
                                "uri": "spotify:artist:0SdiiPkr02EUdekHZJkt58"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/0IaT8AWtzOSAzWB1KXoTD8"
                        },
                        "href": "https://api.spotify.com/v1/albums/0IaT8AWtzOSAzWB1KXoTD8",
                        "id": "0IaT8AWtzOSAzWB1KXoTD8",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273aeb97994467b5a33f2b3fa12",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02aeb97994467b5a33f2b3fa12",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851aeb97994467b5a33f2b3fa12",
                                "width": 64
                            }
                        ],
                        "name": "MmmBop : The Collection",
                        "release_date": "2005-01-01",
                        "release_date_precision": "day",
                        "total_tracks": 17,
                        "type": "album",
                        "uri": "spotify:album:0IaT8AWtzOSAzWB1KXoTD8"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/0SdiiPkr02EUdekHZJkt58"
                            },
                            "href": "https://api.spotify.com/v1/artists/0SdiiPkr02EUdekHZJkt58",
                            "id": "0SdiiPkr02EUdekHZJkt58",
                            "name": "Hanson",
                            "type": "artist",
                            "uri": "spotify:artist:0SdiiPkr02EUdekHZJkt58"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 267946,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USMR19786791"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/1reVP49LT6RsV6kYY9lTZz"
                    },
                    "href": "https://api.spotify.com/v1/tracks/1reVP49LT6RsV6kYY9lTZz",
                    "id": "1reVP49LT6RsV6kYY9lTZz",
                    "is_local": false,
                    "name": "MMMBop    ",
                    "popularity": 2,
                    "preview_url": null,
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:1reVP49LT6RsV6kYY9lTZz"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:24:07Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/7jy3rLJdDQY21OgRLCZ9sD"
                                },
                                "href": "https://api.spotify.com/v1/artists/7jy3rLJdDQY21OgRLCZ9sD",
                                "id": "7jy3rLJdDQY21OgRLCZ9sD",
                                "name": "Foo Fighters",
                                "type": "artist",
                                "uri": "spotify:artist:7jy3rLJdDQY21OgRLCZ9sD"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/30ly6F6Xl0TKmyBCU50Khv"
                        },
                        "href": "https://api.spotify.com/v1/albums/30ly6F6Xl0TKmyBCU50Khv",
                        "id": "30ly6F6Xl0TKmyBCU50Khv",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2730389027010b78a5e7dce426b",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e020389027010b78a5e7dce426b",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048510389027010b78a5e7dce426b",
                                "width": 64
                            }
                        ],
                        "name": "The Colour And The Shape",
                        "release_date": "1997-05-20",
                        "release_date_precision": "day",
                        "total_tracks": 14,
                        "type": "album",
                        "uri": "spotify:album:30ly6F6Xl0TKmyBCU50Khv"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/7jy3rLJdDQY21OgRLCZ9sD"
                            },
                            "href": "https://api.spotify.com/v1/artists/7jy3rLJdDQY21OgRLCZ9sD",
                            "id": "7jy3rLJdDQY21OgRLCZ9sD",
                            "name": "Foo Fighters",
                            "type": "artist",
                            "uri": "spotify:artist:7jy3rLJdDQY21OgRLCZ9sD"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 250546,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USRW29600011"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/5UWwZ5lm5PKu6eKsHAGxOk"
                    },
                    "href": "https://api.spotify.com/v1/tracks/5UWwZ5lm5PKu6eKsHAGxOk",
                    "id": "5UWwZ5lm5PKu6eKsHAGxOk",
                    "is_local": false,
                    "name": "Everlong",
                    "popularity": 76,
                    "preview_url": "https://p.scdn.co/mp3-preview/    4a2dc307a71393a695d69b16407cd73e1e234941?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 11,
                    "type": "track",
                    "uri": "spotify:track:5UWwZ5lm5PKu6eKsHAGxOk"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:24:19Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/5lpH0xAS4fVfLkACg9DAuM"
                                },
                                "href": "https://api.spotify.com/v1/artists/5lpH0xAS4fVfLkACg9DAuM",
                                "id": "5lpH0xAS4fVfLkACg9DAuM",
                                "name": "Wham!",
                                "type": "artist",
                                "uri": "spotify:artist:5lpH0xAS4fVfLkACg9DAuM"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/02f3y3NTsddjdUMoNiBppI"
                        },
                        "href": "https://api.spotify.com/v1/albums/02f3y3NTsddjdUMoNiBppI",
                        "id": "02f3y3NTsddjdUMoNiBppI",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273a2fc41b0dd6ce4f0d16a4c46",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02a2fc41b0dd6ce4f0d16a4c46",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851a2fc41b0dd6ce4f0d16a4c46",
                                "width": 64
                            }
                        ],
                        "name": "Make It Big",
                        "release_date": "1984-10-23",
                        "release_date_precision": "day",
                        "total_tracks": 8,
                        "type": "album",
                        "uri": "spotify:album:02f3y3NTsddjdUMoNiBppI"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/5lpH0xAS4fVfLkACg9DAuM"
                            },
                            "href": "https://api.spotify.com/v1/artists/5lpH0xAS4fVfLkACg9DAuM",
                            "id": "5lpH0xAS4fVfLkACg9DAuM",
                            "name": "Wham!",
                            "type": "artist",
                            "uri": "spotify:artist:5lpH0xAS4fVfLkACg9DAuM"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 231333,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBBBN0009712"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/0ikz6tENMONtK6qGkOrU3c"
                    },
                    "href": "https://api.spotify.com/v1/tracks/0ikz6tENMONtK6qGkOrU3c",
                    "id": "0ikz6tENMONtK6qGkOrU3c",
                    "is_local": false,
                    "name": "Wake Me up Before You Go-Go",
                    "popularity": 79,
                    "preview_url": "https://p.scdn.co/mp3-preview    /d1c143357d86d1736806ed7404b71a44feb8451d?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:0ikz6tENMONtK6qGkOrU3c"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:24:29Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/6Q192DXotxtaysaqNPy5yR"
                                },
                                "href": "https://api.spotify.com/v1/artists/6Q192DXotxtaysaqNPy5yR",
                                "id": "6Q192DXotxtaysaqNPy5yR",
                                "name": "Amy Winehouse",
                                "type": "artist",
                                "uri": "spotify:artist:6Q192DXotxtaysaqNPy5yR"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/6GJCGWfI95aeRsdtVB52vc"
                        },
                        "href": "https://api.spotify.com/v1/albums/6GJCGWfI95aeRsdtVB52vc",
                        "id": "6GJCGWfI95aeRsdtVB52vc",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2734b6583b0a1505e40779faec6",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e024b6583b0a1505e40779faec6",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048514b6583b0a1505e40779faec6",
                                "width": 64
                            }
                        ],
                        "name": "Back To Black",
                        "release_date": "2006-01-01",
                        "release_date_precision": "day",
                        "total_tracks": 11,
                        "type": "album",
                        "uri": "spotify:album:6GJCGWfI95aeRsdtVB52vc"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/6Q192DXotxtaysaqNPy5yR"
                            },
                            "href": "https://api.spotify.com/v1/artists/6Q192DXotxtaysaqNPy5yR",
                            "id": "6Q192DXotxtaysaqNPy5yR",
                            "name": "Amy Winehouse",
                            "type": "artist",
                            "uri": "spotify:artist:6Q192DXotxtaysaqNPy5yR"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 213760,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBUM70603730"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/4osg3vT6sXv6wNxm9Z6ucQ"
                    },
                    "href": "https://api.spotify.com/v1/tracks/4osg3vT6sXv6wNxm9Z6ucQ",
                    "id": "4osg3vT6sXv6wNxm9Z6ucQ",
                    "is_local": false,
                    "name": "Rehab    ",
                    "popularity": 4,
                    "preview_url": null,
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:4osg3vT6sXv6wNxm9Z6ucQ"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:24:48Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/5gznATMVO85ZcLTkE9ULU7"
                                },
                                "href": "https://api.spotify.com/v1/artists/5gznATMVO85ZcLTkE9ULU7",
                                "id": "5gznATMVO85ZcLTkE9ULU7",
                                "name": "Lenny Kravitz",
                                "type": "artist",
                                "uri": "spotify:artist:5gznATMVO85ZcLTkE9ULU7"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/35LzZH7Fgog8lf1hfcdoMQ"
                        },
                        "href": "https://api.spotify.com/v1/albums/35LzZH7Fgog8lf1hfcdoMQ",
                        "id": "35LzZH7Fgog8lf1hfcdoMQ",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273542d87e4d1512bf7facb3860",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02542d87e4d1512bf7facb3860",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851542d87e4d1512bf7facb3860",
                                "width": 64
                            }
                        ],
                        "name": "Are You Gonna Go My Way",
                        "release_date": "1993-03-09",
                        "release_date_precision": "day",
                        "total_tracks": 11,
                        "type": "album",
                        "uri": "spotify:album:35LzZH7Fgog8lf1hfcdoMQ"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/5gznATMVO85ZcLTkE9ULU7"
                            },
                            "href": "https://api.spotify.com/v1/artists/5gznATMVO85ZcLTkE9ULU7",
                            "id": "5gznATMVO85ZcLTkE9ULU7",
                            "name": "Lenny Kravitz",
                            "type": "artist",
                            "uri": "spotify:artist:5gznATMVO85ZcLTkE9ULU7"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 211933,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USVI29300001"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/45Ia1U4KtIjAPPU7Wv1Sea"
                    },
                    "href": "https://api.spotify.com/v1/tracks/45Ia1U4KtIjAPPU7Wv1Sea",
                    "id": "45Ia1U4KtIjAPPU7Wv1Sea",
                    "is_local": false,
                    "name": "Are You Gonna Go My Way",
                    "popularity": 72,
                    "preview_url": "https://p.scdn.co/mp3-preview    /6a3d395821e9a90da87458bff1f08119d7323e41?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:45Ia1U4KtIjAPPU7Wv1Sea"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:25:03Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/67ea9eGLXYMsO2eYQRui3w"
                                },
                                "href": "https://api.spotify.com/v1/artists/67ea9eGLXYMsO2eYQRui3w",
                                "id": "67ea9eGLXYMsO2eYQRui3w",
                                "name": "The Who",
                                "type": "artist",
                                "uri": "spotify:artist:67ea9eGLXYMsO2eYQRui3w"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/1JAdpYypQlNaPjL3kHgRZm"
                        },
                        "href": "https://api.spotify.com/v1/albums/1JAdpYypQlNaPjL3kHgRZm",
                        "id": "1JAdpYypQlNaPjL3kHgRZm",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2737822e765ff3459ca3c870e4d",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e027822e765ff3459ca3c870e4d",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048517822e765ff3459ca3c870e4d",
                                "width": 64
                            }
                        ],
                        "name": "My Generation (Remastered Mono Version)",
                        "release_date": "1965-12-03",
                        "release_date_precision": "day",
                        "total_tracks": 12,
                        "type": "album",
                        "uri": "spotify:album:1JAdpYypQlNaPjL3kHgRZm"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/67ea9eGLXYMsO2eYQRui3w"
                            },
                            "href": "https://api.spotify.com/v1/artists/67ea9eGLXYMsO2eYQRui3w",
                            "id": "67ea9eGLXYMsO2eYQRui3w",
                            "name": "The Who",
                            "type": "artist",
                            "uri": "spotify:artist:67ea9eGLXYMsO2eYQRui3w"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 197320,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBAKW6500004"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/6UdCTwbVAvNqbWyZKZiRWL"
                    },
                    "href": "https://api.spotify.com/v1/tracks/6UdCTwbVAvNqbWyZKZiRWL",
                    "id": "6UdCTwbVAvNqbWyZKZiRWL",
                    "is_local": false,
                    "name": "My Generation - Original Mono Version    ",
                    "popularity": 1,
                    "preview_url": null,
                    "track": true,
                    "track_number": 6,
                    "type": "track",
                    "uri": "spotify:track:6UdCTwbVAvNqbWyZKZiRWL"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:25:19Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/2cGwlqi3k18jFpUyTrsR84"
                                },
                                "href": "https://api.spotify.com/v1/artists/2cGwlqi3k18jFpUyTrsR84",
                                "id": "2cGwlqi3k18jFpUyTrsR84",
                                "name": "The Verve",
                                "type": "artist",
                                "uri": "spotify:artist:2cGwlqi3k18jFpUyTrsR84"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/2okCg9scHue9GNELoB8U9g"
                        },
                        "href": "https://api.spotify.com/v1/albums/2okCg9scHue9GNELoB8U9g",
                        "id": "2okCg9scHue9GNELoB8U9g",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2738f0a8a62487542fef319d20a",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e028f0a8a62487542fef319d20a",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048518f0a8a62487542fef319d20a",
                                "width": 64
                            }
                        ],
                        "name": "Urban Hymns",
                        "release_date": "1997-09-29",
                        "release_date_precision": "day",
                        "total_tracks": 14,
                        "type": "album",
                        "uri": "spotify:album:2okCg9scHue9GNELoB8U9g"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/2cGwlqi3k18jFpUyTrsR84"
                            },
                            "href": "https://api.spotify.com/v1/artists/2cGwlqi3k18jFpUyTrsR84",
                            "id": "2cGwlqi3k18jFpUyTrsR84",
                            "name": "The Verve",
                            "type": "artist",
                            "uri": "spotify:artist:2cGwlqi3k18jFpUyTrsR84"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 358426,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBAAA9700049"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/5yEPxDjbbzUzyauGtnmVEC"
                    },
                    "href": "https://api.spotify.com/v1/tracks/5yEPxDjbbzUzyauGtnmVEC",
                    "id": "5yEPxDjbbzUzyauGtnmVEC",
                    "is_local": false,
                    "name": "Bitter Sweet Symphony    ",
                    "popularity": 9,
                    "preview_url": null,
                    "track": true,
                    "track_number": 1,
                    "type": "track",
                    "uri": "spotify:track:5yEPxDjbbzUzyauGtnmVEC"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:25:27Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/4iudEcmuPlYNdbP3e1bdn1"
                                },
                                "href": "https://api.spotify.com/v1/artists/4iudEcmuPlYNdbP3e1bdn1",
                                "id": "4iudEcmuPlYNdbP3e1bdn1",
                                "name": "Silverchair",
                                "type": "artist",
                                "uri": "spotify:artist:4iudEcmuPlYNdbP3e1bdn1"
                            }
                        ],
                        "available_markets": [
                            "AU",
                            "NZ"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/7yDs4Q4jhZEOTivpHbllda"
                        },
                        "href": "https://api.spotify.com/v1/albums/7yDs4Q4jhZEOTivpHbllda",
                        "id": "7yDs4Q4jhZEOTivpHbllda",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273d6186a92ad92606981160837",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02d6186a92ad92606981160837",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851d6186a92ad92606981160837",
                                "width": 64
                            }
                        ],
                        "name": "Young Modern",
                        "release_date": "2007-03-30",
                        "release_date_precision": "day",
                        "total_tracks": 11,
                        "type": "album",
                        "uri": "spotify:album:7yDs4Q4jhZEOTivpHbllda"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/4iudEcmuPlYNdbP3e1bdn1"
                            },
                            "href": "https://api.spotify.com/v1/artists/4iudEcmuPlYNdbP3e1bdn1",
                            "id": "4iudEcmuPlYNdbP3e1bdn1",
                            "name": "Silverchair",
                            "type": "artist",
                            "uri": "spotify:artist:4iudEcmuPlYNdbP3e1bdn1"
                        }
                    ],
                    "available_markets": [
                        "AU",
                        "NZ"
                    ],
                    "disc_number": 1,
                    "duration_ms": 257733,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "AUEL00700009"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/5HBDU0kn4f4hkZMjABsltT"
                    },
                    "href": "https://api.spotify.com/v1/tracks/5HBDU0kn4f4hkZMjABsltT",
                    "id": "5HBDU0kn4f4hkZMjABsltT",
                    "is_local": false,
                    "name": "Straight Lines",
                    "popularity": 57,
                    "preview_url": "https://p.scdn.co/mp3-preview    /467da8c718a448c58d21deb47801796bac1b7ca2?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 2,
                    "type": "track",
                    "uri": "spotify:track:5HBDU0kn4f4hkZMjABsltT"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:25:37Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "compilation",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/6ogn9necmbUdCppmNnGOdi"
                                },
                                "href": "https://api.spotify.com/v1/artists/6ogn9necmbUdCppmNnGOdi",
                                "id": "6ogn9necmbUdCppmNnGOdi",
                                "name": "Alanis Morissette",
                                "type": "artist",
                                "uri": "spotify:artist:6ogn9necmbUdCppmNnGOdi"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/4N7LuZYpstQrtcHIoOKzqg"
                        },
                        "href": "https://api.spotify.com/v1/albums/4N7LuZYpstQrtcHIoOKzqg",
                        "id": "4N7LuZYpstQrtcHIoOKzqg",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b273d00e49003543a5bb5aa5b873",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e02d00e49003543a5bb5aa5b873",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d00004851d00e49003543a5bb5aa5b873",
                                "width": 64
                            }
                        ],
                        "name": "The Collection (Standard Edition)",
                        "release_date": "2005-11-11",
                        "release_date_precision": "day",
                        "total_tracks": 19,
                        "type": "album",
                        "uri": "spotify:album:4N7LuZYpstQrtcHIoOKzqg"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/6ogn9necmbUdCppmNnGOdi"
                            },
                            "href": "https://api.spotify.com/v1/artists/6ogn9necmbUdCppmNnGOdi",
                            "id": "6ogn9necmbUdCppmNnGOdi",
                            "name": "Alanis Morissette",
                            "type": "artist",
                            "uri": "spotify:artist:6ogn9necmbUdCppmNnGOdi"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 249760,
                    "episode": false,
                    "explicit": true,
                    "external_ids": {
                        "isrc": "USMV20500300"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/17ZAZ24Eyh5fKqQ06u4R3d"
                    },
                    "href": "https://api.spotify.com/v1/tracks/17ZAZ24Eyh5fKqQ06u4R3d",
                    "id": "17ZAZ24Eyh5fKqQ06u4R3d",
                    "is_local": false,
                    "name": "You Oughta Know",
                    "popularity": 52,
                    "preview_url": "https://p.scdn.co/mp3-preview/    d81696e37c3470da07a0f8c358ea3eca65c5b6a3?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 10,
                    "type": "track",
                    "uri": "spotify:track:17ZAZ24Eyh5fKqQ06u4R3d"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:25:45Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/3fMbdgg4jU18AjLCKBhRSm"
                                },
                                "href": "https://api.spotify.com/v1/artists/3fMbdgg4jU18AjLCKBhRSm",
                                "id": "3fMbdgg4jU18AjLCKBhRSm",
                                "name": "Michael Jackson",
                                "type": "artist",
                                "uri": "spotify:artist:3fMbdgg4jU18AjLCKBhRSm"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LI",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PS",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/1C2h7mLntPSeVYciMRTF4a"
                        },
                        "href": "https://api.spotify.com/v1/albums/1C2h7mLntPSeVYciMRTF4a",
                        "id": "1C2h7mLntPSeVYciMRTF4a",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2734121faee8df82c526cbab2be",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e024121faee8df82c526cbab2be",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048514121faee8df82c526cbab2be",
                                "width": 64
                            }
                        ],
                        "name": "Thriller 25 Super Deluxe Edition",
                        "release_date": "1982-11-30",
                        "release_date_precision": "day",
                        "total_tracks": 30,
                        "type": "album",
                        "uri": "spotify:album:1C2h7mLntPSeVYciMRTF4a"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/3fMbdgg4jU18AjLCKBhRSm"
                            },
                            "href": "https://api.spotify.com/v1/artists/3fMbdgg4jU18AjLCKBhRSm",
                            "id": "3fMbdgg4jU18AjLCKBhRSm",
                            "name": "Michael Jackson",
                            "type": "artist",
                            "uri": "spotify:artist:3fMbdgg4jU18AjLCKBhRSm"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LI",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PS",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 293826,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USSM19902991"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/5ChkMS8OtdzJeqyybCc9R5"
                    },
                    "href": "https://api.spotify.com/v1/tracks/5ChkMS8OtdzJeqyybCc9R5",
                    "id": "5ChkMS8OtdzJeqyybCc9R5",
                    "is_local": false,
                    "name": "Billie Jean",
                    "popularity": 81,
                    "preview_url": "https://p.scdn.co/mp3-preview    /f504e6b8e037771318656394f532dede4f9bcaea?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 6,
                    "type": "track",
                    "uri": "spotify:track:5ChkMS8OtdzJeqyybCc9R5"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:25:58Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/6eUKZXaKkcviH0Ku9w2n3V"
                                },
                                "href": "https://api.spotify.com/v1/artists/6eUKZXaKkcviH0Ku9w2n3V",
                                "id": "6eUKZXaKkcviH0Ku9w2n3V",
                                "name": "Ed Sheeran",
                                "type": "artist",
                                "uri": "spotify:artist:6eUKZXaKkcviH0Ku9w2n3V"
                            }
                        ],
                        "available_markets": [
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/1xn54DMo2qIqBuMqHtUsFd"
                        },
                        "href": "https://api.spotify.com/v1/albums/1xn54DMo2qIqBuMqHtUsFd",
                        "id": "1xn54DMo2qIqBuMqHtUsFd",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b27313b3e37318a0c247b550bccd",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e0213b3e37318a0c247b550bccd",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d0000485113b3e37318a0c247b550bccd",
                                "width": 64
                            }
                        ],
                        "name": "x (Deluxe Edition)",
                        "release_date": "2014-06-21",
                        "release_date_precision": "day",
                        "total_tracks": 16,
                        "type": "album",
                        "uri": "spotify:album:1xn54DMo2qIqBuMqHtUsFd"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/6eUKZXaKkcviH0Ku9w2n3V"
                            },
                            "href": "https://api.spotify.com/v1/artists/6eUKZXaKkcviH0Ku9w2n3V",
                            "id": "6eUKZXaKkcviH0Ku9w2n3V",
                            "name": "Ed Sheeran",
                            "type": "artist",
                            "uri": "spotify:artist:6eUKZXaKkcviH0Ku9w2n3V"
                        }
                    ],
                    "available_markets": [
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 281560,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBAHS1400099"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/34gCuhDGsG4bRPIf9bb02f"
                    },
                    "href": "https://api.spotify.com/v1/tracks/34gCuhDGsG4bRPIf9bb02f",
                    "id": "34gCuhDGsG4bRPIf9bb02f",
                    "is_local": false,
                    "name": "Thinking out Loud",
                    "popularity": 82,
                    "preview_url": "https://p.scdn.co/mp3-preview/    7fba47d0806142cb34ad2080a5f139eba915fe05?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 11,
                    "type": "track",
                    "uri": "spotify:track:34gCuhDGsG4bRPIf9bb02f"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:26:10Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/7mEIug7XUlQHikrFxjTWes"
                                },
                                "href": "https://api.spotify.com/v1/artists/7mEIug7XUlQHikrFxjTWes",
                                "id": "7mEIug7XUlQHikrFxjTWes",
                                "name": "Neil Diamond",
                                "type": "artist",
                                "uri": "spotify:artist:7mEIug7XUlQHikrFxjTWes"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/3aLKBtYt2B0XdLaTtBzF2n"
                        },
                        "href": "https://api.spotify.com/v1/albums/3aLKBtYt2B0XdLaTtBzF2n",
                        "id": "3aLKBtYt2B0XdLaTtBzF2n",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b27326007318d27552db70e1cb95",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e0226007318d27552db70e1cb95",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d0000485126007318d27552db70e1cb95",
                                "width": 64
                            }
                        ],
                        "name": "Sweet Caroline",
                        "release_date": "1969",
                        "release_date_precision": "year",
                        "total_tracks": 13,
                        "type": "album",
                        "uri": "spotify:album:3aLKBtYt2B0XdLaTtBzF2n"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/7mEIug7XUlQHikrFxjTWes"
                            },
                            "href": "https://api.spotify.com/v1/artists/7mEIug7XUlQHikrFxjTWes",
                            "id": "7mEIug7XUlQHikrFxjTWes",
                            "name": "Neil Diamond",
                            "type": "artist",
                            "uri": "spotify:artist:7mEIug7XUlQHikrFxjTWes"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 203573,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "USMC16991138"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/3zByVQLvdXUaDTubfWkpCk"
                    },
                    "href": "https://api.spotify.com/v1/tracks/3zByVQLvdXUaDTubfWkpCk",
                    "id": "3zByVQLvdXUaDTubfWkpCk",
                    "is_local": false,
                    "name": "Sweet Caroline"    ,
                    "popularity": 4,
                    "preview_url": null,
                    "track": true,
                    "track_number": 13,
                    "type": "track",
                    "uri": "spotify:track:3zByVQLvdXUaDTubfWkpCk"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:26:18Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "album",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/0WwSkZ7LtFUFjGjMZBMt6T"
                                },
                                "href": "https://api.spotify.com/v1/artists/0WwSkZ7LtFUFjGjMZBMt6T",
                                "id": "0WwSkZ7LtFUFjGjMZBMt6T",
                                "name": "Dire Straits",
                                "type": "artist",
                                "uri": "spotify:artist:0WwSkZ7LtFUFjGjMZBMt6T"
                            }
                        ],
                        "available_markets": [],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/1NF8WUbdC632SIwixiWrLh"
                        },
                        "href": "https://api.spotify.com/v1/albums/1NF8WUbdC632SIwixiWrLh",
                        "id": "1NF8WUbdC632SIwixiWrLh",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b27348cd811e6c34abd3ff00d15f",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e0248cd811e6c34abd3ff00d15f",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d0000485148cd811e6c34abd3ff00d15f",
                                "width": 64
                            }
                        ],
                        "name": "Brothers In Arms (Remastered)",
                        "release_date": "1985-05-13",
                        "release_date_precision": "day",
                        "total_tracks": 9,
                        "type": "album",
                        "uri": "spotify:album:1NF8WUbdC632SIwixiWrLh"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/0WwSkZ7LtFUFjGjMZBMt6T"
                            },
                            "href": "https://api.spotify.com/v1/artists/0WwSkZ7LtFUFjGjMZBMt6T",
                            "id": "0WwSkZ7LtFUFjGjMZBMt6T",
                            "name": "Dire Straits",
                            "type": "artist",
                            "uri": "spotify:artist:0WwSkZ7LtFUFjGjMZBMt6T"
                        }
                    ],
                    "available_markets": [],
                    "disc_number": 1,
                    "duration_ms": 510933,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBF088500674"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/4WfGrAJVC3A5xhUTja0gUG"
                    },
                    "href": "https://api.spotify.com/v1/tracks/4WfGrAJVC3A5xhUTja0gUG",
                    "id": "4WfGrAJVC3A5xhUTja0gUG",
                    "is_local": false,
                    "name": "Money For Nothing    ",
                    "popularity": 4,
                    "preview_url": null,
                    "track": true,
                    "track_number": 2,
                    "type": "track",
                    "uri": "spotify:track:4WfGrAJVC3A5xhUTja0gUG"
                },
                "video_thumbnail": {
                    "url": null
                }
            },
            {
                "added_at": "2017-04-18T03:26:26Z",
                "added_by": {
                    "external_urls": {
                        "spotify": "https://open.spotify.com/user/maxaustralia"
                    },
                    "href": "https://api.spotify.com/v1/users/maxaustralia",
                    "id": "maxaustralia",
                    "type": "user",
                    "uri": "spotify:user:maxaustralia"
                },
                "is_local": false,
                "primary_color": null,
                "track": {
                    "album": {
                        "album_type": "compilation",
                        "artists": [
                            {
                                "external_urls": {
                                    "spotify": "https://open.spotify.com/artist/7MhMgCo0Bl0Kukl93PZbYS"
                                },
                                "href": "https://api.spotify.com/v1/artists/7MhMgCo0Bl0Kukl93PZbYS",
                                "id": "7MhMgCo0Bl0Kukl93PZbYS",
                                "name": "Blur",
                                "type": "artist",
                                "uri": "spotify:artist:7MhMgCo0Bl0Kukl93PZbYS"
                            }
                        ],
                        "available_markets": [
                            "AD",
                            "AE",
                            "AR",
                            "AT",
                            "AU",
                            "BE",
                            "BG",
                            "BH",
                            "BO",
                            "BR",
                            "CA",
                            "CH",
                            "CL",
                            "CO",
                            "CR",
                            "CY",
                            "CZ",
                            "DE",
                            "DK",
                            "DO",
                            "DZ",
                            "EC",
                            "EE",
                            "EG",
                            "ES",
                            "FI",
                            "FR",
                            "GB",
                            "GR",
                            "GT",
                            "HK",
                            "HN",
                            "HU",
                            "ID",
                            "IE",
                            "IL",
                            "IN",
                            "IS",
                            "IT",
                            "JO",
                            "JP",
                            "KW",
                            "LB",
                            "LT",
                            "LU",
                            "LV",
                            "MA",
                            "MC",
                            "MT",
                            "MX",
                            "MY",
                            "NI",
                            "NL",
                            "NO",
                            "NZ",
                            "OM",
                            "PA",
                            "PE",
                            "PH",
                            "PL",
                            "PT",
                            "PY",
                            "QA",
                            "RO",
                            "SA",
                            "SE",
                            "SG",
                            "SK",
                            "SV",
                            "TH",
                            "TN",
                            "TR",
                            "TW",
                            "US",
                            "UY",
                            "VN",
                            "ZA"
                        ],
                        "external_urls": {
                            "spotify": "https://open.spotify.com/album/1bgkxe4t0HNeLn9rhrx79x"
                        },
                        "href": "https://api.spotify.com/v1/albums/1bgkxe4t0HNeLn9rhrx79x",
                        "id": "1bgkxe4t0HNeLn9rhrx79x",
                        "images": [
                            {
                                "height": 640,
                                "url": "https://i.scdn.co/image/ab67616d0000b2736eba1a0996d9e69ad20ec88b",
                                "width": 640
                            },
                            {
                                "height": 300,
                                "url": "https://i.scdn.co/image/ab67616d00001e026eba1a0996d9e69ad20ec88b",
                                "width": 300
                            },
                            {
                                "height": 64,
                                "url": "https://i.scdn.co/image/ab67616d000048516eba1a0996d9e69ad20ec88b",
                                "width": 64
                            }
                        ],
                        "name": "Blur: The Best Of",
                        "release_date": "2000-10-23",
                        "release_date_precision": "day",
                        "total_tracks": 18,
                        "type": "album",
                        "uri": "spotify:album:1bgkxe4t0HNeLn9rhrx79x"
                    },
                    "artists": [
                        {
                            "external_urls": {
                                "spotify": "https://open.spotify.com/artist/7MhMgCo0Bl0Kukl93PZbYS"
                            },
                            "href": "https://api.spotify.com/v1/artists/7MhMgCo0Bl0Kukl93PZbYS",
                            "id": "7MhMgCo0Bl0Kukl93PZbYS",
                            "name": "Blur",
                            "type": "artist",
                            "uri": "spotify:artist:7MhMgCo0Bl0Kukl93PZbYS"
                        }
                    ],
                    "available_markets": [
                        "AD",
                        "AE",
                        "AR",
                        "AT",
                        "AU",
                        "BE",
                        "BG",
                        "BH",
                        "BO",
                        "BR",
                        "CA",
                        "CH",
                        "CL",
                        "CO",
                        "CR",
                        "CY",
                        "CZ",
                        "DE",
                        "DK",
                        "DO",
                        "DZ",
                        "EC",
                        "EE",
                        "EG",
                        "ES",
                        "FI",
                        "FR",
                        "GB",
                        "GR",
                        "GT",
                        "HK",
                        "HN",
                        "HU",
                        "ID",
                        "IE",
                        "IL",
                        "IN",
                        "IS",
                        "IT",
                        "JO",
                        "JP",
                        "KW",
                        "LB",
                        "LT",
                        "LU",
                        "LV",
                        "MA",
                        "MC",
                        "MT",
                        "MX",
                        "MY",
                        "NI",
                        "NL",
                        "NO",
                        "NZ",
                        "OM",
                        "PA",
                        "PE",
                        "PH",
                        "PL",
                        "PT",
                        "PY",
                        "QA",
                        "RO",
                        "SA",
                        "SE",
                        "SG",
                        "SK",
                        "SV",
                        "TH",
                        "TN",
                        "TR",
                        "TW",
                        "US",
                        "UY",
                        "VN",
                        "ZA"
                    ],
                    "disc_number": 1,
                    "duration_ms": 121880,
                    "episode": false,
                    "explicit": false,
                    "external_ids": {
                        "isrc": "GBAYE9600015"
                    },
                    "external_urls": {
                        "spotify": "https://open.spotify.com/track/3GfOAdcoc3X5GPiiXmpBjK"
                    },
                    "href": "https://api.spotify.com/v1/tracks/3GfOAdcoc3X5GPiiXmpBjK",
                    "id": "3GfOAdcoc3X5GPiiXmpBjK",
                    "is_local": false,
                    "name": "Song 2",
                    "popularity": 65,
                    "preview_url": "https://p.scdn.co/mp3-preview    /dfa055d3831ac3ec60cf66d92bda9ab68e302dbd?cid=774b29d4f13844c495f206cafdad9c86",
                    "track": true,
                    "track_number": 2,
                    "type": "track",
                    "uri": "spotify:track:3GfOAdcoc3X5GPiiXmpBjK"
                },
                "video_thumbnail": {
                    "url": null
                }
            }
        ]


